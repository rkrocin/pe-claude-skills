# Platform & DevOps Conference Profiles

## PlatformCon

- **Audience**: Platform engineers, DevEx leads, engineering leaders building IDPs
- **Typical attendees**: 10,000+ (virtual), mix of ICs and leaders
- **Session formats**: 20-30 min talks, panels, lightning talks
- **What gets accepted**: Practitioner stories with real outcomes, IDP case studies, platform team organizational models, developer experience research, open source platform tooling
- **What gets rejected**: Vendor pitches disguised as talks, purely theoretical frameworks without implementation evidence, "101" introductions to well-known topics
- **Tone**: Practitioner-to-practitioner. Honest about failures. Community-oriented.
- **Review emphasis**: Originality, specificity of outcomes, relevance to platform engineering practitioners

### What PlatformCon Reviewers Look For
- Real stories from real organizations (anonymized is fine, but concrete)
- Quantified outcomes (adoption metrics, developer experience improvements, DORA changes)
- Lessons from failure, not just success
- Actionable takeaways the audience can apply in their own organizations
- Diverse perspectives: not just Big Tech, also mid-market, regulated industries, startups

---

## KubeCon / CloudNativeCon

- **Audience**: Cloud native practitioners, Kubernetes administrators, CNCF ecosystem contributors
- **Typical attendees**: 10,000+ (in-person), heavily IC-focused
- **Session formats**: 35 min breakout, 5 min lightning, 90 min tutorial, panel
- **What gets accepted**: Deep technical content, production experience with CNCF projects, operator/controller patterns, multi-cluster architectures, security in cloud native environments
- **What gets rejected**: Introductory Kubernetes content, vendor product demos, talks without production experience
- **Tone**: Deeply technical, community-driven, open source-first
- **Review emphasis**: Technical depth, production experience, contribution to the ecosystem

### KubeCon Specific Guidance
- Mention specific CNCF projects by name (Backstage, Argo, Crossplane, OPA, Falco)
- Abstracts should demonstrate production-scale experience, not just lab experiments
- Include failure modes and operational challenges, not just success stories
- If the talk involves a proprietary system, frame it as a pattern that applies to the broader ecosystem

---

## DevOpsDays

- **Audience**: DevOps practitioners, SREs, engineering leaders, culture advocates
- **Typical attendees**: 200-500 per city (local events), mix of ICs and managers
- **Session formats**: 30 min talks, ignite talks (5 min / 20 slides auto-advance), open spaces
- **What gets accepted**: Culture and organizational change stories, CI/CD practice improvements, incident management experiences, DevOps adoption journeys, team topology changes
- **What gets rejected**: Pure product pitches, overly theoretical talks, content that ignores the human/cultural dimension of DevOps
- **Tone**: Community-focused, inclusive, values culture as much as technology
- **Review emphasis**: Story quality, relevance to practitioners, cultural/organizational dimension

### DevOpsDays Specific Guidance
- DevOpsDays values the human side of DevOps. Include people and culture alongside technology.
- Ignite format (5 min, 20 slides, auto-advance) is high-risk/high-reward. Only recommend for experienced speakers or very focused topics.
- Local events value local stories. Mention the city's tech community if relevant.
- Open spaces are a core part of DevOpsDays. Consider proposing an open space topic alongside a talk.

---

## SREcon

- **Audience**: SREs, reliability engineers, production engineering, infrastructure leadership
- **Typical attendees**: 500-800, heavily IC and senior IC
- **Session formats**: 25 min talks, 50 min deep dives, workshops, lightning talks
- **What gets accepted**: Novel approaches to reliability, incident management case studies, SLO implementation stories, observability deep dives, organizational models for SRE
- **What gets rejected**: Introductory SRE content, vendor pitches, talks without operational depth
- **Tone**: Deeply technical, operationally focused, values production experience
- **Review emphasis**: Operational depth, novelty, applicability to other organizations

---

## Velocity / O'Reilly Infrastructure & Ops

- **Audience**: Infrastructure engineers, ops leaders, performance engineers
- **Session formats**: 40 min talks, tutorials, keynotes
- **What gets accepted**: Infrastructure automation at scale, performance engineering, cloud migration stories, FinOps, observability architecture
- **Tone**: Technical with business context, values quantified outcomes
- **Review emphasis**: Scale, impact, transferability of lessons

---

## Local Meetups (General Guidance)

- **Audience**: Local practitioners, 20-100 attendees, mixed experience levels
- **Session formats**: 20-45 min talks, sometimes lightning talks
- **What works**: Practical demos, "here's how we did X" stories, new tool introductions, community discussion prompts
- **Tone**: Informal, conversational, questions encouraged throughout
- **Key difference from conferences**: Audience is local and likely to know each other. Personal connection matters. Community building is as important as content delivery.

### Meetup-Specific Guidance
- Shorter is better. 20-30 minutes with discussion is more engaging than 45 minutes of slides.
- Live demos work well in small groups but have higher risk. Have a fallback plan.
- End with something actionable: a repo to clone, a tool to try, a concept to discuss with their team on Monday.
- If you organize the meetup, speaking at your own event is a credibility builder for future conference CFPs.
