# Leadership & General Engineering Conference Profiles

## QCon

- **Audience**: Senior engineers, architects, engineering leaders
- **Typical attendees**: 1,000-1,500 per city (London, San Francisco, etc.)
- **Session formats**: 50 min talks organized in thematic tracks, workshops
- **What gets accepted**: Architecture decisions at scale, engineering organization design, technology strategy, platform evolution stories, emerging technology adoption
- **What gets rejected**: Introductory content, vendor pitches, talks without production depth
- **Tone**: Senior practitioner, values depth and nuance, intellectually rigorous
- **Review emphasis**: Seniority of content, architectural significance, transferability of lessons
- **Note**: QCon is invite-curated, not open CFP for all tracks. However, proposing talks through their submission process does get reviewed. Track hosts actively recruit.

## LeadDev

- **Audience**: Engineering managers, directors, VPs, CTOs
- **Typical attendees**: 500-1,000 per city
- **Session formats**: 30 min talks, panels, workshops
- **What gets accepted**: People management challenges, organizational design, engineering culture, career growth, diversity and inclusion in engineering, managing through change
- **What gets rejected**: Purely technical content without leadership framing, vendor pitches
- **Tone**: Empathetic, human-centered, values vulnerability and honesty about leadership challenges
- **Review emphasis**: Personal leadership story, actionable advice, emotional resonance

### LeadDev Specific Guidance
- LeadDev audiences want to hear about the hard parts of leadership: difficult conversations, organizational change, failure, and growth.
- Vulnerability is valued. "Here is how I failed and what I learned" is more powerful than "here is how I succeeded."
- Include the human impact of technical decisions, not just the technical outcome.

## AllDayDevOps

- **Audience**: DevOps practitioners and leaders, global virtual audience
- **Typical attendees**: 30,000+ (virtual, free)
- **Session formats**: 30 min talks, organized in tracks
- **What gets accepted**: DevOps practices, CI/CD, automation, cultural transformation, DevSecOps, SRE, platform engineering
- **What gets rejected**: Vendor demos, overly basic content
- **Tone**: Practitioner-friendly, inclusive, values accessibility
- **Review emphasis**: Breadth of appeal, practical applicability, clear takeaways
- **Note**: High acceptance rate makes this a good first conference for new speakers. Large audience provides visibility.

## CTO Summit / CTO Craft

- **Audience**: CTOs, VPs of Engineering, technical co-founders
- **Typical attendees**: 200-400, highly senior
- **Session formats**: 30-40 min talks, panels, fireside chats, roundtables
- **What gets accepted**: Technology strategy, engineering organization scaling, technical due diligence, M&A technology integration, executive communication, board-level technology storytelling
- **What gets rejected**: IC-level technical content, introductory management topics
- **Tone**: Executive, strategic, candid (closed or semi-closed events allow more honesty)
- **Review emphasis**: Seniority of perspective, strategic impact, candor

## Internal Tech Talks

- **Audience**: Your own engineering organization
- **Format**: 20-45 min, usually informal
- **What works**: Architectural deep dives, postmortem reviews, new tool introductions, cross-team knowledge sharing, "things I wish I knew when I started here"
- **Key difference**: No CFP process, but the same preparation disciplines apply. Internal talks build speaking confidence and can be refined into external conference submissions.
- **Tip**: Record internal talks. A recording of a well-delivered internal talk is powerful evidence in a conference CFP "notes to reviewers" field.
