# Cloud & Infrastructure Conference Profiles

## AWS re:Invent

- **Audience**: AWS practitioners, architects, developers, leadership. Broadest cloud conference.
- **Typical attendees**: 50,000+ (in-person), all levels
- **Session formats**: Breakout (60 min), chalk talk (60 min, interactive), workshop (2 hrs), builder session (60 min, hands-on), lightning talk
- **What gets accepted**: Production AWS architectures at scale, migration stories with quantified outcomes, innovative uses of AWS services, multi-account governance, cost optimization, security architecture
- **What gets rejected**: Beginner AWS content (200-level is the floor), non-AWS-specific content, vendor pitches from non-AWS companies
- **Tone**: Celebratory of AWS ecosystem but values honest production stories
- **Review emphasis**: Scale of deployment, specificity of architecture, quantified business outcomes

### re:Invent Specific Guidance
- Sessions are numbered by difficulty: 200 (introductory), 300 (advanced), 400 (expert). Most accepted customer talks are 300-400 level. Aim for 300+ unless specifically targeting a beginner track.
- Chalk talks are interactive whiteboard sessions. They require deep expertise because the audience asks questions in real time. Excellent format for architects.
- re:Invent values customer stories over vendor stories. If you work for an AWS customer, you have an advantage over consultancies.
- Include specific AWS service names in the abstract. Reviewers filter by service relevance.
- Mention specific metrics: cost savings, latency improvements, reliability improvements, team velocity gains.

---

## HashiConf

- **Audience**: Infrastructure automation practitioners, Terraform/Vault/Consul/Nomad users
- **Typical attendees**: 2,000-3,000
- **Session formats**: 30 min talks, workshops, lightning talks
- **What gets accepted**: Terraform at scale, multi-cloud infrastructure, secrets management, service mesh, infrastructure governance, policy-as-code
- **What gets rejected**: Introductory Terraform content, non-HashiCorp tooling focus, purely theoretical talks
- **Tone**: Community-driven, open source-friendly, values production experience
- **Review emphasis**: Scale, governance patterns, production challenges, community contribution

### HashiConf Specific Guidance
- Terraform talks should go beyond basics. Module management at scale, state management patterns, provider development, or policy-as-code (Sentinel/OPA) are strong topics.
- Multi-cloud is a strong theme. If your architecture spans AWS + another cloud, lean into that.
- Mention team and resource scale: "managing 2,000+ Terraform resources across 50 AWS accounts" signals depth.

---

## Google Cloud Next

- **Audience**: Google Cloud practitioners, data engineers, ML engineers, leadership
- **Typical attendees**: 30,000+
- **Session formats**: Breakout (45 min), workshop, lightning talk, demo theater
- **What gets accepted**: GCP architecture at scale, BigQuery/data engineering, Vertex AI/ML, Kubernetes/GKE, multi-cloud with GCP component
- **What gets rejected**: Non-GCP-specific content, introductory cloud content
- **Tone**: Innovation-focused, data and AI heavy, values quantified outcomes
- **Review emphasis**: GCP service usage, data/AI outcomes, architectural innovation

---

## CloudNativeCon (co-located with KubeCon)

See KubeCon in platform-devops-conferences.md. Key addition for infrastructure-focused talks:

- Infrastructure-layer talks (networking, storage, compute abstraction) fit well at CloudNativeCon
- Crossplane, Cluster API, and infrastructure controller patterns are strong themes
- Multi-cluster and multi-cloud architectures are consistently popular
- FinOps for Kubernetes is an emerging topic with growing interest

---

## Infrastructure-Focused Meetups

### Chicago Infrastructure-as-Code User Group
- **Audience**: Local IaC practitioners, 20-50 attendees
- **Format**: 20-30 min talks + discussion
- **What works**: Terraform tips and patterns, IaC governance approaches, tool comparisons, live demos, "how we solved X" stories
- **Tone**: Informal, collaborative, beginner-friendly
- **Unique value**: Organizer has first-mover advantage in proposing topics and recruiting speakers. Speaking at your own meetup builds a talk portfolio for larger conferences.
