# Security & Compliance Conference Profiles

## RSA Conference

- **Audience**: Security leaders, CISOs, security architects, vendors, analysts
- **Typical attendees**: 40,000+
- **Session formats**: 50 min breakout, panel, birds-of-a-feather, keynote
- **What gets accepted**: Novel security research, CISO-level strategy, compliance program development, security architecture at scale, AI security, zero trust implementation
- **What gets rejected**: Vendor pitches (heavy filtering), introductory security content, theoretical frameworks without evidence
- **Tone**: Professional, leadership-oriented, values actionable strategy
- **Review emphasis**: Novelty, practitioner relevance, speaker credibility

## BSides (Various Cities)

- **Audience**: Security practitioners, researchers, hackers, students
- **Typical attendees**: 200-1,000 per city, grassroots community events
- **Session formats**: 20-50 min talks, workshops, villages, CTFs
- **What gets accepted**: Security research, tool development, incident stories, defensive techniques, career development, community building
- **What gets rejected**: Vendor pitches (community strongly averse), overly corporate messaging
- **Tone**: Grassroots, hacker culture, inclusive, values honesty and technical depth
- **Review emphasis**: Originality, community value, technical substance

## fwd:cloudsec

- **Audience**: Cloud security practitioners, security engineers, DevSecOps
- **Typical attendees**: 300-500, highly focused
- **Session formats**: 25 min talks, lightning talks
- **What gets accepted**: Cloud security architecture, IAM at scale, container security, infrastructure security automation, incident response in cloud, compliance automation
- **What gets rejected**: Non-cloud security, vendor demos, introductory content
- **Tone**: Practitioner-focused, values production experience, cloud-specific
- **Review emphasis**: Cloud depth, actionable techniques, operational reality

## ISACA Conferences (Various)

- **Audience**: IT auditors, risk managers, governance professionals, CISM/CRISC/CGEIT holders
- **Typical attendees**: 500-2,000
- **Session formats**: 50-60 min sessions, panels, workshops
- **What gets accepted**: Risk management practices, audit methodology, governance frameworks, compliance program development, emerging technology risk
- **What gets rejected**: Purely technical content without governance framing, vendor pitches
- **Tone**: Professional, governance-oriented, values structured frameworks
- **Review emphasis**: Relevance to audit/risk practitioners, actionable governance advice
- **CPE opportunity**: Attendees earn CPE credits, which motivates attendance. Speakers gain visibility in the ISACA community.
