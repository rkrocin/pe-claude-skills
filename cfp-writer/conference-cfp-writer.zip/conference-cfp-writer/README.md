# Conference CFP Writer

A [Claude Skill](https://docs.anthropic.com/) that generates compelling conference Call for Papers (CFP) submissions including titles, abstracts, detailed outlines, and speaker bios tailored to specific conferences and audiences.

## What It Does

Describe your talk idea and target conference, and it generates:

- **2-3 Title Options** balancing clarity, specificity, and intrigue
- **Abstract** (200-300 words) structured as hook, story, and takeaway
- **Detailed Outline** with minute-by-minute timing and narrative arc
- **Learning Outcomes** that satisfy review committee criteria
- **Speaker Bio** tailored to the specific talk and conference
- **Notes to Reviewers** positioning the submission for acceptance

## Why

Getting accepted at technical conferences is a skill that compounds over time. Speaking builds professional visibility, strengthens your network, and signals expertise to hiring managers. But most engineers with great stories never submit because the CFP process feels opaque and the blank page is intimidating. This skill eliminates the friction between having something worth saying and actually submitting it.

## Usage

### Specific Conference

```
I want to submit to PlatformCon 2026. My talk idea is about how we scaled 
our IDP adoption from 3% to 60% by building a developer advocacy practice 
instead of mandating usage. 15,000 engineers, regulated FSI environment.
```

### Exploring Ideas

```
I lead platform engineering at a financial services company. I've built an 
IDP serving 15K engineers, deployed GenAI for knowledge search, and manage 
a $50M infrastructure budget. What talks should I propose, and to which 
conferences?
```

### Meetup Talk

```
I need a 20-minute talk for our local IaC user group about managing Terraform 
at enterprise scale. Keep it practical with a demo component.
```

## Conference Profiles

| Category | Conferences Covered |
|----------|-------------------|
| Platform & DevOps | PlatformCon, KubeCon, DevOpsDays, SREcon, Velocity |
| Cloud & Infrastructure | re:Invent, HashiConf, Google Cloud Next, local meetups |
| Security & Compliance | RSA, BSides, fwd:cloudsec, ISACA conferences |
| Leadership & General | QCon, LeadDev, AllDayDevOps, CTO Summit |

Each profile includes what gets accepted, what gets rejected, tone expectations, reviewer priorities, and conference-specific submission guidance.

## Sample CFP Submissions

| File | Conference | Topic |
|------|-----------|-------|
| `sample-cfp-platformcon.md` | PlatformCon 2026 | IDP adoption journey from 3% to 60% with developer advocacy |
| `sample-cfp-devopsdays.md` | DevOpsDays Chicago 2026 | GenAI/RAG deployment for engineering knowledge search |

Both samples include multiple title options, full abstracts, minute-by-minute outlines, tailored bios, and reviewer notes.

## Title Patterns

The skill generates titles using proven patterns:

- **Outcome + Method**: "Eliminating 40,000 Hours of Toil with GenAI-Powered Knowledge Platforms"
- **Journey + Scale**: "From Ticket-Driven to Product-Led: Transforming Infrastructure at Enterprise Scale"
- **Counterintuitive Claim**: "Your Internal Developer Platform Doesn't Need More Features"
- **Specific Number + Lesson**: "5 Things We Learned Scaling an IDP Across 15,000 Engineers"

## Abstract Structure

Every abstract follows a three-paragraph structure:

1. **The Hook** (2-3 sentences): Open with the problem or surprising result
2. **The Story** (3-4 sentences): What happened, with specific numbers and outcomes
3. **The Takeaway** (2-3 sentences): What the audience will learn and why it matters to them

## Narrative Arcs

Talks use one of three narrative structures:

- **Journey Arc**: Before state, inciting event, struggle, breakthrough, results, lesson
- **Myth-Busting Arc**: Common belief, evidence against, alternative, proof, reframe
- **Framework Arc**: Problem space, your model, component deep dives, application, caveats

## Skill Structure

```
conference-cfp-writer/
├── SKILL.md                                        # Skill definition and writing guidance
├── README.md                                       # This file
├── references/
│   ├── platform-devops-conferences.md              # PlatformCon, KubeCon, DevOpsDays, SREcon
│   ├── cloud-infra-conferences.md                  # re:Invent, HashiConf, Cloud Next
│   ├── security-conferences.md                     # RSA, BSides, fwd:cloudsec, ISACA
│   └── leadership-conferences.md                   # QCon, LeadDev, AllDayDevOps, CTO Summit
└── assets/
    ├── sample-cfp-platformcon.md                   # Full CFP: IDP adoption at PlatformCon
    └── sample-cfp-devopsdays.md                    # Full CFP: GenAI/RAG at DevOpsDays Chicago
```

## License

MIT
