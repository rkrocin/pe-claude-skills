---
name: conference-cfp-writer
description: >
  Generate compelling conference Call for Papers (CFP) submissions including titles, abstracts,
  talk outlines, and speaker bios. Use this skill whenever the user wants to submit a talk proposal,
  write a CFP, prepare a conference abstract, draft a speaker bio, brainstorm talk ideas, or
  structure a presentation proposal for a technical conference, meetup, or internal tech talk.
  Also trigger when the user mentions conference speaking, KubeCon, re:Invent, DevOpsDays, QCon,
  PlatformCon, local meetups, or any event with a Call for Papers. Supports keynotes, breakout
  sessions, lightning talks, panels, and workshops.
---

# Conference CFP Writer

Generate compelling conference CFP submissions with titles, abstracts, detailed outlines, learning outcomes, and tailored speaker bios.

## What This Skill Does

Takes a talk idea, target conference, and speaker background, then generates:

1. **Talk Title** with 2-3 options balancing clarity with intrigue
2. **Abstract** calibrated to the conference format and audience
3. **Detailed Outline** with timing, key points, and narrative arc
4. **Learning Outcomes** that satisfy review committee criteria
5. **Speaker Bio** tailored to the specific talk and conference
6. **Submission Notes** (optional) private notes to the review committee

## Gathering Inputs

| Parameter | Required | Description |
|-----------|----------|-------------|
| Talk idea | Yes | What the speaker wants to talk about |
| Target conference | Recommended | Which conference or type of event (helps calibrate tone and depth) |
| Session format | Optional | Keynote, breakout (30-45 min), lightning talk (5-10 min), workshop, panel |
| Speaker experience | Helpful | Professional background, relevant projects, prior speaking |
| Audience level | Optional | Beginner, intermediate, advanced, mixed |
| Unique angle | Helpful | What makes this talk different from others on the same topic |

Accept input at any level of specificity. The user might provide a fully formed pitch or just say "I want to talk about IDPs at PlatformCon." Both work.

## Conference Profiles

Reference files in `references/` contain guidance for specific conference types. Load the relevant one before generating.

| Profile | File | Covers |
|---------|------|--------|
| Platform & DevOps | `references/platform-devops-conferences.md` | PlatformCon, KubeCon, DevOpsDays, Velocity, SREcon |
| Cloud & Infrastructure | `references/cloud-infra-conferences.md` | re:Invent, Google Cloud Next, HashiConf, CloudNativecon |
| Security & Compliance | `references/security-conferences.md` | RSA, BSides, fwd:cloudsec, ISACA conferences |
| Leadership & General | `references/leadership-conferences.md` | QCon, LeadDev, CTO Summit, AllDayDevOps, local meetups |

## Title Generation

Generate 2-3 title options for every submission. Titles should balance:

**Clarity**: The reviewer (and attendee) should know what the talk is about from the title alone. "Lessons from Scaling Our IDP to 15,000 Engineers" is clear. "The Platform Paradox" is not.

**Specificity**: Include a concrete detail that signals depth. Numbers, technologies, or outcomes work well. "How We Cut Deployment Time 60% with Golden Paths" is more compelling than "Improving Developer Experience."

**Intrigue**: Give the audience a reason to choose this talk over competing sessions. A tension, a counterintuitive claim, or a promise of hard-won lessons creates pull. "Why Our Best Platform Decision Was Saying No" creates more curiosity than "Platform Prioritization Strategies."

### Title Patterns That Work

- **Outcome + Method**: "Eliminating 40,000 Hours of Toil with GenAI-Powered Knowledge Platforms"
- **Journey + Scale**: "From Ticket-Driven to Product-Led: Transforming Infrastructure at Enterprise Scale"
- **Counterintuitive Claim**: "Your Internal Developer Platform Doesn't Need More Features"
- **Specific Number + Lesson**: "5 Things We Learned Scaling an IDP Across 15,000 Engineers"
- **Before/After Contrast**: "From 48-Hour Lead Times to Same-Day Deploys: A Platform Engineering Story"

### Title Patterns to Avoid

- **Jargon-only titles**: "Leveraging GitOps-Driven IaC for Multi-Cloud PaaS Orchestration" (unreadable)
- **Question-only titles**: "Is Your Platform Team a Bottleneck?" (implies the talk has no answer)
- **Single-word or overly abstract**: "Velocity" or "The Cloud Native Journey" (says nothing)
- **Clickbait without substance**: "This One Weird Trick for Zero Downtime" (undermines credibility)

## Abstract Writing

The abstract is the most important element. Review committees read hundreds of abstracts, often in a single sitting. A good abstract gets accepted. A mediocre abstract with a great talk behind it gets rejected.

### Abstract Structure (200-300 words)

**Paragraph 1 - The Hook (2-3 sentences):**
Open with the problem, tension, or surprising result. Make the reviewer care in the first sentence. Use specific details, not generalities.

"When our platform team launched an internal developer portal, we expected engineers to adopt it enthusiastically. Instead, adoption stalled at 15% for three months. What we learned about developer experience changed how we build every platform product."

**Paragraph 2 - The Story (3-4 sentences):**
What happened, what you did, and what the outcome was. This is the body of the talk compressed into a paragraph. Include specific, concrete details: numbers, timelines, technologies, team sizes.

**Paragraph 3 - The Takeaway (2-3 sentences):**
What the audience will learn and why it matters to them. Frame this as transferable lessons, not just your specific story. End with a forward-looking statement or call to action.

### Abstract Principles

- **Write for the reviewer first, the attendee second.** Reviewers decide acceptance. They want to know: Is this talk substantive? Is the speaker credible? Will the audience learn something actionable?
- **Be specific.** "We reduced onboarding time" is weak. "We reduced new engineer time-to-first-deploy from 3 weeks to 4 days" is compelling.
- **Show, do not tell.** Do not say "this talk will be practical and engaging." Instead, describe the practical content and let the reviewer judge.
- **Avoid marketing language.** The abstract is not a press release. No "revolutionary," "game-changing," or "best-in-class."
- **Name the technology but do not sell it.** Mention specific tools and approaches (Backstage, Terraform, RAG) but frame them as context, not advocacy.

## Detailed Outline

Generate a minute-by-minute outline appropriate to the session format.

### Breakout Session (30-40 minutes)

```
0:00 - 3:00   Opening: Hook + Context Setting
               [Attention-grabbing opening, establish credibility, frame the problem]

3:00 - 8:00   The Problem / Before State
               [What was broken, with specific evidence]

8:00 - 20:00  The Journey / What We Did
               [2-3 major decisions or phases, each with:
                - What we tried
                - What happened (including failures)
                - What we learned]

20:00 - 28:00 Results / After State
               [Quantified outcomes, before/after comparison]

28:00 - 33:00 Lessons Learned / Transferable Takeaways
               [3-5 specific lessons the audience can apply]

33:00 - 35:00 Closing + Call to Action
               [Summary, resources, how to connect]

35:00 - 40:00 Q&A
```

### Lightning Talk (5-10 minutes)

```
0:00 - 1:00   Hook: one sentence that captures the entire talk
1:00 - 3:00   Problem + context (compressed)
3:00 - 7:00   Key insight or lesson (ONE main point, not three)
7:00 - 8:00   Evidence / proof point
8:00 - 9:00   Takeaway + call to action
9:00 - 10:00  Close (no Q&A in lightning format)
```

### Workshop (90-180 minutes)

```
0:00 - 10:00   Introduction: goals, prerequisites, environment setup verification
10:00 - 20:00  Context: why this topic matters, what we are building
20:00 - 50:00  Module 1: [First hands-on exercise with guided steps]
50:00 - 60:00  Break + troubleshooting
60:00 - 90:00  Module 2: [Second exercise building on Module 1]
90:00 - 100:00 Break
100:00 - 130:00 Module 3: [Advanced exercise or freestyle]
130:00 - 150:00 Wrap-up: review what was built, next steps, resources
```

## Narrative Arc

Every good technical talk follows a narrative arc, not a list of bullet points.

### The Journey Arc (most common, best for experience-based talks)
1. **The world before**: What existed, what was broken, what the constraints were
2. **The inciting event**: What forced change (growth, incident, acquisition, mandate)
3. **The struggle**: What you tried, including what failed
4. **The breakthrough**: What worked and why
5. **The new world**: Results, metrics, what changed
6. **The lesson**: What the audience can take home

### The Myth-Busting Arc (good for contrarian or counterintuitive talks)
1. **The common belief**: What everyone assumes is true
2. **The evidence against**: What your experience revealed
3. **The alternative**: What actually works
4. **The proof**: Results from the alternative approach
5. **The reframe**: How the audience should think about this differently

### The Framework Arc (good for teaching or methodology talks)
1. **The problem space**: Why this is hard and why existing approaches fall short
2. **The framework**: Your model or approach (3-5 components)
3. **Component deep dives**: Each component with examples
4. **Application**: How to apply the framework in their context
5. **Caveats and limitations**: When this does NOT work

## Learning Outcomes

Most CFPs require explicit learning outcomes. Write 3-4 outcomes using active verbs:

**Good learning outcomes:**
- "Attendees will be able to design a phased IDP adoption strategy that avoids the 'build it and they will come' trap"
- "Attendees will learn how to quantify developer experience improvements in terms that resonate with executive stakeholders"
- "Attendees will understand the tradeoffs between Backstage, Port, and custom-built developer portals for regulated environments"

**Weak learning outcomes:**
- "Attendees will learn about platform engineering" (too vague)
- "Attendees will understand the importance of developer experience" (not actionable)
- "Attendees will hear our story" (not a learning outcome)

## Speaker Bio

Tailor the bio to the specific talk and conference. A bio for a security conference emphasizes different credentials than a bio for a platform engineering conference.

### Bio Structure (100-150 words)

**Sentence 1**: Current role and scope (establishes credibility)
**Sentence 2**: Relevant accomplishment that connects to the talk topic (proves you have done this)
**Sentence 3**: Career context or unique perspective (what makes your viewpoint distinctive)
**Sentence 4**: Community involvement or speaking experience (signals engagement beyond day job)

### Bio Principles

- Lead with the credential most relevant to the talk, not the most impressive overall
- Include specific numbers where possible (team size, platform scale, users served)
- Mention community involvement (meetup organizer, open source contributor)
- Keep it under 150 words; reviewers skim bios
- Write in third person (most CFPs expect this)

## Submission Notes

Many CFPs have a "notes to reviewers" field. Use this to:
- Mention prior speaking experience at similar events
- Note if this is a new talk or an iteration of a previously delivered talk
- Offer to adjust scope, duration, or audience level
- Mention any A/V or logistical requirements
- Link to videos of prior talks if available

## Edge Cases

- **First-time speaker**: Emphasize the substance of the content rather than speaking history. Many conferences actively seek new speakers. Note in submission notes that this is a first submission if the conference has a mentorship program.
- **Multiple submissions**: If the user wants to submit multiple talks to the same conference, generate distinct proposals that do not overlap in content. Note which talk to prioritize if the conference typically accepts one per speaker.
- **Internal tech talk**: Simplify the format. Skip the bio and learning outcomes. Focus on the outline and key takeaways. Internal talks can be more candid about failures and specific tooling.
- **Panel submission**: Generate a panel description, 3-4 discussion questions, moderator guidance, and suggested panelist profiles rather than a single-speaker outline.
- **Co-presented talk**: Note both speakers in the bio and clarify who covers which sections in the outline.
