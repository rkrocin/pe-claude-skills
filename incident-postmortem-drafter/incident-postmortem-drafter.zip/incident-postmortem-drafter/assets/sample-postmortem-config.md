# Incident Postmortem: Payments API Outage Due to Unvalidated Configuration Change

**Date**: March 28, 2026
**Author**: Platform Engineering
**Status**: Action Items In Progress
**Severity**: SEV2 - Major

---

## Summary

A configuration change deployed to the payments API at 23:15 CT contained an invalid database connection string, causing 30% of payment transactions to fail with 500 errors for 40 minutes. Approximately 2,100 transactions failed before the configuration was rolled back at 23:52 CT. The incident was detected by automated alerting within 5 minutes of impact onset, and the on-call engineer began investigation within 2 minutes of the page. Resolution was delayed by 15 minutes because the rollback process was manual and required verifying the previous configuration version.

**Duration**: 40 minutes (23:15 to 23:55 CT)
**Time to Detect (TTD)**: 5 minutes
**Time to Mitigate (TTM)**: 17 minutes (from page to rollback initiated)
**Time to Resolve (TTR)**: 20 minutes (from page to service fully recovered)

---

## Severity & Impact

**Severity**: SEV2 - Major
Classified as SEV2 based on partial service degradation affecting revenue-generating transactions for more than 10 minutes.

**User Impact**:
- Approximately 2,100 payment transactions failed with HTTP 500 errors during the 40-minute window
- 30% of total transaction volume was affected (customers routed to the affected service instances)
- 70% of traffic was unaffected due to healthy instances continuing to serve requests with cached connections
- Affected customers received a generic error message with no retry guidance

**Business Impact**:
- Estimated $47,000 in failed transactions during the window
- Majority of affected transactions were retried successfully by customers after recovery
- No SLA breach (monthly SLA allows 43 minutes of downtime; this consumed 40 minutes of the monthly budget)
- One enterprise partner contacted support during the incident

**Systems Affected**:
- payments-api (direct impact)
- payments-db connection pool (connection failures triggered the 500s)
- transaction-ledger (downstream, received reduced volume but no errors)

---

## Timeline

All times in Central Time (CT).

| Time | Event | Source |
|------|-------|--------|
| 23:10 | Configuration change PR submitted for payments-api database connection parameters | GitHub |
| 23:12 | PR merged without peer review (auto-merge enabled for config repo) | GitHub |
| 23:15 | Configuration deployed to production via CI/CD pipeline | GitHub Actions |
| 23:15 | New payments-api instances begin starting with invalid connection string | ECS deployment log |
| 23:18 | New instances fail health checks; ECS continues routing to healthy instances while rolling deployment proceeds | ECS service events |
| 23:25 | Rolling deployment reaches 30% of instances; error rate crosses 5% threshold | CloudWatch |
| 23:30 | Error rate alert fires at 30% threshold | PagerDuty |
| 23:32 | On-call engineer acknowledges page, opens CloudWatch dashboard | PagerDuty, Slack |
| 23:35 | On-call identifies elevated 500s on payments-api, begins investigating application logs | Slack incident channel |
| 23:38 | Database connection errors identified in logs; on-call suspects connection string issue | Slack incident channel |
| 23:40 | On-call reviews recent deployments, identifies config change from 23:15 | GitHub deploy history |
| 23:42 | On-call identifies typo in connection string (port number transposed) | GitHub diff |
| 23:44 | On-call begins manual rollback: identifying previous config version in parameter store | Slack incident channel |
| 23:48 | Incident escalated to payments team lead for awareness | Slack incident channel |
| 23:52 | Previous configuration version deployed; new ECS deployment initiated | GitHub Actions |
| 23:55 | Healthy instances confirmed, error rate returns to baseline | CloudWatch |
| 23:57 | All-clear declared in incident channel | Slack incident channel |
| 00:15 | Post-incident Slack thread opened for initial observations | Slack |

---

## Contributing Factors

### Immediate Trigger
A configuration change to the payments-api database connection string contained a transposed port number (5423 instead of 5432). The change was deployed to production, and new service instances launched with the invalid connection string.

### Enabling Conditions

1. **No configuration validation in the deployment pipeline**: The CI/CD pipeline for configuration changes does not validate connection strings, API endpoints, or other structured values before deployment. A syntactically valid but semantically incorrect value passed through without any check.

2. **Auto-merge enabled on the configuration repository**: The config repository allowed PRs to be merged without peer review. This was originally enabled to reduce friction for routine config updates but eliminated the human review step that would likely have caught the typo.

3. **No pre-deployment smoke test**: The deployment pipeline does not include a step that verifies the new configuration can successfully connect to downstream dependencies before proceeding with the rolling deployment.

### Amplifying Factors

1. **Manual rollback process**: Rolling back the configuration required the on-call engineer to manually identify the previous version in AWS Parameter Store and trigger a new deployment. This added approximately 10 minutes to the resolution time compared to an automated rollback capability.

2. **Generic customer error message**: Affected customers received a generic "Something went wrong" error with no retry guidance or estimated recovery time. This generated support contacts that consumed additional team bandwidth.

3. **Alert threshold set at 30% error rate**: The error rate alert was configured to fire at 30%, which meant the incident was not detected until 30% of instances were affected. A lower threshold (5-10%) would have triggered the alert 5-7 minutes earlier, during the rolling deployment window when fewer instances were impacted.

---

## Resolution

**Immediate mitigation**: The on-call engineer identified the invalid configuration, retrieved the previous version from AWS Parameter Store, and deployed it via the existing CI/CD pipeline. New ECS instances launched with the corrected connection string and passed health checks.

**Verification**: CloudWatch error rate dashboard confirmed return to baseline (<0.1%) within 3 minutes of the corrected deployment completing. The on-call verified database connectivity by checking active connection counts in the RDS console.

**Permanent fix**: Captured in action items below. The immediate fix only reverted the bad configuration; the systemic enabling conditions remain.

---

## Lessons Learned

### What Went Well
- **Alerting fired within the expected window.** The PagerDuty alert triggered 5 minutes after error rate began increasing, within the configured evaluation window. Detection was automated, not customer-reported.
- **On-call response was fast.** The on-call engineer acknowledged the page within 2 minutes and correctly diagnosed the issue within 10 minutes of starting investigation.
- **Impact was contained by the rolling deployment model.** Because ECS performs rolling deployments, only 30% of instances had rotated to the bad configuration before the alert fired. Full fleet deployment would have caused a complete outage.
- **Incident communication was clear.** The on-call opened an incident channel promptly and provided regular updates, allowing the payments team lead to stay informed without interrupting the investigation.

### What Went Poorly
- **No config validation caught the error.** A typo in a connection string is one of the most common deployment errors, and the pipeline had no check for it.
- **Rollback was manual and slow.** The on-call had to search for the previous config version and trigger a deployment manually. An automated rollback on health check failure would have resolved the incident in under 5 minutes.
- **Alert threshold was too high.** Waiting until 30% error rate meant the incident was well underway before anyone was notified. Earlier detection during the rolling deployment could have limited impact to the first few instances.
- **No peer review on the config change.** Auto-merge eliminated the simplest possible check: another human looking at the change.

### Where We Got Lucky
- **The incident occurred at 23:15 CT (low traffic).** Peak payment volume occurs between 10:00-14:00 CT. If this had happened during peak, approximately 10x more transactions would have failed.
- **The rolling deployment was only 30% complete.** If the deployment had completed before the alert fired (possible with a faster deployment cadence), 100% of traffic would have been affected.
- **The on-call engineer had recently worked on the payments-api.** A different on-call without this context would likely have taken longer to diagnose the connection string issue.

---

## Action Items

| Priority | Action | Contributing Factor | Owner | Deadline | Status |
|----------|--------|-------------------|-------|----------|--------|
| P1 | Implement connection string validation in the config deployment pipeline (verify format, test connectivity before deploy) | No config validation | Platform Engineering | April 11, 2026 | Open |
| P1 | Require peer review on all config changes (disable auto-merge on config repo) | Auto-merge enabled | Platform Engineering | April 4, 2026 | Open |
| P1 | Implement automated rollback on health check failure during config deployments | Manual rollback process | Platform Engineering | April 18, 2026 | Open |
| P2 | Lower payments-api error rate alert threshold from 30% to 5% | Alert threshold too high | SRE | April 7, 2026 | Open |
| P2 | Add pre-deployment smoke test that validates downstream connectivity before proceeding with rolling deployment | No pre-deployment smoke test | Platform Engineering | April 25, 2026 | Open |
| P3 | Improve customer error messaging to include retry guidance and estimated recovery time | Generic error message | Payments Engineering | May 9, 2026 | Open |

---

## Appendix

### Supporting Data
- CloudWatch error rate dashboard: [link]
- ECS deployment events: [link]
- GitHub PR for the config change: [link]
- PagerDuty incident: [link]
- Slack incident channel archive: #inc-2026-03-28-payments-api

### Related Incidents
- None identified. This is the first configuration-related outage for payments-api. However, a similar unvalidated config issue affected the notification service in January 2026 (INC-2026-01-15). The lack of config validation is a systemic pattern, not isolated to this service.
