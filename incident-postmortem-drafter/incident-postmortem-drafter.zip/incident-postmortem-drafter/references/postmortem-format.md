# Postmortem Format Reference

## Standard Template

```markdown
# Incident Postmortem: [Concise Title Describing What Happened]

**Date**: [Incident date]
**Author**: [Postmortem author]
**Status**: [Draft | Final | Action Items In Progress | Closed]
**Severity**: [SEV1 | SEV2 | SEV3 | SEV4]

---

## Summary

[2-3 sentences: what happened, what the impact was, how long it lasted. This should
be readable by someone with no context and give them the essential picture in 10 seconds.]

**Duration**: [Total incident duration from trigger to all-clear]
**Time to Detect (TTD)**: [Time from trigger to first alert or human awareness]
**Time to Mitigate (TTM)**: [Time from first awareness to impact mitigated]
**Time to Resolve (TTR)**: [Time from first awareness to root cause addressed]

---

## Severity & Impact

**Severity**: [Classification with rationale]

**User Impact**:
- [Number of affected users or percentage of traffic]
- [Nature of impact: errors, latency, data issues, feature unavailability]
- [Geographic or segment-specific impact if applicable]

**Business Impact**:
- [Revenue impact if quantifiable]
- [SLA/SLO impact: error budget consumed, SLA breach]
- [Reputational impact if applicable]

**Systems Affected**:
- [List of services, databases, infrastructure components involved]

---

## Timeline

All times in [timezone].

| Time | Event | Source |
|------|-------|--------|
| HH:MM | [Triggering event] | [How we know] |
| HH:MM | [Detection / first alert] | [Alert system] |
| HH:MM | [First human response] | [PagerDuty / Slack] |
| HH:MM | [Investigation step or communication] | [Source] |
| HH:MM | [Mitigation action taken] | [Deploy log / CLI] |
| HH:MM | [Impact mitigated / service recovering] | [Monitoring] |
| HH:MM | [All clear declared] | [Incident channel] |

---

## Contributing Factors

### Immediate Trigger
[The specific event that initiated the incident]

### Enabling Conditions
1. **[Factor name]**: [Description of the systemic weakness that allowed the trigger 
   to cause an incident]
2. **[Factor name]**: [Description]
3. **[Factor name]**: [Description]

### Amplifying Factors
1. **[Factor name]**: [What made the incident worse or longer than necessary]
2. **[Factor name]**: [Description]

---

## Resolution

**Immediate mitigation**: [What was done to stop the bleeding]

**Verification**: [How we confirmed the mitigation worked]

**Permanent fix** (if different from mitigation): [What was done to address the 
underlying issue, or note that this is captured in action items]

---

## Lessons Learned

### What Went Well
- [Positive observation about the response]
- [Another positive observation]

### What Went Poorly
- [Negative observation about the response]
- [Another negative observation]

### Where We Got Lucky
- [Thing that limited blast radius by chance, not design]
- [Another lucky break]

---

## Action Items

| Priority | Action | Contributing Factor | Owner | Deadline | Status |
|----------|--------|-------------------|-------|----------|--------|
| P1 | [Specific action] | [Which factor this addresses] | [Team] | [Date] | Open |
| P1 | [Specific action] | [Which factor this addresses] | [Team] | [Date] | Open |
| P2 | [Specific action] | [Which factor this addresses] | [Team] | [Date] | Open |
| P2 | [Specific action] | [Which factor this addresses] | [Team] | [Date] | Open |
| P3 | [Specific action] | [Which factor this addresses] | [Team] | [Date] | Open |

---

## Appendix

### Supporting Data
- [Links to dashboards, graphs, or screenshots from during the incident]
- [Links to relevant Slack threads or incident channel archives]
- [Links to deploy logs or change records]

### Related Incidents
- [Links to prior postmortems if this is a recurring pattern]

### Regulatory Notifications
- [Any required notifications sent (for regulated environments)]
```

## Title Conventions

Good postmortem titles describe what happened, not the technical cause:

- "Payments API Outage Due to Configuration Error" (clear impact + cause)
- "30-Minute Degradation of Customer Login Service" (clear impact + duration)
- "Data Processing Pipeline Stall Affecting Daily Reports" (clear impact + affected system)

Avoid:
- "SEV2 Incident" (says nothing)
- "Database Issue" (too vague)
- "Prod Is Down" (Slack message, not a title)

## Writing Tone

The postmortem should read as a factual, dispassionate account of what happened and what the organization learned. It is not a blame document, an apology, or a narrative with heroes and villains.

- Use past tense throughout
- Refer to people by role, not name (unless instructed otherwise)
- State facts, not opinions, in the timeline and contributing factors
- Save judgment for the lessons learned section
- Be specific: "error rate increased from 0.1% to 34% over 3 minutes" not "errors spiked significantly"
- Quantify impact wherever possible

## Review Process

A good postmortem practice includes:

1. **Draft within 48 hours** while memory is fresh
2. **Review with incident participants** to verify timeline accuracy
3. **Share with the broader team** for learning (not just the responders)
4. **Track action items** in the team's work management system (Jira, Linear, etc.)
5. **Review action item completion** in a follow-up meeting (2-4 weeks later)
6. **Close the postmortem** only when all P1 and P2 action items are verified complete
