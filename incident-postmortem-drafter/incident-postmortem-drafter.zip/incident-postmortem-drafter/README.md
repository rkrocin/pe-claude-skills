# Incident Postmortem Drafter

A [Claude Skill](https://docs.anthropic.com/) that generates blameless incident postmortem documents from incident timeline data, with contributing factor analysis, action items, and lessons learned.

## What It Does

Describe what happened during a production incident and it generates:

- **Incident Summary** with severity classification, duration metrics (TTD, TTM, TTR), and impact quantification
- **Timeline Reconstruction** as a chronological table with event sources
- **Contributing Factor Analysis** identifying systemic causes (not individual blame)
- **Lessons Learned** structured as what went well, what went poorly, and where you got lucky
- **Action Items** prioritized with owners, deadlines, and mapping to contributing factors
- **Leadership Summary** (optional) condensed for VP/CIO reporting

## Why

Every engineering organization writes postmortems after incidents. Most do it inconsistently: different formats, different depth, different quality depending on who writes them. Some teams skip them entirely when they are busy. The result is lost organizational learning and recurring incidents.

This skill eliminates the blank-page problem. Provide the incident details in whatever format you have (Slack thread, bullet points, structured data) and get a well-structured postmortem back. The consistent format ensures every incident gets the same analytical rigor, and the blameless framing is built into the skill so teams do not have to remember to practice it under stress.

## Core Principle: Blameless

Every postmortem follows the blameless philosophy:

- People are never the root cause. Systems, processes, tooling, and information gaps are.
- Individuals are referred to by role, not name
- "The monitoring gap allowed the issue to persist" rather than "the team failed to monitor"
- Human error is always a symptom of a deeper systemic issue

## Usage

### From Informal Notes

```
Last night at 11:30pm our payments API started returning 500s. About 30% 
of transactions were failing. On-call got paged at 11:35pm. Turned out a 
config change from 11:15pm had a typo in the database connection string. 
Rolled back at 11:52pm, recovered by 11:55pm. About 2,000 transactions 
failed. No config validation in the pipeline and the change went through 
without review. Write a postmortem.
```

### From Structured Data

```json
{
  "title": "Auth service cascade failure",
  "severity": "SEV1",
  "start": "2026-04-02T14:12:00-05:00",
  "end": "2026-04-02T14:35:00-05:00",
  "impact": "100% authentication failure, 180K users affected",
  "timeline": [
    {"time": "13:45", "event": "Marketing push notification sent to 2M customers"},
    {"time": "14:08", "event": "DB connection pool exhausted"},
    {"time": "14:12", "event": "Retry storm from downstream services"}
  ]
}
```

### Leadership Summary Only

```
Generate a leadership summary for this incident for the VP of Engineering. 
[paste incident details]
```

## Sample Postmortems

| File | Scenario | Severity |
|------|----------|----------|
| `sample-postmortem-config.md` | Configuration typo causes payments API partial outage | SEV2 |
| `sample-postmortem-cascade.md` | Traffic spike triggers cascade failure across authentication and downstream services | SEV1 |

The SEV2 sample demonstrates a straightforward incident with clear contributing factors and focused action items. The SEV1 sample demonstrates a complex cascade failure with retry storms, a failed first mitigation attempt, parallel resolution tracks, and a leadership summary.

## Severity Classification

| Severity | Criteria | Postmortem Timeline |
|----------|----------|-------------------|
| SEV1 - Critical | Complete outage, data loss, security breach | Within 48 hours |
| SEV2 - Major | Partial outage, >10% users affected, SLA breach | Within 1 week |
| SEV3 - Minor | Limited degradation, workaround available | Within 2 weeks |
| SEV4 - Low | No user-facing impact | Optional |

## Contributing Factor Model

The skill uses a contributing factor model instead of "root cause analysis" because incidents rarely have a single root cause:

- **Immediate trigger**: The specific event that started the incident
- **Enabling conditions**: Systemic weaknesses that allowed the trigger to cause an incident (missing guardrails, observability gaps, process gaps)
- **Amplifying factors**: Things that made the incident worse or longer (retry storms, slow rollback, communication gaps)

Every contributing factor maps to at least one action item. If it does not, the factor is either too broad or the action item is missing.

## Action Item Framework

| Priority | Meaning | Timeline |
|----------|---------|----------|
| P1 | Prevents recurrence of this specific incident | Within 1 sprint |
| P2 | Reduces blast radius or detection time | Within 1 month |
| P3 | Improves systemic resilience | Within 1 quarter |

Action items are capped at 5-8 per postmortem. More than that and nothing gets done.

## Skill Structure

```
incident-postmortem-drafter/
├── SKILL.md                              # Skill definition and blameless principles
├── README.md                             # This file
├── references/
│   └── postmortem-format.md              # Full template, writing guidelines, review process
└── assets/
    ├── sample-postmortem-config.md        # SEV2: Config change outage
    └── sample-postmortem-cascade.md       # SEV1: Cascade failure with retry storm
```

## License

MIT
