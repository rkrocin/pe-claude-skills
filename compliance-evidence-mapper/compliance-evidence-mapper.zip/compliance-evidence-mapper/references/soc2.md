# SOC 2 Type II - Trust Services Criteria (Infrastructure Layer)

Trust Services Criteria relevant to cloud infrastructure and platform engineering. Organized by the five trust principles. Criteria that are purely organizational policy with no infrastructure component are excluded.

## Security (Common Criteria)

### CC6.1: Logical and physical access controls to protect information assets
- **Category**: Access Control
- **Evidence expectations**: IAM policies, RBAC configuration, network segmentation, encryption configuration, access provisioning procedures
- **Common controls**: AWS IAM with least-privilege policies, VPC security groups, KMS encryption, SSO with MFA

### CC6.2: User registration and authorization procedures
- **Category**: Access Management
- **Evidence expectations**: User provisioning/deprovisioning process, role assignment procedures, approval workflows
- **Common controls**: SSO provisioning via SCIM, IAM role assignment via Terraform, onboarding/offboarding checklists

### CC6.3: Access removed when no longer required
- **Category**: Access Management
- **Evidence expectations**: Deprovisioning procedures, access review evidence, automated deactivation, orphaned account detection
- **Common controls**: SSO deprovisioning, quarterly access reviews, IAM Access Analyzer, automated access certification

### CC6.6: Security measures against threats outside system boundaries
- **Category**: Network Security
- **Evidence expectations**: Firewall/WAF configuration, DDoS protection, intrusion detection, edge security
- **Common controls**: AWS WAF, CloudFront with security headers, Shield Advanced, GuardDuty

### CC6.7: Restrict data transmission, movement, and removal
- **Category**: Data Protection
- **Evidence expectations**: Data transfer encryption, DLP controls, data classification, exfiltration prevention
- **Common controls**: TLS enforcement, VPC endpoints, S3 bucket policies blocking public access, GuardDuty S3 protection

### CC6.8: Prevent unauthorized or malicious software
- **Category**: Malware Prevention
- **Evidence expectations**: Container scanning, dependency scanning, code review processes, endpoint protection
- **Common controls**: ECR scan-on-push, Trivy in CI/CD, SAST scanning, host-based agents

### CC7.1: Monitoring procedures detect security events
- **Category**: Monitoring
- **Evidence expectations**: Monitoring tool configurations, alert rules, SIEM integration, detection coverage
- **Common controls**: GuardDuty, CloudWatch alarms, Security Hub, VPC flow logs, centralized logging

### CC7.2: Monitoring includes detection of unusual activity and anomalies
- **Category**: Monitoring
- **Evidence expectations**: Anomaly detection configurations, baseline definitions, alert thresholds, investigation procedures
- **Common controls**: GuardDuty anomaly detection, CloudTrail Insights, CloudWatch anomaly detection, custom alert rules

### CC7.3: Security events evaluated to determine if incidents
- **Category**: Incident Management
- **Evidence expectations**: Triage procedures, severity classifications, investigation workflows, escalation criteria
- **Common controls**: PagerDuty escalation policies, incident classification matrix, IR runbooks, triage procedures

### CC7.4: Incidents responded to according to defined procedures
- **Category**: Incident Response
- **Evidence expectations**: IR plan, response procedures, communication templates, post-incident review process
- **Common controls**: IR runbooks, PagerDuty integrations, incident communication channels, postmortem process

### CC7.5: Root cause identified and remediation actions taken
- **Category**: Incident Response
- **Evidence expectations**: Postmortem documents, root cause analyses, remediation tracking, follow-up verification
- **Common controls**: Blameless postmortem process, Jira tracking of remediation items, postmortem review cadence

### CC8.1: Changes to infrastructure and software authorized, designed, developed, tested
- **Category**: Change Management
- **Evidence expectations**: Change management procedures, approval workflows, testing evidence, deployment records
- **Common controls**: GitHub PR approvals, CI/CD pipeline with test gates, Terraform plan/apply workflow, change advisory board

## Availability

### A1.1: System availability commitments defined and monitored
- **Category**: Availability
- **Evidence expectations**: SLAs/SLOs, uptime monitoring, availability reports, escalation for availability incidents
- **Common controls**: CloudWatch synthetics, SLO dashboards, status pages, availability alerting

### A1.2: Environmental protections, data backups, and recovery infrastructure
- **Category**: Disaster Recovery
- **Evidence expectations**: Backup configurations, recovery procedures, DR testing evidence, RTO/RPO definitions
- **Common controls**: RDS automated backups, S3 cross-region replication, EBS snapshots, DR runbooks, annual DR tests

### A1.3: Recovery plan procedures tested periodically
- **Category**: Disaster Recovery
- **Evidence expectations**: DR test plans, test execution records, test results, remediation of test findings
- **Common controls**: Annual DR tests, documented test outcomes, remediation tracking

## Confidentiality

### C1.1: Confidential information identified and protected
- **Category**: Data Protection
- **Evidence expectations**: Data classification scheme, encryption of confidential data at rest and in transit, access restrictions
- **Common controls**: Data classification tags, KMS encryption, TLS enforcement, IAM access policies scoped to data classification

### C1.2: Confidential information disposed of securely
- **Category**: Data Lifecycle
- **Evidence expectations**: Data retention policies, secure deletion procedures, S3 lifecycle policies, database purge schedules
- **Common controls**: S3 lifecycle rules, RDS snapshot retention, data purge automation, certificate of destruction for decommissioned hardware

## Processing Integrity

### PI1.1: Processing completeness, accuracy, timeliness, and authorization
- **Category**: Processing Controls
- **Evidence expectations**: Input validation, processing reconciliation, error handling, batch job completion monitoring
- **Common controls**: Application input validation, batch job monitoring and alerting, reconciliation reports, data quality checks

## Privacy

### P6.1: Personal information retained only as necessary
- **Category**: Data Retention
- **Evidence expectations**: Retention policies, automated purge configurations, retention schedule compliance evidence
- **Common controls**: S3 lifecycle policies, database TTL configurations, automated PII purge jobs, retention policy documentation
