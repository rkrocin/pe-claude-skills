# PCI DSS v4.0 - Infrastructure Layer Requirements

Requirements from PCI DSS v4.0 as they apply to cloud infrastructure and platform engineering. Application-layer and organizational policy requirements that have no infrastructure component are excluded.

## Requirement 1: Network Security Controls

### 1.2.1: Network segmentation between CDE and non-CDE
- **Category**: Network Security
- **Evidence expectations**: Network diagrams showing CDE boundary, security group rules, VPC/subnet configurations, firewall rules demonstrating traffic restriction
- **Common controls**: VPC segmentation, dedicated CDE subnets, security groups with explicit deny, NACLs

### 1.2.5: All services, protocols, and ports identified and authorized
- **Category**: Network Security
- **Evidence expectations**: Documented inventory of allowed ports/protocols, security group rules matching the inventory, periodic review evidence
- **Common controls**: Security group documentation, Terraform configurations, port scanning reports

### 1.3.1: Inbound traffic restricted to necessary communications
- **Category**: Network Security
- **Evidence expectations**: Security group ingress rules showing only required source/port combinations, no 0.0.0.0/0 on sensitive ports
- **Common controls**: Security group configurations, WAF rules, ALB listener configurations

### 1.3.2: Outbound traffic restricted to necessary communications
- **Category**: Network Security
- **Evidence expectations**: Security group egress rules, NAT gateway configurations, proxy configurations for internet-bound traffic
- **Common controls**: Egress security groups, VPC endpoints for AWS services, outbound proxy

### 1.4.1: NSCs implemented between trusted and untrusted networks
- **Category**: Network Security
- **Evidence expectations**: Architecture diagrams showing trust boundaries, firewall/security group rules at each boundary
- **Common controls**: ALB/WAF at internet boundary, security groups between tiers, VPC peering controls

## Requirement 2: Secure Configuration Standards

### 2.2.1: Configuration standards developed for all system components
- **Category**: Secure Configuration
- **Evidence expectations**: Documented configuration standards (hardening guides), evidence of application (IaC templates, AMI build configs, container base images)
- **Common controls**: Terraform modules with security defaults, hardened AMIs, CIS-benchmarked base images, container scanning

### 2.2.7: All non-console administrative access encrypted with strong cryptography
- **Category**: Secure Configuration
- **Evidence expectations**: SSH key management, SSM Session Manager configurations, bastion host configurations, TLS enforcement
- **Common controls**: SSM Session Manager (no SSH), certificate-based authentication, encrypted admin channels

## Requirement 3: Protect Stored Account Data

### 3.5.1: Stored account data rendered unreadable via cryptography
- **Category**: Data Protection
- **Evidence expectations**: Encryption configuration on all data stores (S3, RDS, EBS, DynamoDB), KMS key policies, key rotation evidence
- **Common controls**: AWS KMS with CMK, storage_encrypted=true on RDS, S3 SSE-KMS, EBS encryption

### 3.6.1: Cryptographic key management procedures defined and implemented
- **Category**: Key Management
- **Evidence expectations**: KMS key policies, key rotation configuration, key access audit logs, documented key management procedures
- **Common controls**: AWS KMS automatic key rotation, key policy restricting access to CDE roles, CloudTrail logging of key usage

## Requirement 4: Protect Data in Transit

### 4.2.1: Strong cryptography used for data transmission over open networks
- **Category**: Data in Transit
- **Evidence expectations**: TLS configuration on load balancers, API gateways, and inter-service communication. Certificate management. Minimum TLS version enforcement.
- **Common controls**: ALB with TLS 1.2+ policy, ACM certificates, RDS SSL enforcement, API Gateway TLS configuration

## Requirement 5: Protect Against Malware

### 5.2.1: Anti-malware solution deployed on systems commonly affected
- **Category**: Malware Protection
- **Evidence expectations**: Endpoint protection on EC2 instances, container image scanning, malware scanning on file uploads
- **Common controls**: Container image scanning (Trivy, ECR scanning), GuardDuty malware protection, host-based agents

### 5.3.1: Anti-malware mechanisms kept current
- **Category**: Malware Protection
- **Evidence expectations**: Automated update evidence, scan schedule configuration, alert configuration for outdated definitions
- **Common controls**: Automated ECR scan-on-push, CI/CD vulnerability scanning, automated agent updates

## Requirement 6: Develop and Maintain Secure Systems

### 6.2.4: Software engineering techniques prevent common vulnerabilities
- **Category**: Secure Development
- **Evidence expectations**: SAST/DAST scan configurations, CI/CD pipeline security gates, dependency vulnerability scanning
- **Common controls**: Semgrep/SonarQube in CI/CD, Snyk/Trivy dependency scanning, pre-merge security gates

### 6.3.1: Security vulnerabilities identified and managed
- **Category**: Vulnerability Management
- **Evidence expectations**: Vulnerability scanning tools and schedules, remediation SLAs, tracking and closure evidence
- **Common controls**: Qualys/Nessus scanning, ECR image scanning, AWS Inspector, vulnerability tracking in Jira

### 6.3.3: Critical and high security patches installed within defined timeframe
- **Category**: Patch Management
- **Evidence expectations**: Patch management policy, evidence of patching cadence, automated patching configurations
- **Common controls**: SSM Patch Manager, automated AMI rebuilds, container base image update pipelines

## Requirement 7: Restrict Access by Business Need

### 7.2.1: Access control system covers all system components
- **Category**: Access Control
- **Evidence expectations**: IAM policies, role definitions, RBAC configuration, access provisioning/deprovisioning procedures
- **Common controls**: AWS IAM roles and policies managed via Terraform, SSO integration, RBAC

### 7.2.2: Access assigned based on job classification and function
- **Category**: Access Control
- **Evidence expectations**: Role definitions mapped to job functions, access review evidence, least-privilege policy documents
- **Common controls**: IAM role separation (dev/ops/admin), Terraform-managed role assignments, quarterly access reviews

### 7.2.5: Access rights reviewed periodically
- **Category**: Access Control
- **Evidence expectations**: Access review schedule, review completion evidence, access modification/revocation records
- **Common controls**: Quarterly access reviews, IAM Access Analyzer findings, automated access certification

## Requirement 8: Identify Users and Authenticate Access

### 8.3.1: All user access authenticated with at least one authentication factor
- **Category**: Authentication
- **Evidence expectations**: Authentication configuration, SSO/MFA enforcement, service account management
- **Common controls**: Okta/Azure AD SSO, MFA enforcement, IAM policies requiring MFA

### 8.3.6: MFA required for all access into the CDE
- **Category**: Authentication
- **Evidence expectations**: MFA configuration on all CDE access paths, conditional access policies, VPN MFA
- **Common controls**: SSO with mandatory MFA, AWS IAM MFA conditions, VPN MFA enforcement

### 8.6.1: Interactive use of system and application accounts managed
- **Category**: Authentication
- **Evidence expectations**: Service account inventory, rotation policies, monitoring for interactive use of service accounts
- **Common controls**: IAM role-based access (no static keys), Secrets Manager rotation, CloudTrail monitoring

## Requirement 10: Log and Monitor All Access

### 10.2.1: Audit logs capture all individual user access to cardholder data
- **Category**: Audit Logging
- **Evidence expectations**: CloudTrail configuration, application audit logging, data access logging on data stores
- **Common controls**: CloudTrail multi-region, S3 access logging, RDS audit logging, application-level access logs

### 10.2.2: Audit logs capture all actions taken by any individual with admin access
- **Category**: Audit Logging
- **Evidence expectations**: CloudTrail management events, console sign-in logging, privileged action alerting
- **Common controls**: CloudTrail with management events, CloudWatch alarms on root/admin activity

### 10.3.1: Audit log files protected from modification
- **Category**: Log Integrity
- **Evidence expectations**: CloudTrail log file validation, S3 bucket policies preventing log deletion, MFA-delete on log buckets
- **Common controls**: CloudTrail log file validation, S3 Object Lock, bucket policies restricting delete

### 10.4.1: Audit logs reviewed at least daily
- **Category**: Log Monitoring
- **Evidence expectations**: Automated log analysis configuration, alert rules, daily review procedures, SIEM integration
- **Common controls**: CloudWatch Logs Insights, GuardDuty, Security Hub, SIEM integration, automated alerting

### 10.5.1: Audit log history retained for at least 12 months
- **Category**: Log Retention
- **Evidence expectations**: Log retention configuration, S3 lifecycle policies for log archives, retention policy documentation
- **Common controls**: CloudWatch log retention settings, S3 lifecycle policies, Glacier archival

## Requirement 11: Test Security Regularly

### 11.3.1: Internal vulnerability scans performed at least quarterly
- **Category**: Vulnerability Testing
- **Evidence expectations**: Scan schedules, scan reports, remediation evidence for identified vulnerabilities
- **Common controls**: AWS Inspector, Qualys internal scanning, scheduled Trivy/Nessus scans

### 11.3.2: External vulnerability scans performed at least quarterly by ASV
- **Category**: Vulnerability Testing
- **Evidence expectations**: ASV scan reports, remediation evidence, passing scan confirmations
- **Common controls**: Approved Scanning Vendor (ASV) engagement, quarterly scan reports

### 11.4.1: Intrusion detection/prevention techniques detect and alert on intrusions
- **Category**: Intrusion Detection
- **Evidence expectations**: IDS/IPS configuration, alert rules, incident response integration, detection coverage
- **Common controls**: GuardDuty, VPC flow log analysis, WAF rules, Security Hub

## Requirement 12: Organizational Policies (Infrastructure Layer)

### 12.5.2: Scope of PCI DSS validated and documented annually
- **Category**: Scope Management
- **Evidence expectations**: CDE scope documentation, network diagrams, data flow diagrams, annual scope review records
- **Common controls**: Documented CDE boundary, tagged CDE resources, annual scope review process

### 12.10.1: Incident response plan established and ready to activate
- **Category**: Incident Response
- **Evidence expectations**: IR plan document, contact lists, escalation procedures, annual IR testing evidence
- **Common controls**: Documented IR runbooks, PagerDuty escalation policies, tabletop exercise records
