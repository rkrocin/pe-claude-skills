# NIST Cybersecurity Framework 2.0 - Infrastructure Layer

NIST CSF 2.0 categories and subcategories relevant to cloud infrastructure and platform engineering. Organized by the six core functions.

## Govern (GV)

### GV.OC-3: Legal, regulatory, and contractual cybersecurity requirements understood
- **Category**: Governance
- **Evidence expectations**: Compliance requirements inventory, framework mapping documentation, regulatory obligation tracking
- **Common controls**: Compliance matrix documentation, tagged resources by compliance scope, framework mapping tools

### GV.RM-2: Risk appetite and tolerance determined and communicated
- **Category**: Risk Management
- **Evidence expectations**: Risk appetite statements, risk tolerance thresholds, risk acceptance documentation
- **Common controls**: Documented risk thresholds, risk register, accepted risk documentation with review dates

## Identify (ID)

### ID.AM-1: Hardware and systems inventoried
- **Category**: Asset Management
- **Evidence expectations**: Asset inventory, auto-discovery configurations, inventory accuracy verification
- **Common controls**: AWS Config, Systems Manager inventory, resource tagging, AWS Organizations account inventory

### ID.AM-2: Software platforms and applications inventoried
- **Category**: Asset Management
- **Evidence expectations**: Application inventory, software bill of materials, version tracking
- **Common controls**: Service catalog, CMDB, container image registry, dependency manifests

### ID.AM-5: Assets prioritized based on classification and business value
- **Category**: Asset Management
- **Evidence expectations**: Data classification scheme, asset criticality ratings, resource tagging reflecting classification
- **Common controls**: Resource tags (DataClassification, Criticality), tiered monitoring based on classification

### ID.RA-1: Asset vulnerabilities identified
- **Category**: Risk Assessment
- **Evidence expectations**: Vulnerability scanning configurations, scan results, vulnerability tracking
- **Common controls**: AWS Inspector, Qualys/Nessus, Trivy container scanning, dependency scanning in CI/CD

### ID.RA-2: Threat intelligence received from shared sources
- **Category**: Risk Assessment
- **Evidence expectations**: Threat intelligence feed subscriptions, integration with detection tools
- **Common controls**: GuardDuty threat intelligence, AWS Security Hub, threat feed integration with SIEM

## Protect (PR)

### PR.AC-1: Identities and credentials managed for authorized users and services
- **Category**: Identity Management
- **Evidence expectations**: Identity provider configuration, credential policies, service account management
- **Common controls**: SSO (Okta/Azure AD), MFA enforcement, IAM role-based access, Secrets Manager for service credentials

### PR.AC-3: Remote access managed
- **Category**: Access Control
- **Evidence expectations**: VPN/remote access configurations, session management, MFA for remote access
- **Common controls**: SSM Session Manager, VPN with MFA, bastion host configurations, session recording

### PR.AC-4: Access permissions and authorizations managed with least privilege
- **Category**: Access Control
- **Evidence expectations**: Least-privilege IAM policies, access review evidence, privilege escalation controls
- **Common controls**: Terraform-managed IAM with scoped policies, IAM Access Analyzer, quarterly access reviews

### PR.DS-1: Data at rest protected
- **Category**: Data Security
- **Evidence expectations**: Encryption configuration on all data stores, key management, encryption verification
- **Common controls**: KMS encryption on S3, RDS, EBS, DynamoDB; AWS Config rules verifying encryption

### PR.DS-2: Data in transit protected
- **Category**: Data Security
- **Evidence expectations**: TLS configuration, certificate management, minimum protocol version enforcement
- **Common controls**: ALB TLS policies, ACM certificates, RDS SSL enforcement, API Gateway TLS

### PR.DS-5: Protections against data leaks implemented
- **Category**: Data Security
- **Evidence expectations**: DLP controls, exfiltration prevention, public access blocks, network egress controls
- **Common controls**: S3 public access blocks, VPC endpoint policies, GuardDuty S3 protection, egress filtering

### PR.IP-1: Configuration baselines established and maintained
- **Category**: Protective Technology
- **Evidence expectations**: Infrastructure-as-code templates, configuration standards, drift detection
- **Common controls**: Terraform modules with security defaults, AWS Config conformance packs, drift detection alerting

### PR.IP-3: Configuration change control processes in place
- **Category**: Change Management
- **Evidence expectations**: Change management procedures, approval workflows, change tracking
- **Common controls**: Terraform plan/apply with PR approval, GitHub branch protection, change log audit trail

### PR.IP-4: Backups conducted, maintained, and tested
- **Category**: Data Protection
- **Evidence expectations**: Backup configurations, retention policies, restore test evidence
- **Common controls**: RDS automated backups, S3 cross-region replication, EBS snapshots, annual restore tests

### PR.IP-12: Vulnerability management plan developed and implemented
- **Category**: Vulnerability Management
- **Evidence expectations**: Vulnerability management policy, scanning schedules, remediation SLAs, patching cadence
- **Common controls**: Patch management via SSM, container image update pipelines, vulnerability tracking in Jira

### PR.PT-1: Audit and log records maintained
- **Category**: Logging
- **Evidence expectations**: Logging configuration, retention policies, log integrity protections
- **Common controls**: CloudTrail, CloudWatch Logs, VPC flow logs, log retention configurations, log file validation

## Detect (DE)

### DE.CM-1: Networks monitored to detect security events
- **Category**: Continuous Monitoring
- **Evidence expectations**: Network monitoring tools, VPC flow log analysis, IDS/IPS configurations, alerting rules
- **Common controls**: GuardDuty, VPC flow logs, Security Hub, WAF logging, network anomaly detection

### DE.CM-4: Malicious code detected
- **Category**: Continuous Monitoring
- **Evidence expectations**: Malware detection tools, container scanning, runtime protection
- **Common controls**: GuardDuty malware protection, ECR image scanning, CI/CD security scanning

### DE.CM-7: Monitoring for unauthorized activity (personnel, connections, software)
- **Category**: Continuous Monitoring
- **Evidence expectations**: User activity monitoring, anomaly detection, unauthorized access alerting
- **Common controls**: CloudTrail monitoring, IAM Access Analyzer, GuardDuty, CloudWatch alarms on suspicious activity

### DE.DP-4: Event detection information communicated to appropriate parties
- **Category**: Detection Processes
- **Evidence expectations**: Alert routing configurations, escalation procedures, notification channels
- **Common controls**: PagerDuty integrations, SNS alert topics, Slack/email notifications, on-call schedules

## Respond (RS)

### RS.RP-1: Response plan executed during or after an incident
- **Category**: Response Planning
- **Evidence expectations**: IR plan, execution evidence from past incidents, tabletop exercise records
- **Common controls**: IR runbooks, postmortem records, tabletop exercise documentation

### RS.AN-1: Notifications from detection systems investigated
- **Category**: Analysis
- **Evidence expectations**: Alert triage procedures, investigation workflows, false positive management
- **Common controls**: Alert triage runbooks, GuardDuty finding investigation procedures, Security Hub workflow

### RS.MI-1: Incidents contained
- **Category**: Mitigation
- **Evidence expectations**: Containment procedures, isolation capabilities, evidence from past containment actions
- **Common controls**: Security group isolation procedures, IAM policy revocation, account quarantine procedures

## Recover (RC)

### RC.RP-1: Recovery plan executed during or after an incident
- **Category**: Recovery Planning
- **Evidence expectations**: DR/recovery plans, recovery execution evidence, RTO/RPO compliance
- **Common controls**: DR runbooks, failover procedures, recovery test evidence, RTO/RPO tracking
