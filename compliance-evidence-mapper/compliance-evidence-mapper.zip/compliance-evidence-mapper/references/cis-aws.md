# CIS AWS Foundations Benchmark - Key Controls

Selected controls from the CIS AWS Foundations Benchmark relevant to platform engineering compliance mapping. Organized by benchmark section.

## 1. Identity and Access Management

### 1.4: Ensure no root account access key exists
- **Category**: IAM
- **Evidence expectations**: Root account access key status, AWS Config rule evaluation, credential report
- **Common controls**: AWS Config rule iam-root-access-key-check, credential report review, root account lockdown

### 1.5: Ensure MFA is enabled for the root account
- **Category**: IAM
- **Evidence expectations**: Root account MFA configuration, hardware MFA device assignment
- **Common controls**: Hardware MFA on root, AWS Config rule root-account-mfa-enabled

### 1.10: Ensure MFA is enabled for all IAM users with console access
- **Category**: IAM
- **Evidence expectations**: IAM credential report showing MFA status, MFA enforcement policy
- **Common controls**: SSO with mandatory MFA, IAM policy requiring MFA, credential report review

### 1.16: Ensure IAM policies are attached only to groups or roles
- **Category**: IAM
- **Evidence expectations**: No inline policies on IAM users, policies attached to roles/groups only
- **Common controls**: Terraform IAM management with role-based policies, AWS Config rule iam-user-no-policies-check

### 1.17: Ensure a support role has been created for AWS Support access
- **Category**: IAM
- **Evidence expectations**: AWSSupportAccess role configuration, support case access policy
- **Common controls**: Dedicated support role with AWSSupportAccess policy

### 1.20: Ensure access keys are rotated every 90 days or less
- **Category**: IAM
- **Evidence expectations**: Access key age report, rotation enforcement, credential report
- **Common controls**: AWS Config rule access-keys-rotated (90 days), automated rotation alerts

## 2. Storage

### 2.1.1: Ensure S3 bucket default encryption is enabled
- **Category**: Data Protection
- **Evidence expectations**: S3 bucket encryption configuration, AWS Config rule evaluation
- **Common controls**: AWS Config rule s3-bucket-server-side-encryption-enabled, Terraform module defaults

### 2.1.2: Ensure S3 bucket policy denies HTTP requests
- **Category**: Data Protection
- **Evidence expectations**: S3 bucket policies enforcing TLS, AWS Config rule evaluation
- **Common controls**: Bucket policy with aws:SecureTransport condition, AWS Config rule s3-bucket-ssl-requests-only

### 2.1.5: Ensure S3 buckets are not publicly accessible
- **Category**: Data Protection
- **Evidence expectations**: S3 public access block configuration, account-level block public access
- **Common controls**: Account-level S3 Block Public Access, AWS Config rule s3-bucket-public-read-prohibited

### 2.3.1: Ensure RDS instances have encryption at rest enabled
- **Category**: Data Protection
- **Evidence expectations**: RDS encryption configuration, AWS Config rule evaluation
- **Common controls**: AWS Config rule rds-storage-encrypted, Terraform module defaults

### 2.3.3: Ensure RDS instances are not publicly accessible
- **Category**: Network Security
- **Evidence expectations**: RDS publicly_accessible setting, AWS Config rule evaluation
- **Common controls**: AWS Config rule rds-instance-public-access-check, Terraform module defaults

## 3. Logging

### 3.1: Ensure CloudTrail is enabled in all regions
- **Category**: Audit Logging
- **Evidence expectations**: CloudTrail multi-region trail configuration, AWS Config rule evaluation
- **Common controls**: AWS Config rule multi-region-cloudtrail-enabled, Terraform CloudTrail configuration

### 3.2: Ensure CloudTrail log file validation is enabled
- **Category**: Log Integrity
- **Evidence expectations**: CloudTrail log file validation setting, AWS Config rule evaluation
- **Common controls**: AWS Config rule cloud-trail-log-file-validation-enabled

### 3.4: Ensure CloudTrail trails are integrated with CloudWatch Logs
- **Category**: Log Monitoring
- **Evidence expectations**: CloudTrail CloudWatch Logs integration, log group configuration
- **Common controls**: CloudTrail delivery to CloudWatch Logs, metric filters and alarms

### 3.7: Ensure S3 bucket access logging is enabled on CloudTrail S3 bucket
- **Category**: Audit Logging
- **Evidence expectations**: S3 access logging on the CloudTrail log bucket, logging bucket configuration
- **Common controls**: S3 access logging configuration, dedicated logging bucket

### 3.9: Ensure VPC flow logging is enabled in all VPCs
- **Category**: Network Logging
- **Evidence expectations**: VPC flow log configuration for all VPCs, destination configuration
- **Common controls**: AWS Config rule vpc-flow-logs-enabled, Terraform VPC module with flow logs

## 4. Monitoring

### 4.1: Ensure unauthorized API calls are monitored
- **Category**: Monitoring
- **Evidence expectations**: CloudWatch metric filter for unauthorized API calls, associated alarm
- **Common controls**: CloudWatch metric filter on UnauthorizedOperation and AccessDenied, SNS alarm

### 4.3: Ensure root account usage is monitored
- **Category**: Monitoring
- **Evidence expectations**: CloudWatch metric filter for root login, associated alarm, alert routing
- **Common controls**: CloudWatch metric filter on root ConsoleLogin, SNS alarm, PagerDuty integration

### 4.4: Ensure IAM policy changes are monitored
- **Category**: Monitoring
- **Evidence expectations**: CloudWatch metric filter for IAM policy events, associated alarm
- **Common controls**: CloudWatch metric filter on IAM policy change events, SNS alarm

### 4.5: Ensure CloudTrail configuration changes are monitored
- **Category**: Monitoring
- **Evidence expectations**: CloudWatch metric filter for CloudTrail changes, associated alarm
- **Common controls**: CloudWatch metric filter on StopLogging/DeleteTrail/UpdateTrail, SNS alarm

### 4.12: Ensure network gateway changes are monitored
- **Category**: Monitoring
- **Evidence expectations**: CloudWatch metric filter for VPC gateway changes, associated alarm
- **Common controls**: CloudWatch metric filter on gateway events, SNS alarm

### 4.14: Ensure VPC changes are monitored
- **Category**: Monitoring
- **Evidence expectations**: CloudWatch metric filter for VPC changes, associated alarm
- **Common controls**: CloudWatch metric filter on VPC events, SNS alarm

## 5. Networking

### 5.1: Ensure no network ACLs allow ingress from 0.0.0.0/0 to admin ports
- **Category**: Network Security
- **Evidence expectations**: NACL rules, security group rules, no SSH/RDP from 0.0.0.0/0
- **Common controls**: AWS Config rule restricted-ssh, security group audit, Terraform security group modules

### 5.3: Ensure default security group restricts all traffic
- **Category**: Network Security
- **Evidence expectations**: Default security group configuration with no ingress/egress rules
- **Common controls**: AWS Config rule vpc-default-security-group-closed, Terraform VPC configuration

### 5.6: Ensure EC2 instances in public subnets do not have public IP auto-assign
- **Category**: Network Security
- **Evidence expectations**: Subnet auto-assign public IP configuration, instance configuration
- **Common controls**: Subnet configuration with map_public_ip_on_launch=false, Terraform subnet modules
