# Technical Interview Question Bank

A [Claude Skill](https://docs.anthropic.com/) that generates structured interview question sets with evaluation rubrics, scoring criteria, and debrief frameworks for technical and engineering leadership hiring.

## What It Does

Provide a role description and it generates:

- **Interview Loop Design** with stages, focus areas, and interviewer recommendations
- **Question Sets** organized by competency with follow-up probes that dig into depth
- **Evaluation Rubrics** defining what Strong Hire through Strong No Hire looks like for each question
- **Debrief Scorecard** for structured candidate comparison
- **Green Flags and Red Flags** specific to the role

## Why

Most engineering interviews suffer from the same problems: questions are improvised, interviewers assess overlapping competencies, rubrics do not exist (or are generic), and debrief conversations become unstructured opinion-sharing. The result is inconsistent signal, biased hiring, and wasted interview time.

This skill applies structure to every stage: each question has a rubric written before the interview, each interviewer owns specific competencies, and the debrief scorecard forces evidence-based decisions rather than gut reactions.

## Usage

### Full Interview Loop

```
Build me an interview loop for a Director of Platform Engineering at a 
financial services company. The role manages 80-100 engineers, owns a 
$40M cloud budget, and reports to the VP of Engineering.
```

### Specific Stage Questions

```
I'm interviewing a Senior SRE tomorrow. Generate behavioral questions 
focused on incident response and ownership. Include rubrics.
```

### Debrief Scorecard Only

```
Create a debrief scorecard for a Staff Platform Engineer role. We're 
assessing system design, IaC expertise, leadership without authority, 
and security awareness.
```

## Question Categories

| Category | Questions | Focus Areas |
|----------|-----------|-------------|
| Platform & Infrastructure | 6 questions | Platform design, cloud migration, IaC at scale, SRE, DevSecOps, FinOps |
| Engineering Leadership | 7 questions | Team building, coaching, performance management, org design, strategy, stakeholder management, cross-functional leadership |
| Behavioral & Culture | 7 questions | Ownership, learning from failure, communication, feedback, collaboration, disagreement, growth mindset, adaptability |
| Security & Compliance | 5 questions | Zero trust, audit preparation, compliance automation, threat modeling, vulnerability management, security culture |

## Evaluation Approach

Every question uses a 4-point rubric with no middle option, forcing a decision:

| Score | Label | Meaning |
|-------|-------|---------|
| 4 | Strong Hire | Exceeds the bar. Would raise the team's capability. |
| 3 | Hire | Meets the bar. Solid answers with reasonable depth. |
| 2 | Lean No Hire | Below the bar. Vague answers, significant gaps. |
| 1 | Strong No Hire | Clearly below the bar. Fundamental gaps or concerning signals. |

Rubrics are calibrated to the role level. What constitutes "Strong Hire" for a Senior Engineer is different from a Director.

## Sample Output

`assets/sample-loop-director-platform.md` contains a complete interview loop for a Director of Platform Engineering in financial services, including:

- 5-stage loop design with interviewer assignments
- 12 questions across technical, leadership, security, and cross-functional competencies
- Full debrief scorecard with role-specific green and red flags

## Design Principles

**Ask about their work, not hypotheticals.** "Tell me about a time..." produces more reliable signal than "What would you do if..." Past behavior is the best predictor of future behavior.

**Follow-ups reveal depth.** The initial question is a prompt. Push for specifics: numbers, timelines, who was involved, what went wrong, what they would change.

**Each stage assesses distinct competencies.** Overlap between interviewers wastes candidate time and produces redundant signal.

**Define "good" before the interview.** Rubrics exist so interviewers know what they are looking for rather than deciding after the fact.

**No trivia.** Questions test judgment and thinking, not memorized facts.

## Skill Structure

```
interview-question-bank/
├── SKILL.md                                    # Skill definition and generation process
├── README.md                                   # This file
├── references/
│   ├── platform-infra.md                       # 6 platform/infrastructure questions with rubrics
│   ├── engineering-leadership.md               # 7 leadership questions with rubrics
│   ├── behavioral.md                           # 7 behavioral questions with rubrics
│   └── security-compliance.md                  # 5 security/compliance questions with rubrics
└── assets/
    └── sample-loop-director-platform.md        # Complete interview loop for Director of Platform Eng
```

## License

MIT
