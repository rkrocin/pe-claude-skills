# Security & Compliance Interview Questions

Questions for security engineering, GRC, compliance, and security-adjacent platform and infrastructure roles.

## Security Architecture

### Zero Trust Design
**Question**: How would you approach implementing a zero-trust security model in an organization that currently relies on perimeter-based security? What are the first three things you would change?

**What this assesses**: Security architecture thinking, practical implementation awareness, ability to prioritize and sequence security improvements.

**Follow-up probes**:
- How do you handle legacy systems that cannot support zero-trust patterns?
- How do you manage the performance and complexity overhead of zero-trust?
- How do you get engineering teams to adopt zero-trust practices without creating friction?
- What is the role of identity in a zero-trust architecture vs. network controls?

**Evaluation rubric**:
| Rating | Signal |
|--------|--------|
| Strong Hire | Articulates zero-trust principles (verify explicitly, least privilege, assume breach) with practical implementation steps. Prioritizes identity-centric controls over network-centric. Acknowledges the transition complexity and proposes an incremental approach. Considers developer experience alongside security posture. |
| Hire | Understands zero-trust concepts and can propose reasonable first steps. May focus too heavily on tooling rather than principles. |
| Lean No Hire | Describes zero-trust as a product to buy rather than an architecture to implement. Cannot prioritize or sequence. |
| Strong No Hire | Does not understand zero-trust beyond the buzzword, or confuses it with VPN/firewall replacement. |

---

## Compliance and Governance

### Audit Preparation
**Question**: You have 90 days before a PCI DSS (or SOC 2) audit. Walk me through your preparation process, assuming the environment has never been audited before.

**What this assesses**: Audit preparation experience, structured approach, ability to manage scope and evidence.

**Follow-up probes**:
- How do you determine the scope of the audit?
- How do you identify gaps before the auditor does?
- How do you prioritize remediation when you cannot fix everything in time?
- How do you prepare the team for auditor interviews?

**Evaluation rubric**:
| Rating | Signal |
|--------|--------|
| Strong Hire | Describes a structured approach: scope definition, controls inventory, gap assessment, evidence collection, remediation prioritization, team preparation. Has experience with real audits and can describe specific challenges. Understands the difference between passing an audit and building a sustainable compliance program. |
| Hire | Reasonable preparation approach with some practical experience. May lack depth on one area (evidence collection, team preparation, or remediation prioritization). |
| Lean No Hire | Describes audit preparation as a checklist exercise without strategic thinking. No experience with actual audit interactions. |
| Strong No Hire | No audit experience. Cannot describe a compliance framework or preparation approach. |

---

### Compliance as Code
**Question**: How have you automated compliance checks or evidence collection in your infrastructure? Give me a specific example of a compliance requirement you automated and the impact it had.

**What this assesses**: Ability to operationalize compliance, automation thinking applied to governance, practical implementation.

**Follow-up probes**:
- How did you choose which compliance checks to automate first?
- How do you handle false positives in automated compliance scanning?
- How do you keep automated checks current as compliance requirements evolve?
- What is the boundary between automated compliance and human judgment?

**Evaluation rubric**:
| Rating | Signal |
|--------|--------|
| Strong Hire | Describes specific automated compliance implementations (AWS Config rules, policy-as-code, automated evidence collection) with measurable impact (reduced audit prep time, continuous compliance monitoring). Understands that automation complements but does not replace human judgment. |
| Hire | Has automated some compliance checks with reasonable approach. May describe a narrower implementation. |
| Lean No Hire | Describes compliance automation in theoretical terms without practical implementation. |
| Strong No Hire | Views compliance as a manual, periodic activity with no automation interest or experience. |

---

## Security Operations

### Threat Modeling
**Question**: Walk me through how you would threat model a new microservice that handles payment processing. What frameworks or approaches do you use?

**What this assesses**: Structured security analysis, threat identification capability, risk-based thinking.

**Follow-up probes**:
- How do you decide which threats to prioritize?
- How do you involve developers in the threat modeling process?
- How do you ensure threat models are maintained as the service evolves?
- What is the difference between a threat model and a security review?

**Evaluation rubric**:
| Rating | Signal |
|--------|--------|
| Strong Hire | Uses a structured approach (STRIDE, DREAD, or equivalent). Identifies data flows, trust boundaries, and threat categories systematically. Prioritizes by business impact, not just technical severity. Involves developers as participants, not recipients. |
| Hire | Reasonable threat modeling approach. Identifies major threats. May lack structure or prioritization framework. |
| Lean No Hire | Identifies some security concerns but not in a structured way. Threat modeling is ad hoc rather than systematic. |
| Strong No Hire | Cannot describe a threat modeling approach. Identifies security concerns only after incidents. |

---

### Vulnerability Management
**Question**: You discover a critical vulnerability (CVSSv3 9.8) affecting a production system that processes customer financial data. Walk me through your response from the moment you learn about it.

**What this assesses**: Incident response instincts, risk-based decision-making, communication under pressure, patching discipline.

**Follow-up probes**:
- How do you assess whether the vulnerability is actively being exploited?
- How do you balance speed of patching against risk of introducing a regression?
- Who do you communicate with, and in what order?
- How do you handle the case where the patch is not yet available?

**Evaluation rubric**:
| Rating | Signal |
|--------|--------|
| Strong Hire | Describes a structured response: assess exposure and exploitability, implement mitigating controls if immediate patching is not possible, communicate to stakeholders, patch with tested change, verify remediation, conduct post-event review. Understands that communication is as important as the technical fix. |
| Hire | Reasonable response with appropriate urgency. May overlook mitigating controls or communication steps. |
| Lean No Hire | Jumps to patching without assessing exposure or communicating. No structured approach. |
| Strong No Hire | Does not treat a 9.8 CVSS as urgent, or cannot describe a vulnerability response process. |

---

## Security Culture

### Security Awareness
**Question**: How do you build a security-aware culture in an engineering organization where security has traditionally been "someone else's problem"?

**What this assesses**: Cultural change capability, influence, practical security evangelism.

**Follow-up probes**:
- What specific programs or initiatives have you implemented?
- How do you measure whether the culture is actually changing?
- How do you handle engineers who view security as an obstacle?
- What is the most effective thing you have done to shift security culture?

**Evaluation rubric**:
| Rating | Signal |
|--------|--------|
| Strong Hire | Describes specific cultural initiatives with measurable outcomes (reduced vulnerabilities, improved response times, increased security engagement). Makes security accessible rather than adversarial. Can describe adapting approach for different audiences (senior engineers, new hires, leadership). |
| Hire | Has contributed to security culture improvement with some specific examples. May describe initiatives without measurement. |
| Lean No Hire | Describes security training as the solution without broader cultural strategy. |
| Strong No Hire | Views security culture as enforcement rather than enablement. Describes punitive approaches to security violations. |
