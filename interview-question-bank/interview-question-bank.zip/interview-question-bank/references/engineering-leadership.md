# Engineering Leadership Interview Questions

Questions for Engineering Manager, Director, VP, and other roles with people management, organizational design, and strategic responsibilities.

## People Development

### Building Teams
**Question**: Tell me about a team you built or significantly reshaped. What was the starting point, what did you change, and what was the outcome?

**What this assesses**: Ability to build and develop teams, organizational design thinking, people investment.

**Follow-up probes**:
- How did you decide on the team structure?
- How did you handle underperformers during the transition?
- What was your approach to hiring? What did you optimize for?
- How did you develop people who were already on the team?

**Evaluation rubric**:
| Rating | Signal |
|--------|--------|
| Strong Hire | Describes a deliberate team-building approach with specific structural decisions and rationale. Can name people they developed and how. Describes both hiring strategy and existing team development. Acknowledges mistakes in the process. |
| Hire | Solid team-building experience with specific examples. Clear on hiring approach. May lack depth on developing existing team members. |
| Lean No Hire | Describes inheriting and maintaining teams but not building or reshaping them. Development of others is described in generic terms (mentoring, 1:1s) without specific outcomes. |
| Strong No Hire | Cannot describe building or developing a team with specifics. Takes credit for team achievements without describing personal contribution to team growth. |

---

### Coaching and Development
**Question**: Tell me about someone who reported to you who grew significantly under your leadership. What was your role in their growth, and how did you know your approach was working?

**What this assesses**: Coaching ability, investment in others, ability to adapt leadership style, measurement of development outcomes.

**Follow-up probes**:
- How did you identify what this person needed to grow?
- What was a specific intervention you made that had impact?
- How did you balance their development against delivery pressure?
- Have you had cases where your coaching approach did not work? What happened?

**Evaluation rubric**:
| Rating | Signal |
|--------|--------|
| Strong Hire | Names a specific individual (without violating privacy) and describes a deliberate development plan with observable outcomes. Can describe adapting their approach when initial efforts did not land. Describes failures alongside successes. |
| Hire | Good coaching example with specifics. Clear that they invested in the person's growth. May describe one approach without evidence of adaptation. |
| Lean No Hire | Describes generic coaching activities without specific outcomes. Cannot name observable growth indicators. |
| Strong No Hire | Cannot provide a coaching example, or describes coaching as telling people what to do. |

---

### Managing Underperformance
**Question**: Tell me about a time you had to manage out an underperformer. How did you make the determination, and how did you handle the process?

**What this assesses**: Performance management courage, fairness, process discipline, emotional intelligence.

**Follow-up probes**:
- How long did you try to improve performance before deciding to manage out?
- What feedback did you give, and how early?
- How did you ensure the process was fair and documented?
- How did the rest of the team react, and how did you handle that?

**Evaluation rubric**:
| Rating | Signal |
|--------|--------|
| Strong Hire | Describes a clear performance management process: early feedback, documented expectations, improvement plan, decision point. Demonstrates empathy alongside accountability. Describes impact on the broader team. Does not celebrate the termination. |
| Hire | Has managed underperformance with a reasonable process. May have been slower to act than ideal but eventually reached the right outcome. |
| Lean No Hire | Has not managed anyone out, or describes the process without evidence of early intervention or clear feedback. |
| Strong No Hire | Describes surprise terminations without prior feedback, or avoids performance management entirely. |

---

## Organizational Design

### Project-to-Product Transformation
**Question**: Describe a significant organizational transformation you led or contributed to. What was the before state, what did you change, and how did you manage the transition?

**What this assesses**: Change management capability, strategic thinking, ability to operate through ambiguity, stakeholder management.

**Follow-up probes**:
- How did you get buy-in from engineers who were comfortable with the old model?
- What metrics did you use to measure whether the transformation was working?
- What resistance did you encounter, and how did you handle it?
- What would you do differently if you had to do it again?

**Evaluation rubric**:
| Rating | Signal |
|--------|--------|
| Strong Hire | Describes a multi-phase transformation with clear before/after states and measurable outcomes. Demonstrates awareness of the human change management challenge alongside the structural change. Can describe resistance and how they addressed it. Honest about what did not work. |
| Hire | Participated meaningfully in a transformation. Can describe the rationale and outcomes. May not have owned the full strategy. |
| Lean No Hire | Describes organizational changes that happened around them rather than changes they drove. Cannot articulate the transformation strategy. |
| Strong No Hire | No transformation experience, or describes changes imposed top-down without engagement or measurement. |

---

### Span of Control
**Question**: You are given an organization of 100 engineers across 12 teams. Some teams have 4 people, some have 15. Managers range from first-time to very senior. How do you assess and potentially restructure this organization?

**What this assesses**: Org design thinking, analytical approach to structure, ability to balance team health with delivery needs.

**Follow-up probes**:
- What data would you gather before making changes?
- How do you decide the right team size and manager span?
- How do you handle restructuring when people are attached to their current teams?
- How do you handle managers who are not performing at the level needed for the new structure?

**Evaluation rubric**:
| Rating | Signal |
|--------|--------|
| Strong Hire | Describes a data-driven assessment approach: team delivery metrics, manager effectiveness, dependency patterns, communication overhead. Has a framework for team sizing and span of control. Acknowledges the human cost of restructuring and has strategies to manage it. |
| Hire | Reasonable approach to org assessment. Understands team sizing principles. May rely more on intuition than data. |
| Lean No Hire | No framework for org assessment. Proposes restructuring based on technology boundaries alone without considering team dynamics or manager capability. |
| Strong No Hire | Cannot articulate how they would assess an organization. Proposes changes without gathering information. |

---

## Strategic Leadership

### Technical Strategy
**Question**: How do you develop and communicate a technical strategy for a platform organization? Walk me through a strategy you built, how you got alignment, and how you measured progress.

**What this assesses**: Strategic thinking, communication at multiple levels, ability to connect technical direction to business outcomes.

**Follow-up probes**:
- How did you balance long-term platform investment against short-term delivery pressure?
- How did you communicate the strategy to engineers vs. to executives?
- How did you handle it when the strategy needed to change mid-execution?
- How did you decide what NOT to do?

**Evaluation rubric**:
| Rating | Signal |
|--------|--------|
| Strong Hire | Describes a coherent strategy with clear connection to business outcomes. Demonstrates ability to communicate at multiple altitudes (IC, director, VP). Can describe tradeoffs and what was explicitly deprioritized. Adapted the strategy based on feedback or changing conditions. |
| Hire | Has built or contributed to a technical strategy with reasonable structure. Can describe the connection to business outcomes. May need prompting on adaptation or what was deprioritized. |
| Lean No Hire | Describes a technology roadmap but not a strategy. Cannot connect technical decisions to business outcomes. No evidence of executive-level communication. |
| Strong No Hire | Cannot describe a coherent technical strategy. Confuses a list of projects with a strategy. |

---

### Stakeholder Management
**Question**: Tell me about a time you had to influence a senior stakeholder (VP, CIO, CISO) to invest in a platform initiative that did not have obvious short-term ROI. How did you make the case?

**What this assesses**: Upward influence, business case construction, executive communication, persistence.

**Follow-up probes**:
- How did you frame the investment in terms the stakeholder cared about?
- What objections did you face, and how did you address them?
- Did you have to compromise? What did you give up?
- How did you measure and report on the investment after it was approved?

**Evaluation rubric**:
| Rating | Signal |
|--------|--------|
| Strong Hire | Built a compelling business case with quantified impact. Adapted the framing to the audience. Handled objections without becoming defensive. Followed through on measurement after approval. Demonstrates political awareness without being political. |
| Hire | Successfully influenced a senior stakeholder with a reasonable business case. May have relied on relationship rather than structured argument. |
| Lean No Hire | Describes escalating to get what they wanted rather than influencing. Cannot articulate how they framed the value proposition for the audience. |
| Strong No Hire | Cannot describe influencing a senior stakeholder. Views executive communication as someone else's responsibility. |

---

## Cross-Functional Leadership

### Working with Security
**Question**: Tell me about a time the security team and your engineering team disagreed on a control or requirement. How did you resolve it?

**What this assesses**: Cross-functional collaboration, ability to balance competing priorities, security awareness without security adversarial mindset.

**Follow-up probes**:
- Did you understand the security team's concern before pushing back?
- What compromise did you reach?
- How did the resolution affect the relationship going forward?
- How do you generally embed security into platform work rather than treating it as a gate?

**Evaluation rubric**:
| Rating | Signal |
|--------|--------|
| Strong Hire | Describes understanding the security concern first, then working collaboratively to find a solution that satisfied both security and engineering needs. Has a general philosophy of security as enabler, not blocker. Describes ongoing relationship investment with security. |
| Hire | Resolved the disagreement constructively. Demonstrates respect for security perspectives. May describe it as a one-time resolution rather than a systematic approach. |
| Lean No Hire | Describes security as an obstacle. Resolution was escalation rather than collaboration. |
| Strong No Hire | Adversarial toward security. Describes bypassing or overriding security requirements. |
