# Platform & Infrastructure Interview Questions

Questions for platform engineering, cloud infrastructure, DevOps, SRE, and related technical roles. Organized by competency.

## Cloud Architecture & Design

### System Design: Platform Service
**Question**: Walk me through how you would design an internal developer platform that serves 500+ engineers across 30 teams. What are the key components, and how do you prioritize what to build first?

**What this assesses**: Architecture thinking at scale, prioritization, understanding of developer experience, ability to scope incrementally.

**Follow-up probes**:
- How do you decide between build vs. buy for each component?
- How do you handle teams with conflicting requirements?
- What metrics would you use to measure whether the platform is succeeding?
- How do you avoid the platform team becoming a bottleneck?

**Evaluation rubric**:
| Rating | Signal |
|--------|--------|
| Strong Hire | Identifies core components (service catalog, Golden Paths, CI/CD, observability) and articulates a phased rollout prioritized by developer pain. Discusses adoption strategy alongside technical design. Considers governance and self-service tradeoffs. |
| Hire | Identifies most key components. Has a reasonable prioritization rationale. May need prompting on adoption strategy or governance. |
| Lean No Hire | Lists technologies but cannot articulate how they fit together or how to prioritize. Focuses on tools rather than developer outcomes. |
| Strong No Hire | Cannot describe a coherent platform architecture. No awareness of developer experience as a design driver. |

---

### Cloud Migration Strategy
**Question**: Tell me about a significant infrastructure migration you led. What was the scope, how did you plan it, and what went wrong?

**What this assesses**: Migration experience, planning discipline, risk management, honesty about challenges.

**Follow-up probes**:
- How did you handle services that were too risky to migrate on the original timeline?
- What was your rollback strategy?
- How did you communicate progress and risk to leadership?
- What would you do differently with the benefit of hindsight?

**Evaluation rubric**:
| Rating | Signal |
|--------|--------|
| Strong Hire | Describes a structured migration approach (assessment, pilot, waves). Specific about risk mitigation and rollback planning. Honest about what went wrong. Can articulate lessons learned that changed their approach. |
| Hire | Solid migration experience with reasonable planning. Can describe challenges and how they were addressed. May lack depth on risk quantification. |
| Lean No Hire | Migration experience is limited to individual services rather than organizational scale. Cannot describe a structured approach. |
| Strong No Hire | Claims migration experience but cannot describe the planning, risk management, or decision-making process. |

---

## Infrastructure as Code & Automation

### IaC at Scale
**Question**: How have you managed Terraform (or equivalent) at enterprise scale? How do you handle module versioning, state management, and preventing drift across hundreds of resources?

**What this assesses**: Practical IaC experience at scale, understanding of operational challenges beyond writing HCL.

**Follow-up probes**:
- How do you handle breaking changes in shared modules?
- What is your approach to state file management and access control?
- How do you detect and remediate drift?
- How do you enable teams to self-service infrastructure without sacrificing governance?

**Evaluation rubric**:
| Rating | Signal |
|--------|--------|
| Strong Hire | Has managed IaC at scale with mature practices: module registry, semantic versioning, remote state with locking, CI/CD for infrastructure, drift detection, policy-as-code. Can discuss tradeoffs between flexibility and governance. |
| Hire | Solid IaC experience with awareness of scale challenges. Uses remote state and modules. May not have solved all governance challenges. |
| Lean No Hire | Uses Terraform but at small scale. No experience with module management, state operations at scale, or governance patterns. |
| Strong No Hire | Limited IaC experience or cannot explain state management fundamentals. |

---

## Site Reliability Engineering

### Incident Response
**Question**: Tell me about the most impactful production incident you were involved in. Walk me through the timeline from detection to resolution, and what changed as a result.

**What this assesses**: Incident management capability, structured thinking under pressure, learning orientation, communication.

**Follow-up probes**:
- How was the incident detected? Was it automated or customer-reported?
- What was the communication flow during the incident?
- How did you determine root cause vs. contributing factors?
- What preventive measures were implemented, and were they effective?

**Evaluation rubric**:
| Rating | Signal |
|--------|--------|
| Strong Hire | Describes a structured incident response with clear roles, communication cadence, and timeline. Distinguishes between root cause and contributing factors. Describes concrete postmortem outcomes that were implemented and verified. Demonstrates learning without blaming. |
| Hire | Good incident narrative with reasonable structure. Identifies root cause and some preventive actions. May lack depth on communication or follow-through. |
| Lean No Hire | Describes an incident but in a disorganized way. Cannot distinguish root cause from symptoms. No clear postmortem or preventive outcomes. |
| Strong No Hire | Cannot describe a significant incident in detail, or describes incidents in a blame-oriented way. |

---

### SLO and Reliability
**Question**: How do you define and manage SLOs for a platform that serves multiple teams with different reliability expectations?

**What this assesses**: Reliability engineering maturity, ability to balance competing stakeholder needs, quantitative thinking.

**Follow-up probes**:
- How do you choose SLIs that actually reflect user experience?
- How do you handle error budget disagreements between the platform team and consuming teams?
- What happens when you burn through your error budget?
- How do you balance reliability investment against feature delivery?

**Evaluation rubric**:
| Rating | Signal |
|--------|--------|
| Strong Hire | Articulates SLO/SLI/error budget concepts with practical experience. Can describe real tradeoff negotiations. Understands that SLOs are a tool for prioritization, not just measurement. |
| Hire | Understands SLO concepts and has some practical experience. May rely on theoretical knowledge for error budget management. |
| Lean No Hire | Knows the terms but has not implemented SLOs in practice. Conflates uptime with SLOs. |
| Strong No Hire | No understanding of SLOs or reliability engineering beyond "keep things running." |

---

## DevSecOps & Security

### Shift-Left Security
**Question**: How have you embedded security into the development pipeline without slowing teams down? Give me a specific example of a security control you implemented and how you managed the developer experience tradeoff.

**What this assesses**: Practical DevSecOps experience, ability to balance security with developer productivity, influence skills.

**Follow-up probes**:
- How did you get developer buy-in for the security control?
- What was the false positive rate, and how did you manage it?
- How do you prioritize which security controls to enforce in CI/CD vs. advisory?
- How do you handle exceptions when a team needs to bypass a security gate?

**Evaluation rubric**:
| Rating | Signal |
|--------|--------|
| Strong Hire | Describes specific security controls embedded in CI/CD (SAST, SCA, container scanning) with practical experience managing false positives and developer pushback. Has a framework for mandatory vs. advisory controls. Understands that security controls that developers bypass are worse than no controls. |
| Hire | Has implemented security scanning in pipelines. Understands the developer friction tradeoff. May not have a mature exception process. |
| Lean No Hire | Describes security tools but not how they were integrated into developer workflow. No awareness of false positive management or developer experience. |
| Strong No Hire | No practical DevSecOps experience. Views security as a gate, not an enabler. |

---

## FinOps & Cost Management

### Cloud Cost Governance
**Question**: You inherit a $40M annual cloud budget that has been growing 25% year-over-year with no formal governance. What do you do in the first 90 days?

**What this assesses**: FinOps maturity, prioritization under ambiguity, organizational change management, quantitative approach.

**Follow-up probes**:
- How do you establish visibility before you can optimize?
- How do you handle teams that resist tagging or cost allocation?
- What is the difference between rate optimization and usage optimization, and which do you pursue first?
- How do you communicate cost savings in a way that resonates with engineering leadership?

**Evaluation rubric**:
| Rating | Signal |
|--------|--------|
| Strong Hire | Describes a phased approach: visibility first (tagging, cost allocation, reporting), then quick wins (rightsizing, unused resources), then structural optimization (reserved capacity, architecture changes). Understands the organizational change required alongside the technical work. Can frame cost optimization in terms of engineering productivity, not just savings. |
| Hire | Reasonable approach with focus on visibility and quick wins. May lack depth on organizational change or long-term governance structures. |
| Lean No Hire | Jumps to cost-cutting tactics without establishing visibility. Cannot describe a structured FinOps approach. |
| Strong No Hire | No experience with cloud cost management at meaningful scale. |
