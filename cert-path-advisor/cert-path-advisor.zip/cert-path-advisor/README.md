# Certification Path Advisor

A [Claude Skill](https://docs.anthropic.com/) that analyzes a resume and job description to recommend certifications and certification paths that close skill gaps and strengthen candidacy for a target role.

## What It Does

Upload your resume and a target job description, and it generates:

- **Skills Gap Analysis** across five dimensions: certification gaps, skill gaps, domain gaps, level gaps, and credential relevance
- **Prioritized Recommendations** in four tiers from "close now" to "nice to have," each with effort, cost, and ROI assessment
- **Certification Path** with sequencing optimized for knowledge overlap and dependency chains
- **Existing Credential Assessment** evaluating which current certs matter for the target role
- **Investment Summary** with total time, cost, and overlap savings

## Why

Most people choose certifications based on what is popular or what their employer offers, not based on what closes the specific gap between where they are and where they want to be. This skill reads both sides of the equation (your resume and the target JD), identifies the exact credibility gaps, and recommends certifications that close them in priority order.

The sequencing matters as much as the selection. Taking CISSP before CCSP saves 3-4 weeks of study time due to 40% content overlap. Taking AWS SA Associate before Professional saves 2-3 weeks. These overlap savings compound across a multi-certification path.

## Usage

### Resume + Job Description

```
[Upload: resume.pdf]
[Upload: job-description.docx]

Analyze my resume against this job description and recommend certifications 
that would strengthen my candidacy. I have about 10 hours per week to study.
```

### Resume + Target Role Description

```
[Upload: resume.pdf]

I'm targeting Director of Platform Engineering roles at financial services 
companies in Chicago. Which certifications should I prioritize?
```

### Quick Gap Check

```
I have AWS SA Associate, Terraform Associate, and Security+. I'm applying 
for a Director of Cloud Engineering role at a bank that wants "deep AWS 
expertise" and "security certifications preferred." What am I missing?
```

## Supported Input Formats

| Format | How It Is Read |
|--------|---------------|
| `.pdf` | Via pdf-reading skill |
| `.docx` | Converted via pandoc |
| `.md` / `.txt` | Read directly |
| Pasted text | Used directly from conversation |

## Priority Framework

| Tier | Meaning | Timing |
|------|---------|--------|
| **Tier 1** | Closes the biggest credibility gap; high hiring signal | Before applying if possible |
| **Tier 2** | Moves candidate from "meets" to "exceeds" requirements | Next quarter |
| **Tier 3** | Differentiates from equally qualified candidates | This year |
| **Tier 4** | Minor value or validates existing knowledge | Opportunistic |

## Certification Coverage

| Domain | Certifications Covered |
|--------|----------------------|
| AWS | SA Associate/Professional, Developer, SysOps, DevOps Pro, Security, ML, GenAI, Data Engineer, Database, Networking |
| Security & GRC | CISSP, ISSAP, ISSEP, CCSP, CISM, CRISC, CGEIT, CISA, CSSLP, GSLC, Security+, CEH, OSCP |
| Cloud & Platform | CKA, CKAD, CKS, Terraform, FinOps Practitioner/Engineer, Azure, GCP equivalents |
| AI/ML | AWS GenAI, AWS ML Specialty, AWS ML Engineer, AAISM, Google ML Engineer, Azure AI |
| DevOps & Agile | AWS DevOps Pro, Azure DevOps, GitLab, PMP, SAFe, ITIL |

## Sample Output

`assets/sample-analysis.md` contains a complete analysis for a Senior Cloud Engineer targeting a Director of Platform Engineering role in financial services. It includes:

- Gap analysis identifying four certification gaps and four skill gaps
- Six certification recommendations across four priority tiers
- 12-month certification path with sequencing and overlap savings
- Investment summary: $2,863 total cost, 350 study hours, 5-6 weeks saved through overlap

## Analysis Principles

**Certifications are signals, not skills.** They tell hiring managers you invested time in a domain. They do not prove you can do the job.

**Required certs are table stakes.** ATS systems filter on them. Get them regardless of experience.

**Preferred certs are differentiators.** They move you from "meets requirements" to "exceeds requirements."

**Industry context matters.** CISSP is near-universal in financial services security leadership. It is less common in startups.

**Level-appropriate only.** A Director does not need Security+. A Junior Engineer does not need CGEIT.

**Certification fatigue is real.** 3-5 well-chosen certs across 6-12 months beats 15 certs that signal exam-taking ability rather than depth.

## Skill Structure

```
cert-path-advisor/
├── SKILL.md                              # Skill definition and analysis workflow
├── README.md                             # This file
├── references/
│   ├── aws.md                            # AWS certification map with role and industry mapping
│   ├── security-grc.md                   # Security/GRC certs with level appropriateness
│   ├── cloud-platform.md                 # Cloud, platform, DevOps, and agile certs
│   └── ai-ml.md                          # AI/ML certification landscape
└── assets/
    └── sample-analysis.md                # Full analysis: Sr Cloud Eng → Director Platform Eng (FSI)
```

## Relationship to Cert Study Planner

This skill answers "which certifications should I get?" The [Cert Study Planner](../cert-study-planner) answers "how do I prepare for this specific certification?" Use this skill first to select and prioritize, then use the Cert Study Planner to build a week-by-week study plan for each selected certification.

## License

MIT
