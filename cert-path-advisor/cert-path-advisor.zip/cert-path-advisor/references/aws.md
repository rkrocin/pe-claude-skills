# AWS Certifications Reference

## Certification Map

| Certification | Level | Exam Cost | Prep Time (Intermediate) | Hiring Signal |
|--------------|-------|-----------|-------------------------|---------------|
| Solutions Architect Associate | Associate | $150 | 4-6 weeks | Baseline AWS credibility |
| Solutions Architect Professional | Professional | $300 | 6-8 weeks | Deep architecture expertise |
| Developer Associate | Associate | $150 | 3-4 weeks | Hands-on development capability |
| SysOps Administrator Associate | Associate | $150 | 4-5 weeks | Operational AWS expertise |
| DevOps Engineer Professional | Professional | $300 | 6-8 weeks | CI/CD and automation mastery |
| Security Specialty | Specialty | $300 | 5-7 weeks | AWS security architecture depth |
| Machine Learning Specialty | Specialty | $300 | 6-8 weeks | ML/AI on AWS |
| Machine Learning Engineer Associate | Associate | $150 | 4-5 weeks | MLOps and production ML |
| GenAI Developer Professional | Professional | $300 | 5-6 weeks | GenAI application development |
| Data Engineer Associate | Associate | $150 | 4-5 weeks | Data pipelines and analytics |
| Database Specialty | Specialty | $300 | 5-6 weeks | Database architecture expertise |
| Advanced Networking Specialty | Specialty | $300 | 6-8 weeks | Network architecture depth |

## Dependencies and Overlap

```
Solutions Architect Associate
├── Solutions Architect Professional (40% overlap, save 2-3 weeks)
├── Security Specialty (25% overlap, save 1-2 weeks)
├── DevOps Engineer Professional (20% overlap)
└── Database Specialty (15% overlap)

Developer Associate
├── DevOps Engineer Professional (30% overlap)
└── GenAI Developer Professional (15% overlap)

ML Specialty
├── ML Engineer Associate (35% overlap, save 2 weeks)
└── GenAI Developer Professional (20% overlap, save 1 week)
```

## Role-to-Certification Mapping

| Target Role | Must Have | Strong Signal | Differentiator |
|-------------|----------|---------------|----------------|
| Cloud Architect | SA Professional | Security Specialty | Advanced Networking |
| Platform Engineer | SA Associate or Professional | DevOps Professional | Terraform Associate |
| Cloud Security Engineer | Security Specialty | SA Professional | CISSP (non-AWS) |
| DevOps Engineer | DevOps Professional | SA Associate | Developer Associate |
| Data Engineer | Data Engineer Associate | SA Associate | ML Specialty |
| ML/AI Engineer | ML Specialty or ML Engineer | GenAI Developer | SA Associate |
| Cloud Director/VP | SA Professional | Security Specialty | Multiple specialties |

## Industry Context

| Industry | High-Value AWS Certs | Rationale |
|----------|---------------------|-----------|
| Financial Services | SA Professional, Security Specialty | Regulatory depth, architecture scale |
| Healthcare | SA Professional, Security Specialty | HIPAA compliance alignment |
| Startup/Tech | Developer Associate, DevOps Professional | Velocity and automation focus |
| Government | SA Professional, Security Specialty | FedRAMP, compliance alignment |
| Enterprise (General) | SA Professional, DevOps Professional | Scale and operational maturity |
