# AI/ML Certifications Reference

## Certification Map

| Certification | Issuing Body | Level | Exam Cost | Prep Time (Intermediate) | Hiring Signal |
|--------------|-------------|-------|-----------|-------------------------|---------------|
| AWS GenAI Developer Professional | AWS | Professional | $300 | 5-6 weeks | GenAI application development with Bedrock |
| AWS ML Specialty | AWS | Specialty | $300 | 6-8 weeks | Full ML lifecycle on AWS |
| AWS ML Engineer Associate | AWS | Associate | $150 | 4-5 weeks | MLOps and production ML |
| AAISM | Various | Professional | Varies | 4-5 weeks | AI security and governance |
| Google Professional ML Engineer | Google | Professional | $200 | 6-8 weeks | ML on GCP (Vertex AI) |
| Azure AI Engineer Associate | Microsoft | Associate | $165 | 4-5 weeks | AI on Azure |
| Azure Data Scientist Associate | Microsoft | Associate | $165 | 5-6 weeks | Data science on Azure |
| TensorFlow Developer Certificate | Google | Associate | $100 | 4-6 weeks | TensorFlow implementation skills |
| Databricks ML Professional | Databricks | Professional | $200 | 4-5 weeks | ML on Databricks/Spark |

## Dependencies and Overlap

```
AWS ML Specialty
├── AWS ML Engineer Associate (35% overlap, save 2 weeks)
└── AWS GenAI Developer Professional (20% overlap, save 1 week)

AWS GenAI Developer Professional
└── AAISM (complementary: GenAI application + AI security)

Google Professional ML Engineer
└── TensorFlow Developer (30% overlap if TF is your framework)
```

## Role-to-Certification Mapping

| Target Role | Must Have | Strong Signal | Differentiator |
|-------------|----------|---------------|----------------|
| ML Engineer | AWS ML Specialty or Google ML Engineer | AWS ML Engineer Associate | GenAI Developer |
| AI/ML Platform Engineer | AWS GenAI Developer | AWS ML Specialty | CKA (ML infra) |
| Data Scientist | AWS ML Specialty or Azure Data Scientist | Databricks ML Professional | TensorFlow Developer |
| AI Security Engineer | AAISM | CISSP + GenAI Developer | AWS Security Specialty |
| Platform Director (AI-enabled) | AWS GenAI Developer | AWS ML Specialty | AAISM |
| Engineering Leader (AI strategy) | AWS GenAI Developer | AAISM | AWS ML Specialty |

## Emerging vs. Established

| Category | Established (Widely Recognized) | Emerging (Growing Recognition) |
|----------|-------------------------------|-------------------------------|
| Cloud ML | AWS ML Specialty, Google ML Engineer | AWS ML Engineer Associate |
| GenAI | AWS GenAI Developer Professional | AAISM |
| Data Science | Azure Data Scientist, Databricks ML Pro | TensorFlow Developer |

## Industry Context

| Industry | High-Value AI/ML Certs | Rationale |
|----------|------------------------|-----------|
| Financial Services | AWS GenAI Developer, AAISM | GenAI application + AI governance/risk |
| Healthcare | AWS ML Specialty, Azure AI Engineer | ML for clinical applications |
| Technology/SaaS | AWS ML Specialty, Google ML Engineer | Production ML at scale |
| Enterprise | AWS GenAI Developer | Practical GenAI enablement |
| Government | AWS ML Specialty | FedRAMP-aligned ML |

## AI Certification Path Strategies

**For platform engineers adding AI enablement:**
1. AWS GenAI Developer Professional (practical, application-focused)
2. AAISM (governance and security for AI systems)

**For ML engineers deepening expertise:**
1. AWS ML Specialty (comprehensive ML lifecycle)
2. AWS ML Engineer Associate (MLOps focus)
3. AWS GenAI Developer Professional (GenAI layer)

**For leaders building AI strategy:**
1. AWS GenAI Developer Professional (understand the technology)
2. AAISM (understand the risks)
