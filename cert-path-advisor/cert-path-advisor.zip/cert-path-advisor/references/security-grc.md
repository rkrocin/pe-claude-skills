# Security & GRC Certifications Reference

## Certification Map

| Certification | Issuing Body | Level | Exam Cost | Prep Time (Intermediate) | Hiring Signal |
|--------------|-------------|-------|-----------|-------------------------|---------------|
| CISSP | (ISC)2 | Expert | $749 | 8-10 weeks | Gold standard for security leadership |
| ISSAP | (ISC)2 | Expert | $599 | 6-8 weeks | Security architecture depth (rare, high signal) |
| ISSEP | (ISC)2 | Expert | $599 | 6-8 weeks | Security engineering depth (rare, high signal) |
| CCSP | (ISC)2 | Professional | $599 | 4-5 weeks (with CISSP) | Cloud security expertise |
| CISM | ISACA | Professional | $575-760 | 5-6 weeks | Security management and governance |
| CRISC | ISACA | Professional | $575-760 | 5-6 weeks | IT risk management |
| CGEIT | ISACA | Professional | $575-760 | 5-6 weeks | Enterprise IT governance |
| CISA | ISACA | Professional | $575-760 | 5-6 weeks | IT audit expertise |
| CSSLP | (ISC)2 | Professional | $599 | 5-6 weeks | Secure software lifecycle |
| GSLC | GIAC/SANS | Professional | ~$2,500 (with training) | 4-5 weeks | Security leadership (SANS perspective) |
| Security+ | CompTIA | Foundation | $392 | 3-4 weeks | Entry-level security baseline |
| CEH | EC-Council | Professional | $1,199 | 4-5 weeks | Ethical hacking / pen testing |
| OSCP | OffSec | Expert | $1,599+ | 10-16 weeks | Hands-on penetration testing mastery |

## Dependencies

```
CISSP (prerequisite for concentrations)
├── ISSAP (requires active CISSP + 2 years architecture experience)
├── ISSEP (requires active CISSP + 2 years engineering experience)
└── CCSP (40% overlap with CISSP, significant prep time savings)

CISM
├── CRISC (25% overlap in risk and governance domains)
└── CGEIT (20% overlap in governance domain)

Security+ (foundation)
└── Stepping stone to CISSP, CCSP, or CEH
```

## Role-to-Certification Mapping

| Target Role | Must Have | Strong Signal | Differentiator |
|-------------|----------|---------------|----------------|
| CISO / VP Security | CISSP | CISM, CRISC | ISSAP, CGEIT |
| Security Architect | CISSP | ISSAP, CCSP | AWS Security Specialty |
| Security Engineer | CISSP or CCSP | AWS Security Specialty | CSSLP, CKS |
| GRC Manager | CISM | CRISC, CISA | CGEIT |
| Risk Manager | CRISC | CISM | CGEIT |
| Security Director | CISSP | CISM | ISSAP or ISSEP |
| Platform Eng Director (FSI) | CISSP | CCSP | CISM, CRISC |
| Pen Tester | OSCP | CEH | GPEN |

## Industry Context

| Industry | High-Value Security Certs | Rationale |
|----------|--------------------------|-----------|
| Financial Services | CISSP, CISM, CRISC | Regulatory-driven, governance-heavy |
| Healthcare | CISSP, CCSP | HIPAA alignment, cloud security |
| Government/Defense | CISSP (required for many roles), GSLC | DoD 8570 mandate |
| Technology/SaaS | CCSP, AWS Security Specialty | Cloud-native security focus |
| Consulting | CISSP, CISM, CISA | Broad client credibility |

## Level Appropriateness

| Career Level | Appropriate Certs | Inappropriate Certs |
|-------------|-------------------|---------------------|
| Junior (0-3 years) | Security+, CEH | CISSP (lacks prerequisite experience) |
| Mid (3-7 years) | CISSP, CCSP, CSSLP | CGEIT (too governance-focused for IC) |
| Senior IC (7+ years) | CISSP, CCSP, OSCP, ISSEP | CGEIT (management-focused) |
| Manager (5+ years mgmt) | CISSP, CISM | OSCP (too hands-on for management) |
| Director/VP | CISSP, CISM, CRISC, CGEIT | Security+ (below level) |
