# Cloud, Platform & DevOps Certifications Reference

## Cloud Platform Certifications

| Certification | Issuing Body | Level | Exam Cost | Prep Time (Intermediate) | Hiring Signal |
|--------------|-------------|-------|-----------|-------------------------|---------------|
| CKA | CNCF/LF | Professional | $395 | 5-7 weeks | Kubernetes administration expertise |
| CKAD | CNCF/LF | Associate-Pro | $395 | 4-5 weeks | Kubernetes application development |
| CKS | CNCF/LF | Professional | $395 | 5-6 weeks | Kubernetes security depth |
| Terraform Associate | HashiCorp | Associate | $70.50 | 2-3 weeks | IaC baseline credibility |
| Terraform Engineer (planned) | HashiCorp | Professional | TBD | 4-6 weeks | IaC depth at scale |
| FinOps Certified Practitioner | FinOps Foundation | Foundation | $300 | 2-3 weeks | Cloud cost management awareness |
| FinOps Certified Engineer | FinOps Foundation | Professional | $600 | 3-4 weeks | Cloud cost management depth |
| FINOS FCFD | FINOS | Foundation | Varies | 1-2 weeks | Financial services open source |
| Azure Administrator Associate | Microsoft | Associate | $165 | 4-6 weeks | Azure operational baseline |
| Azure Solutions Architect Expert | Microsoft | Expert | $165x2 | 8-10 weeks | Azure architecture depth |
| GCP Professional Cloud Architect | Google | Professional | $200 | 6-8 weeks | GCP architecture depth |
| GCP Professional Cloud DevOps Engineer | Google | Professional | $200 | 5-6 weeks | GCP operations depth |

## Dependencies

```
CKA (prerequisite for CKS)
├── CKS (requires active CKA)
└── CKAD (30% overlap with CKA, can be taken in either order)

FinOps Practitioner
└── FinOps Engineer (requires Practitioner, 30% overlap)

Terraform Associate
└── Terraform Engineer (planned, builds on Associate)

Azure Administrator
└── Azure Solutions Architect Expert (builds on Administrator)
```

## Role-to-Certification Mapping

| Target Role | Must Have | Strong Signal | Differentiator |
|-------------|----------|---------------|----------------|
| Platform Engineer | CKA or AWS SA Associate | Terraform Associate | FinOps Practitioner |
| SRE | CKA | AWS SA Associate/Professional | CKS |
| DevOps Engineer | AWS DevOps Pro or CKA | Terraform Associate | GitLab Certified |
| Infrastructure Engineer | AWS SA Associate | Terraform Associate | CKA |
| FinOps Analyst/Manager | FinOps Practitioner | FinOps Engineer | AWS SA Associate |
| Cloud Architect (multi-cloud) | AWS SA Pro + Azure/GCP equivalent | CKA | Terraform Associate |
| Platform Director (FSI) | AWS SA Professional | CKA, FinOps | CISSP |

## DevOps & Agile Certifications

| Certification | Issuing Body | Level | Exam Cost | Prep Time | Hiring Signal |
|--------------|-------------|-------|-----------|-----------|---------------|
| AWS DevOps Professional | AWS | Professional | $300 | 6-8 weeks | CI/CD and automation on AWS |
| Azure DevOps Engineer Expert | Microsoft | Expert | $165 | 5-6 weeks | Azure DevOps pipeline expertise |
| GitLab Certified Associate | GitLab | Associate | Free | 2-3 weeks | GitLab CI/CD proficiency |
| PMP | PMI | Professional | $405-555 | 8-12 weeks | Project management standard |
| SAFe Agilist | Scaled Agile | Professional | $995 | 2-3 weeks (with training) | Enterprise agile scaling |
| ITIL 4 Foundation | Axelos | Foundation | $363 | 2-3 weeks | IT service management baseline |

## Industry Context

| Industry | High-Value Platform Certs | Rationale |
|----------|--------------------------|-----------|
| Financial Services | AWS SA Pro, CKA, FinOps, Terraform | Regulated cloud at scale |
| Technology/SaaS | CKA, CKAD, Terraform, AWS DevOps | Cloud-native velocity |
| Enterprise | AWS SA Pro, Azure Architect, ITIL | Multi-cloud, ITSM alignment |
| Startup | CKA, Terraform, AWS DevOps | Speed and infrastructure automation |
| Government | AWS SA Pro (GovCloud), Azure Gov, ITIL | Compliance and process rigor |

## Multi-Cloud Credential Strategies

For roles requiring multi-cloud expertise:

**Primary cloud deep + secondary cloud breadth:**
- Deep: AWS SA Professional (most market demand)
- Breadth: Azure Administrator or GCP Professional Architect
- Bridge: CKA (cloud-agnostic container orchestration)
- Governance: Terraform Associate (multi-cloud IaC)

**Avoid certification dilution:**
- Having one Professional-level cert in your primary cloud + one Associate-level in a secondary cloud is more credible than three Associate-level certs across three clouds.
- CKA and Terraform bridge cloud platforms more effectively than collecting cloud-specific certs across providers.
