# Standard ADR Format

Full-weight format for consequential architectural decisions. Use by default.

## Template

```markdown
# ADR-NNN: [Concise Decision Title]

## Status

[One of: Proposed | Accepted | Deprecated | Superseded by ADR-NNN]

- Proposed: decision is under discussion, not yet finalized
- Accepted: decision is finalized and being implemented
- Deprecated: decision is no longer relevant (technology retired, context changed)
- Superseded: replaced by a newer decision (link to the replacement)

## Date

[YYYY-MM-DD of when the decision was accepted, or "Proposed" date if pending]

## Participants

[Optional. List individuals or teams involved in the decision]

## Context

[2-4 paragraphs explaining:]

Paragraph 1: The business or technical problem driving this decision. What is
happening that requires a decision now? Include quantitative triggers if available
(traffic growth, latency thresholds, cost increases, compliance deadlines).

Paragraph 2: The technical landscape and constraints. What exists today? What
are the non-negotiable requirements (latency, compliance, budget, team skills)?
What prior decisions constrain or influence this one?

Paragraph 3 (optional): The organizational context. Team size, skill distribution,
hiring plans, cross-team dependencies, timeline pressures.

## Options Considered

### Option 1: [Name]

[1-2 paragraph description of the approach]

**Strengths:**
- [Genuine advantage with specifics]
- [Another advantage]

**Weaknesses:**
- [Genuine limitation with specifics]
- [Another limitation]

**Estimated effort:** [T-shirt size or time range]
**Estimated ongoing cost:** [Monthly/annual run cost if applicable]

### Option 2: [Name]

[Same structure as Option 1]

### Option 3: [Name] (optional)

[Same structure. Include 2-4 options total. More than 4 suggests the decision
space is not well enough understood.]

### Option N: Status Quo / Do Nothing (include when relevant)

[What happens if no action is taken. This is a legitimate option and should be
evaluated honestly.]

## Decision

[First sentence: state the decision clearly.]
[1-2 additional sentences: explain the primary reasoning in terms of which
tradeoffs were prioritized.]

Example: "We will use Amazon Aurora PostgreSQL as the primary data store for the
order service. Relational integrity and ACID compliance are critical for financial
transactions, and Aurora's managed operations reduce the DBA burden on a team
that has no dedicated database administrator."

## Evaluation Matrix (optional, for decisions with 3+ options)

| Criteria (Weight)           | Option 1 | Option 2 | Option 3 |
|-----------------------------|----------|----------|----------|
| [Criterion] (NN%)           | N/5      | N/5      | N/5      |
| [Criterion] (NN%)           | N/5      | N/5      | N/5      |
| [Criterion] (NN%)           | N/5      | N/5      | N/5      |
| [Criterion] (NN%)           | N/5      | N/5      | N/5      |
| **Weighted Score**          | **N.NN** | **N.NN** | **N.NN** |

## Consequences

### Positive
- [What improves or becomes possible]
- [What gets easier for the team]
- [What risks are mitigated]

### Negative
- [What gets harder or more complex]
- [What costs increase]
- [What capabilities are limited or deferred]

### Risks
- [Condition]: [What could go wrong]. Mitigation: [How to reduce the risk]
- [Condition]: [What could go wrong]. Mitigation: [How to reduce the risk]

### Technical Debt Introduced
[If this decision knowingly creates future work, document it here. Include
what would trigger the need to revisit (e.g., "if throughput exceeds 10K TPS,
we will need to re-evaluate the data store choice").]

## Follow-up Actions

- [ ] [Specific action] - Owner: [name/team] - Target: [date or sprint]
- [ ] [Specific action] - Owner: [name/team] - Target: [date or sprint]
- [ ] [Specific action] - Owner: [name/team] - Target: [date or sprint]

## References

- [Link to relevant RFC, design doc, benchmark, or external documentation]
- [Link to related ADR if applicable]
- [Link to relevant vendor documentation or comparison]
```

## Title Conventions

Good titles are specific and describe the decision, not the problem:

- "Use Aurora PostgreSQL for Order Service Data Store" (specific decision)
- "Adopt Trunk-Based Development for Platform Services" (process decision)
- "Replace RabbitMQ with Amazon SQS for Async Messaging" (migration decision)
- "Implement OIDC Federation for CI/CD Pipeline AWS Access" (security decision)

Avoid vague titles:
- "Database Decision" (which database? which service?)
- "Messaging Architecture" (what about it?)
- "Security Improvements" (what specifically?)

## Status Lifecycle

```
Proposed --> Accepted --> [Active indefinitely]
                     \--> Deprecated (context no longer applies)
                     \--> Superseded by ADR-NNN (replaced by newer decision)
```

An ADR is never deleted. Deprecated and superseded ADRs remain in the repository as historical documentation. They explain why things were built the way they were, even if the approach has since changed.
