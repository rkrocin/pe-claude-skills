# Lightweight ADR Format

Compact format for less consequential decisions or teams that prefer brevity. Use when the user requests a short ADR or when the decision is relatively straightforward with limited options.

## Template

```markdown
# ADR-NNN: [Decision Title]

**Status**: [Accepted | Proposed]  
**Date**: [YYYY-MM-DD]

**Context**: [2-3 sentences describing the problem and constraints. Why does this
decision need to be made? What are the key forces at play?]

**Decision**: [1-2 sentences stating the choice and the primary reason. Be direct.]

**Alternatives considered**: [Brief list of other options and why they were not chosen.
One sentence per alternative is sufficient.]

**Consequences**:
- [Positive impact]
- [Positive impact]
- [Negative impact or accepted tradeoff]
- [Risk to monitor]

**Follow-up**: [1-2 specific next steps, or "None" if the decision is self-contained]
```

## Example

```markdown
# ADR-012: Use Pino for Structured Logging in Node.js Services

**Status**: Accepted  
**Date**: 2026-03-15

**Context**: Our Node.js services use console.log with inconsistent formats, making
log aggregation and alerting unreliable. We need a structured logging library that
outputs JSON and supports log levels without significant performance overhead.

**Decision**: We will use Pino as our standard logging library for all Node.js
services. It has the lowest serialization overhead of the mature options and its
JSON output integrates directly with our CloudWatch log processing pipeline.

**Alternatives considered**:
- Winston: More popular but 5-10x slower in benchmarks. Feature-rich but we don't need the extra transports.
- Bunyan: Mature but effectively unmaintained since 2021.
- console.log with wrapper: Insufficient structure and no log level support.

**Consequences**:
- Consistent JSON log format across all Node.js services
- Sub-millisecond logging overhead even under high throughput
- Pino's async mode requires careful handling during process shutdown to avoid lost logs
- Team needs to learn Pino's child logger pattern (minor ramp-up)

**Follow-up**: Update the Node.js Golden Path template to include Pino configuration.
```

## When to Use Lightweight vs. Standard

Use lightweight when:
- The decision affects a single service or team
- There are only 2 options and the choice is relatively clear
- The decision is easily reversible (weeks, not months, to change)
- The team has strong ADR adoption and wants to keep velocity high

Use standard when:
- The decision affects multiple teams or services
- There are 3+ viable options with meaningful tradeoffs
- The decision is difficult or expensive to reverse
- Compliance, security, or significant cost implications exist
- The decision establishes a precedent or pattern
