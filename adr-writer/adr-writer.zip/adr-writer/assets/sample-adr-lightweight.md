# ADR-007: Use Structlog for Python Service Logging

**Status**: Accepted
**Date**: 2026-02-10

**Context**: Python services across the platform use a mix of the standard `logging` module with custom formatters and direct `print()` calls. Log output is inconsistent, making CloudWatch Logs Insights queries unreliable and incident investigation slow. We need a standard structured logging library that outputs JSON, supports context binding (request ID, trace ID), and integrates with our existing log aggregation pipeline.

**Decision**: We will standardize on `structlog` for all Python services. It produces JSON output by default, supports context binding through bound loggers, and wraps the standard library logger so existing `logging.getLogger()` calls continue to work during migration. Performance benchmarks show negligible overhead compared to the standard library.

**Alternatives considered**:
- `python-json-logger`: Adds JSON formatting to the standard logger but lacks structlog's context binding and processor pipeline. Would require custom middleware for request-scoped context.
- Standard `logging` with custom JSON formatter: Maximum control but requires each team to build and maintain their own formatter. Inconsistency is the problem we are solving.
- `loguru`: Developer-friendly but opinionated about output format and less suited to structured JSON in production. Better for CLI tools than services.

**Consequences**:
- Consistent JSON log format across all Python services within one quarter
- Request-scoped context (trace ID, request ID, user context) automatically included in every log line
- CloudWatch Logs Insights queries become reliable across services
- Existing services require migration from `logging` to `structlog` (estimated 1-2 hours per service)
- Team needs to learn structlog's processor pipeline concept (minor ramp-up, well-documented)

**Follow-up**: Update the Python REST API Golden Path template to include structlog configuration and request logging middleware.
