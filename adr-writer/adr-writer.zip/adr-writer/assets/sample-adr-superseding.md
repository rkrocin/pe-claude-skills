# ADR-015: Migrate from Jenkins to GitHub Actions for CI/CD

## Status

Accepted

## Date

2026-03-20

## Supersedes

ADR-004: Adopt Jenkins for CI/CD Pipelines (2019-06-15, now status: Superseded by ADR-015)

## Context

ADR-004 established Jenkins as the CI/CD platform in 2019 when the team was deploying to on-premises infrastructure and needed extensive plugin support for legacy integration points. Three years later, the landscape has changed materially:

The organization completed its cloud migration to AWS in 2024. All production workloads now run on ECS Fargate or Lambda. The on-premises integration points that drove the Jenkins decision have been retired. Meanwhile, Jenkins operational burden has become a persistent drag on the platform team: controller upgrades, plugin compatibility issues, agent fleet management, and credential rotation consume approximately 15 hours per week of engineering time.

GitHub is already the source control and code review platform. GitHub Actions provides CI/CD capabilities natively within the same tool, eliminating context-switching between systems. OIDC-based AWS authentication removes the need for static credentials entirely.

## Options Considered

### Option 1: GitHub Actions

Native CI/CD within GitHub. YAML-based workflow definitions stored alongside application code. Managed runners or self-hosted runners.

**Strengths:**
- Pipeline definitions live in the same repository as the code (no separate Jenkins Job DSL or Jenkinsfile management)
- OIDC integration with AWS eliminates static credential management
- GitHub-managed runners eliminate agent fleet operations
- Native integration with pull requests, branch protection, and environments
- Marketplace provides pre-built actions for common tasks

**Weaknesses:**
- GitHub-managed runner minutes have cost implications at scale
- Some complex pipeline patterns (matrix builds with shared state, dynamic stage generation) are less ergonomic than Jenkins Pipeline
- Vendor lock-in to GitHub (acceptable given existing GitHub dependency)

### Option 2: Maintain Jenkins with Modernization

Invest in upgrading Jenkins: migrate to Kubernetes-based agents, adopt Configuration as Code plugin, reduce plugin footprint.

**Strengths:**
- No migration effort for existing pipelines
- Team has deep Jenkins expertise
- Self-hosted; no per-minute runner costs

**Weaknesses:**
- Does not address the fundamental operational burden (still requires controller management, plugin updates, security patching)
- Kubernetes-based agents add Kubernetes operational complexity
- Perpetuates split between source control (GitHub) and CI/CD (Jenkins)

## Decision

We will migrate from Jenkins to GitHub Actions over a 3-month phased rollout. The operational burden of Jenkins (15 hours/week) is unsustainable for a platform team that should be investing that time in developer experience improvements. GitHub Actions eliminates agent fleet management, credential rotation, and plugin compatibility work while placing pipeline definitions alongside the code they build.

Migration will proceed team-by-team, starting with services that have the simplest Jenkins pipelines. Jenkins will be decommissioned after all pipelines have been migrated and validated in production.

## Consequences

### Positive
- Eliminates ~15 hours/week of Jenkins operational overhead
- Pipeline definitions co-located with application code (single source of truth)
- OIDC authentication removes static AWS credential management
- Developers manage their own pipelines without platform team involvement for routine changes
- GitHub Environments provide native approval gates for production deployments

### Negative
- Migration effort: estimated 3 months across 35 pipelines
- Some complex Jenkins pipelines may need redesign rather than direct translation
- GitHub-managed runner costs estimated at $800-1,200/month at current build volume
- Team loses Jenkins expertise investment (sunk cost, but relevant for hiring signals)

### Risks
- **GitHub outage impacts CI/CD**: GitHub availability directly controls deployment capability. Mitigation: critical hotfix deployments can use local builds pushed to ECR directly (emergency procedure, not standard workflow).
- **Runner minute costs grow faster than expected**: If build volume increases significantly, costs may exceed estimates. Mitigation: evaluate self-hosted runners on ECS if monthly costs exceed $2,000.

## Follow-up Actions

- [ ] Create GitHub Actions Golden Path template for ECS Fargate services - Owner: Platform Engineering - Target: Week 1-2
- [ ] Migrate pilot team (Payments) pipelines to GitHub Actions - Owner: Platform Engineering + Payments - Target: Week 3-4
- [ ] Establish OIDC federation between GitHub and AWS accounts - Owner: Platform Engineering + Security - Target: Week 1
- [ ] Document emergency deployment procedure (bypass CI/CD) - Owner: SRE - Target: Week 2
- [ ] Decommission Jenkins after final pipeline migration - Owner: Platform Engineering - Target: Week 12

## References

- [GitHub Actions Documentation](https://docs.github.com/en/actions)
- [GitHub OIDC with AWS](https://docs.github.com/en/actions/deployment/security-hardening-your-deployments/configuring-openid-connect-in-amazon-web-services)
- ADR-004: Adopt Jenkins for CI/CD Pipelines (Superseded)
