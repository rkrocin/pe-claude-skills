---
name: platform-product-brief
description: >
  Generate product briefs for internal platform capabilities, treating platform features as products
  with defined users, success metrics, and go/no-go criteria. Use this skill whenever the user wants
  to write a product brief, one-pager, feature proposal, or investment case for an internal platform
  capability, developer tool, infrastructure feature, or shared service. Also trigger when the user
  asks about product thinking for platform teams, how to pitch a platform initiative, how to write
  a platform feature proposal, or how to structure a business case for internal tooling investment.
  Supports platform engineering, infrastructure, DevEx, and shared services teams operating as
  product organizations.
---

# Platform Product Brief Generator

Generate product briefs for internal platform capabilities with problem statements, user personas, success metrics, technical approach, and go/no-go criteria.

## What This Skill Does

Takes a platform capability idea and generates:

1. **Product Brief** with problem statement, user personas, proposed solution, and success metrics
2. **Investment Case** framing the capability in terms leadership understands (cost, velocity, risk)
3. **Technical Approach** at the right altitude for a brief (not a design doc)
4. **Go/No-Go Criteria** defining how to evaluate whether to continue after an initial phase
5. **Risks and Dependencies** identifying what could block or derail the initiative

## Why Product Briefs for Platforms

Platform teams that operate as project shops build what stakeholders ask for. Platform teams that operate as product organizations build what their users need, validated by evidence. The product brief is the bridge: it forces clarity about who the user is, what problem is being solved, how success is measured, and when to stop if the hypothesis is wrong.

A good product brief for a platform capability does three things:
- Makes the problem concrete enough that leadership can evaluate the investment
- Defines success in measurable terms so the team knows when they have won
- Establishes a kill criteria so the organization does not invest indefinitely in something that is not working

## Gathering Inputs

| Parameter | Required | Description |
|-----------|----------|-------------|
| Capability idea | Yes | What the platform team wants to build or improve |
| Target users | Recommended | Who will use this (engineers, SREs, security, leadership) |
| Problem evidence | Helpful | Data showing the problem exists (support tickets, survey results, time studies, incident data) |
| Constraints | Helpful | Budget, timeline, team capacity, tech stack, compliance requirements |
| Prior attempts | Optional | What has been tried before and why it did not work |
| Stakeholder audience | Optional | Who will read the brief (VP, CIO, peer directors, the team itself) |

Accept input in any format. The user might describe a fully formed idea or just say "we need to do something about our terrible deployment pipeline." Both are valid starting points.

## Product Brief Structure

Read `references/brief-format.md` for the full template. The standard structure:

```
# Platform Product Brief: [Capability Name]

## The Problem
[What is broken, slow, risky, or missing. Quantified with evidence.]

## Who Is Affected
[User personas with their specific pain points]

## Proposed Solution
[What we will build, at the right altitude for a brief]

## Success Metrics
[How we measure whether this worked]

## Investment Required
[What it costs: people, time, money, opportunity cost]

## Technical Approach
[High-level architecture and key decisions]

## Risks & Dependencies
[What could go wrong or block us]

## Go/No-Go Criteria
[How we decide whether to continue after the first phase]

## Alternatives Considered
[What else we could do, including doing nothing]
```

## Section Guidance

### The Problem

This is the most important section. If the problem is not compelling, the rest does not matter.

**Structure the problem in three layers:**

1. **The pain**: What is happening today that is bad? Be specific. "Deployments are slow" is weak. "Engineers wait an average of 47 minutes for deployment pipelines to complete, spending approximately 3,200 hours per quarter in idle wait time across 200 engineers" is compelling.

2. **The consequence**: What does the pain cause? Connect to outcomes leadership cares about: velocity (time to market), cost (wasted engineering hours), risk (security exposure, compliance gaps), quality (incident rate, MTTR).

3. **The trend**: Is the problem getting worse? Stable problems are tolerable. Growing problems demand action. "Pipeline wait times have increased 30% quarter-over-quarter as the number of microservices has grown from 80 to 140."

**Evidence types that strengthen the problem statement:**
- Time studies (how long engineers spend on the painful activity)
- Support ticket volume (how often engineers ask for help with the current state)
- Survey data (developer experience NPS, satisfaction scores)
- Incident data (how often the current state causes or extends incidents)
- Benchmark comparison (how peer organizations handle the same problem)

If the user does not have evidence, note what data should be collected to validate the problem before committing to a solution.

### Who Is Affected

Define 2-3 user personas. Platform capabilities typically serve:

**Primary users** (direct, daily interaction):
- Application engineers writing and deploying code
- SREs managing reliability and incident response
- Security engineers enforcing controls and responding to findings

**Secondary users** (indirect benefit):
- Engineering managers tracking team productivity
- Directors/VPs reporting on engineering metrics
- Compliance/audit teams requiring evidence

**Anti-users** (explicitly NOT the target):
- Identify who this is NOT for, to prevent scope creep

For each persona, describe:
- Their role and daily workflow
- The specific pain they experience today
- What "better" looks like for them
- How frequently they encounter the problem

### Proposed Solution

Describe the capability at the right altitude: detailed enough that a technical reader understands the approach, abstract enough that a non-technical reader understands the value.

**Include:**
- What the user experience looks like (how do engineers interact with this?)
- Key architectural decisions at a high level
- What changes for the user (before/after)
- Phased delivery if applicable (MVP, v1, v2)

**Do not include:**
- Detailed design (that is a separate design doc)
- Implementation plan (that is a separate project plan)
- Technology comparisons (that is a separate ADR)

### Success Metrics

Define 3-5 metrics that prove the capability is working. Follow the hierarchy:

**Adoption metrics** (are people using it?):
- Monthly active users
- Percentage of eligible teams onboarded
- Feature utilization rate

**Efficiency metrics** (is it making things faster?):
- Time saved per engineer per week
- Reduction in manual steps or support tickets
- Pipeline execution time reduction

**Quality metrics** (is it making things better?):
- DORA metrics improvement (deployment frequency, lead time, MTTR, change failure rate)
- Incident rate reduction
- Compliance finding reduction

**Satisfaction metrics** (do people like it?):
- Developer experience NPS
- User satisfaction score
- Voluntary adoption rate (for non-mandated capabilities)

Each metric needs:
- Current baseline (where we are today)
- Target (where we want to be)
- Measurement method (how we will track it)
- Timeline (when we expect to see improvement)

### Investment Required

Be honest about cost. Platform leaders lose credibility when they underestimate investment.

**People**: How many engineers, for how long? Is this dedicated headcount or shared capacity?
**Timeline**: How long until MVP? Until full capability? Include ramp-up time.
**Infrastructure**: Any new cloud resources, tooling licenses, or third-party services?
**Opportunity cost**: What will this team NOT be doing while building this? This is often the most important cost.

Frame the investment against the problem cost. "This capability requires 3 engineers for 2 quarters (~$300K fully loaded). The problem it addresses costs the organization approximately $1.2M per year in wasted engineering time. Expected payback period: 4 months after launch."

### Technical Approach

High-level architecture at the brief level. Include:
- Key components and how they interact
- Build vs. buy decisions (with brief rationale)
- Integration points with existing systems
- Technology choices that are already decided vs. still open

Reference the ADR Writer skill if detailed architecture decisions need separate documentation.

### Risks & Dependencies

**Technical risks**: Can we build this? What is the hardest technical challenge?
**Adoption risks**: Will engineers use it? What is the change management plan?
**Dependency risks**: What do we need from other teams? What could block us?
**Staffing risks**: Do we have the right skills? Do we need to hire?
**Timeline risks**: What could push the timeline? What has the most schedule uncertainty?

For each risk, include likelihood (low/medium/high), impact (low/medium/high), and a mitigation strategy.

### Go/No-Go Criteria

Define specific, measurable criteria for evaluating whether to continue after the initial phase (typically 4-8 weeks or after MVP):

**Go criteria** (continue investing):
- MVP delivered on time
- Early adoption exceeds N users or N% of target
- User feedback is positive (NPS > X)
- No blocking technical risks materialized

**No-go criteria** (stop and reassess):
- MVP significantly delayed (>2 weeks beyond plan)
- Adoption below N users after 4 weeks of availability
- User feedback reveals a fundamental design flaw
- Technical approach proves infeasible or prohibitively complex

**Pivot criteria** (change approach but continue):
- Users adopt but use it differently than expected
- Core value proposition validated but scope needs adjustment
- Alternative technical approach needed

The go/no-go criteria must be agreed upon BEFORE work begins. They prevent the sunk-cost fallacy that keeps teams investing in initiatives that are not working.

### Alternatives Considered

Include 2-3 alternatives, always including "do nothing":

**Do nothing**: What happens if we do not build this? Is the status quo sustainable? Sometimes documenting the cost of inaction is the most persuasive argument.

**Buy/adopt**: Is there an existing tool (open source or commercial) that solves this? Why build instead?

**Minimal alternative**: Is there a smaller investment that addresses the core pain without the full solution? Sometimes a script, a documentation page, or a process change is enough.

## Output Variants

### Standard Brief (Default)
Full document with all sections. Suitable for director-to-VP level review and team alignment.

### Executive One-Pager
Condensed to a single page:
- Problem + consequence (3 sentences)
- Proposed solution (2 sentences)
- Investment and payback (2 sentences)
- Top 3 success metrics
- Key risk and mitigation
- Ask (what you need from leadership)

### Team Kickoff Brief
Focused on what the building team needs:
- Problem context and user personas
- Proposed solution and technical approach
- Success metrics and measurement plan
- Phase 1 scope and go/no-go criteria
- Known risks and open questions

Generate the variant the user requests, or default to the standard brief.

## Edge Cases

- **Vague idea**: If the user has only a vague sense of what to build ("we need better observability"), use the problem section to sharpen the idea before proposing a solution. Ask what specific pain points exist and what evidence supports them.
- **Solution already decided**: If the user already knows what they want to build and just needs the brief, focus on framing the problem and investment case rather than exploring alternatives. Note in the alternatives section that the solution has been predetermined.
- **Multiple capabilities**: If the idea is actually several distinct capabilities, recommend splitting into separate briefs with a shared problem statement. Each capability should have its own success metrics and go/no-go criteria.
- **Compliance-driven capability**: If the capability is mandated by regulation or audit finding, the "do nothing" alternative should quantify the regulatory risk rather than dismissing it. The brief still adds value by defining scope, metrics, and phasing.
