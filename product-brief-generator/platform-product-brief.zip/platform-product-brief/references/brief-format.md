# Platform Product Brief Format Reference

## Standard Brief Template

```markdown
# Platform Product Brief: [Capability Name]

**Author**: [Name/Team]
**Date**: [Date]
**Status**: [Draft | Under Review | Approved | In Progress | Completed]
**Sponsor**: [VP/Director who owns the investment decision]

---

## The Problem

### The Pain
[2-3 sentences: What is broken, slow, risky, or missing today? Be specific
with numbers.]

### The Consequence
[2-3 sentences: What does this pain cause in terms of velocity, cost, risk,
or quality? Connect to business outcomes.]

### The Trend
[1-2 sentences: Is the problem stable or getting worse? What is driving the
trend?]

### Evidence
| Signal | Data Point | Source |
|--------|-----------|--------|
| [Type] | [Specific metric or observation] | [Where this data comes from] |
| [Type] | [Specific metric or observation] | [Source] |
| [Type] | [Specific metric or observation] | [Source] |

---

## Who Is Affected

### Primary Users
**[Persona Name]** - [Role]
- Current pain: [What they experience today]
- Frequency: [How often they encounter the problem]
- Impact: [What the problem costs them]

**[Persona Name]** - [Role]
- Current pain: [...]
- Frequency: [...]
- Impact: [...]

### Secondary Users
- [Role]: [How they benefit indirectly]

### Anti-Users
- [Who this is explicitly NOT for and why]

---

## Proposed Solution

### Overview
[3-5 sentences: What we will build and what the user experience looks like]

### Before / After

| Dimension | Before | After |
|-----------|--------|-------|
| [Workflow step] | [Current state] | [Future state] |
| [Workflow step] | [Current state] | [Future state] |
| [Workflow step] | [Current state] | [Future state] |

### Phased Delivery

**Phase 1 - MVP** ([timeline]):
- [Capability 1]
- [Capability 2]
- [Go/No-Go checkpoint]

**Phase 2 - v1** ([timeline]):
- [Capability 3]
- [Capability 4]

**Phase 3 - Scale** ([timeline]):
- [Capability 5]
- [Full rollout]

---

## Success Metrics

| Metric | Baseline | Target | Measurement | Timeline |
|--------|----------|--------|-------------|----------|
| [Adoption metric] | [Current] | [Target] | [How measured] | [When] |
| [Efficiency metric] | [Current] | [Target] | [How measured] | [When] |
| [Quality metric] | [Current] | [Target] | [How measured] | [When] |
| [Satisfaction metric] | [Current] | [Target] | [How measured] | [When] |

---

## Investment Required

| Category | Estimate | Notes |
|----------|----------|-------|
| People | [N engineers x N quarters] | [Dedicated or shared] |
| Timeline | [MVP: X weeks, v1: X months] | [Key milestones] |
| Infrastructure | [$X/month] | [New services or resources] |
| Tooling/Licenses | [$X/year] | [Third-party costs] |
| **Total (Year 1)** | **[$X]** | |

**Opportunity Cost**: [What the team will not be doing]

**Payback Analysis**: [Investment vs. problem cost, expected payback period]

---

## Technical Approach

### Architecture Overview
[High-level description of components and interactions. A diagram reference
is appropriate here but not a full design document.]

### Key Decisions
| Decision | Choice | Rationale |
|----------|--------|-----------|
| [Build vs. buy] | [Choice] | [Brief rationale] |
| [Technology selection] | [Choice] | [Brief rationale] |
| [Integration approach] | [Choice] | [Brief rationale] |

### Integration Points
- [System 1]: [How the capability integrates]
- [System 2]: [How the capability integrates]

### Open Technical Questions
- [Question that needs to be resolved during Phase 1]
- [Question that affects scope or approach]

---

## Risks & Dependencies

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| [Risk description] | [L/M/H] | [L/M/H] | [How to mitigate] |
| [Risk description] | [L/M/H] | [L/M/H] | [How to mitigate] |
| [Risk description] | [L/M/H] | [L/M/H] | [How to mitigate] |

### Dependencies
| Dependency | Team | Status | Risk if Delayed |
|------------|------|--------|----------------|
| [What we need] | [From whom] | [Status] | [Impact] |

---

## Go/No-Go Criteria (After Phase 1)

### Go (Continue to Phase 2)
- [ ] MVP delivered within [X] of planned timeline
- [ ] [N] users actively using the capability within [X] weeks of launch
- [ ] User feedback NPS > [X]
- [ ] No blocking technical risks materialized

### No-Go (Stop and Reassess)
- [ ] MVP delayed > [X] weeks beyond plan
- [ ] Adoption below [N] users after [X] weeks
- [ ] User feedback reveals fundamental design flaw
- [ ] Technical approach proves infeasible

### Pivot (Change Approach)
- [ ] Core value validated but scope needs adjustment
- [ ] Users adopt but use differently than expected

---

## Alternatives Considered

### Alternative 1: Do Nothing
[What happens if we do not build this. Quantify the cost of inaction.]

### Alternative 2: [Buy/Adopt Existing Tool]
[Description, cost, why we are not recommending this.]

### Alternative 3: [Minimal Investment]
[Description of a smaller approach, what it solves and what it leaves unresolved.]

### Recommendation
[Why the proposed solution is preferred over the alternatives.]

---

## Approval

| Approver | Role | Decision | Date |
|----------|------|----------|------|
| [Name] | [Role] | [Approve/Reject/Defer] | |
```

## Executive One-Pager Template

```markdown
# [Capability Name] - Executive Summary

**Problem**: [3 sentences: pain, consequence, trend]

**Solution**: [2 sentences: what we will build and the key value proposition]

**Investment**: [N engineers, N quarters, $X total. Payback: N months.]

**Key Metrics**:
1. [Metric]: [Baseline] → [Target] by [date]
2. [Metric]: [Baseline] → [Target] by [date]
3. [Metric]: [Baseline] → [Target] by [date]

**Top Risk**: [Most significant risk and mitigation in 1 sentence]

**Ask**: [What you need from leadership: approval, budget, headcount, prioritization]
```

## Brief Quality Checklist

Before finalizing a brief, verify:

- [ ] Problem is quantified, not just described
- [ ] Success metrics have baselines and targets, not just metric names
- [ ] Investment includes opportunity cost, not just direct cost
- [ ] Go/no-go criteria are specific and measurable
- [ ] "Do nothing" alternative is genuinely evaluated, not dismissed
- [ ] Risks include adoption risk, not just technical risk
- [ ] Brief is readable by someone outside the platform team
