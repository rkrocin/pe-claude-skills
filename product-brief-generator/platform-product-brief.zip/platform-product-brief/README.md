# Platform Product Brief Generator

A [Claude Skill](https://docs.anthropic.com/) that generates product briefs for internal platform capabilities, treating platform features as products with defined users, success metrics, and go/no-go criteria.

## What It Does

Describe a platform capability idea and it generates:

- **Product Brief** with quantified problem statement, user personas, and phased delivery plan
- **Success Metrics** with baselines, targets, and measurement methods
- **Investment Case** with cost, payback analysis, and opportunity cost
- **Go/No-Go Criteria** defining when to continue, stop, or pivot after initial investment
- **Alternatives Analysis** including the cost of doing nothing
- **Executive One-Pager** (optional) for VP/CIO-level decisions

## Why

Platform teams that operate as project shops build what stakeholders ask for. Platform teams that operate as product organizations build what users need, validated by evidence. The product brief forces this discipline: who is the user, what is the problem (with data), how do we measure success, and when do we stop if it is not working.

The go/no-go criteria are the most important section. They prevent the sunk-cost fallacy that keeps teams investing in initiatives that are not delivering value. Agreeing on kill criteria before work starts is the single most effective governance mechanism for platform investment.

## Usage

### From a Rough Idea

```
We need to do something about our terrible deployment pipeline. Engineers 
complain constantly, rollbacks happen weekly, and our DORA metrics are 
getting worse. Write a product brief.
```

### From a Specific Proposal

```
I want to build a GenAI-powered knowledge search platform that indexes our 
Confluence, GitHub wikis, and Slack archives, and lets engineers ask questions 
in natural language. We have 800 engineers and they spend about an hour a day 
searching for documentation. Write a product brief for my VP.
```

### Executive One-Pager Only

```
Generate an executive one-pager for deploying automated deployment guardrails. 
3 engineers, 1 quarter, targeting a reduction in deployment rollbacks from 
12% to 4%.
```

## Sample Outputs

| File | Description |
|------|-------------|
| `sample-brief-knowledge-platform.md` | Full product brief for a GenAI-powered engineering knowledge platform with RAG over internal documentation |
| `sample-executive-onepager.md` | Executive one-pager for automated deployment guardrails |

The knowledge platform sample is the showcase. It demonstrates every section of a strong product brief: quantified problem ($6.2M in lost productivity), specific user personas with pain frequencies, phased delivery with go/no-go checkpoints, a payback analysis, and genuine alternatives evaluation including the cost of inaction.

## Brief Quality Checklist

Every generated brief is validated against:

- [ ] Problem is quantified, not just described
- [ ] Success metrics have baselines and targets, not just metric names
- [ ] Investment includes opportunity cost
- [ ] Go/no-go criteria are specific and measurable
- [ ] "Do nothing" alternative is genuinely evaluated
- [ ] Risks include adoption risk, not just technical risk
- [ ] Brief is readable by someone outside the platform team

## Key Sections

### The Problem (Three Layers)
1. **The pain**: What is happening today, with specific numbers
2. **The consequence**: What the pain costs in terms leadership understands (velocity, cost, risk)
3. **The trend**: Whether the problem is stable or getting worse

### Success Metrics (Four Types)
1. **Adoption**: Are people using it?
2. **Efficiency**: Is it making things faster?
3. **Quality**: Is it making things better?
4. **Satisfaction**: Do people like it?

### Go/No-Go Criteria (Three Outcomes)
1. **Go**: Specific conditions to continue investing
2. **No-Go**: Specific conditions to stop and reassess
3. **Pivot**: Specific conditions to change approach but continue

## Skill Structure

```
platform-product-brief/
├── SKILL.md                                      # Skill definition and section guidance
├── README.md                                     # This file
├── references/
│   └── brief-format.md                           # Full template, one-pager template, quality checklist
└── assets/
    ├── sample-brief-knowledge-platform.md        # Full brief: GenAI knowledge platform
    └── sample-executive-onepager.md              # One-pager: deployment guardrails
```

## License

MIT
