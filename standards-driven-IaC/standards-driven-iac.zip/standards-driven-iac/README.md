# Standards-Driven IaC Generator

A [Claude Skill](https://docs.anthropic.com/) that reads company standards, policies, and guidelines from uploaded documents (.docx or .md) and generates AWS infrastructure-as-code (Terraform or CloudFormation) that complies with those standards.

## What It Does

Upload your company's cloud infrastructure standards document and describe what you need to build. The skill:

1. **Reads and parses** the standards document (Word or Markdown)
2. **Extracts policies** into structured rules across naming, tagging, encryption, networking, compute, storage, database, logging, IAM, and cost governance categories
3. **Confirms extraction** with you before generating (no misinterpreted policies)
4. **Generates compliant IaC** (Terraform HCL or CloudFormation YAML/JSON) with every configuration element traced to a specific policy
5. **Produces a compliance map** showing which policy each configuration satisfies
6. **Flags deviations** if any requested resource cannot fully comply, with explanation and recommendations

## Why

Every organization has cloud infrastructure standards. Most engineers either do not read them, interpret them differently, or discover non-compliance during a code review or audit finding. This skill closes that gap by reading the actual standards document and generating infrastructure code that satisfies every applicable policy from the start.

The compliance map is the key differentiator. It is not just "this Terraform looks right." It is "this Terraform satisfies these specific policies from these specific sections of your standards document," which is exactly what an auditor or compliance reviewer needs to see.

## Usage

### Upload Standards + Describe Resources

```
[Upload: cloud-infrastructure-standards.docx]

Based on our standards document, generate Terraform for:
- An S3 bucket for storing payment transaction logs
- An RDS PostgreSQL instance for the payments service
- Production environment, PCI scope
```

### Multiple Standards Documents

```
[Upload: cloud-standards.md]
[Upload: security-baseline.docx]
[Upload: tagging-policy.md]

Generate CloudFormation for a VPC with public and private subnets 
across 3 AZs, following all three policy documents.
```

### Review Standards Only

```
[Upload: infrastructure-guidelines.docx]

Extract and summarize the policies in this document. 
Don't generate any IaC yet.
```

## Supported Input Formats

| Format | How It Is Read |
|--------|---------------|
| `.md` (Markdown) | Read directly |
| `.docx` (Word) | Converted to Markdown via pandoc |
| `.pdf` | Extracted via pdf-reading skill |

## Supported Output Formats

| Format | Files Generated |
|--------|----------------|
| **Terraform HCL** (default) | `main.tf`, `variables.tf`, `outputs.tf`, `terraform.tfvars.example`, `locals.tf` |
| **CloudFormation** | Single YAML or JSON template with Parameters, Conditions, and Outputs |
| **Compliance Map** (always) | Markdown file mapping every configuration to its source policy |

## Sample Files

### Input
`assets/sample-standards/acme-cloud-standards.md` contains a realistic 10-section cloud infrastructure standards document covering naming, tagging, encryption, networking, compute, database, storage, logging, IAM, and cost governance.

### Output
`assets/sample-output/` contains what the skill generates when asked to create an S3 bucket and RDS instance based on that standards document:

| File | Description |
|------|-------------|
| `main.tf` | Terraform with inline comments referencing specific policy sections |
| `variables.tf` | Variables with validation rules that enforce standards at plan time |
| `compliance-map.md` | Full mapping of every configuration element to its source policy |

## Key Design Decisions

**Every configuration traces to a policy.** Inline comments reference the specific section of the standards document. Nothing is added "just because it's a best practice" without a corresponding policy.

**Variable validation enforces standards.** The generated `variables.tf` includes validation blocks that reject non-compliant inputs at `terraform plan` time, before anything is deployed. Previous-generation instance types, malformed cost center codes, and invalid environment names are caught before they reach AWS.

**Deviations are explicit.** If a resource cannot fully comply (e.g., Multi-AZ in development), the deviation is documented with rationale and a recommendation for updating the standards.

**Ambiguity is resolved conservatively.** When the standards say "should" or "appropriate," the skill chooses the more secure option and documents the assumption.

## Policy Categories

The skill extracts and maps policies across these categories:

| Category | What It Covers |
|----------|---------------|
| Naming conventions | Resource naming patterns, prefixes, case rules |
| Tagging standards | Required tags, key formats, value constraints |
| Encryption | At-rest (KMS CMK vs. AWS-managed), in-transit (TLS version), key rotation |
| Network | VPC architecture, subnet tiers, security groups, public access restrictions |
| IAM | Role naming, least privilege, wildcard restrictions, service accounts |
| Logging | CloudTrail, flow logs, access logs, retention periods |
| Compute | Instance generations, EBS types, auto scaling requirements |
| Storage | S3 versioning, lifecycle, bucket policies, access logging |
| Database | Instance classes, Multi-AZ, backups, deletion protection, SSL enforcement |
| Cost governance | Lifecycle tags, instance optimization, scheduling |

## Skill Structure

```
standards-driven-iac/
├── SKILL.md                                        # Skill definition and workflow
├── README.md                                       # This file
├── references/
│   └── aws-patterns.md                             # Common AWS resource patterns by policy category
└── assets/
    ├── sample-standards/
    │   └── acme-cloud-standards.md                 # Sample 10-section standards document
    └── sample-output/
        ├── main.tf                                 # Generated Terraform with policy annotations
        ├── variables.tf                            # Variables with standards-enforcing validation
        └── compliance-map.md                       # Full policy-to-configuration mapping
```

## Relationship to Other Skills

This skill generates IaC from standards. The [IaC Compliance Reviewer](../iac-compliance-reviewer) evaluates existing IaC against policy controls. Used together:

1. **Standards-Driven IaC Generator** produces compliant templates from company standards
2. **IaC Compliance Reviewer** validates those templates (and any manual modifications) against the same controls
3. **Compliance Evidence Mapper** maps the deployed controls to regulatory frameworks for audit

This three-skill chain covers the full compliance lifecycle: generate compliant, validate compliance, prove compliance.

## License

MIT
