# Variables with defaults aligned to Acme Financial Services Cloud Standards v3.1

variable "aws_region" {
  description = "AWS region"
  type        = string
  default     = "us-east-1"
}

variable "environment" {
  description = "Deployment environment (Section 2.1)"
  type        = string
  validation {
    condition     = contains(["dev", "stg", "prod"], var.environment)
    error_message = "Environment must be dev, stg, or prod per naming convention (Section 2.1)."
  }
}

variable "application" {
  description = "Application identifier, lowercase, no spaces (Section 2.1)"
  type        = string
  default     = "payments"
  validation {
    condition     = can(regex("^[a-z][a-z0-9-]*$", var.application))
    error_message = "Application must be lowercase alphanumeric with hyphens per naming convention (Section 2.1)."
  }
}

# --- Standard Tags (Section 2.2) ---

variable "owner" {
  description = "Responsible team or individual (Section 2.2)"
  type        = string
  default     = "payments-team"
}

variable "cost_center" {
  description = "Finance cost allocation code (Section 2.2)"
  type        = string
  validation {
    condition     = can(regex("^CC-[0-9]+$", var.cost_center))
    error_message = "CostCenter must follow format CC-NNNN (Section 2.2)."
  }
}

variable "data_classification" {
  description = "Data classification level (Section 2.2, required for data stores)"
  type        = string
  default     = "Confidential"
  validation {
    condition     = contains(["Public", "Internal", "Confidential", "Restricted"], var.data_classification)
    error_message = "DataClassification must be Public, Internal, Confidential, or Restricted (Section 2.2)."
  }
}

variable "compliance_scope" {
  description = "Compliance framework scope (Section 2.2)"
  type        = string
  default     = "PCI"
  validation {
    condition     = contains(["PCI", "SOC2", "None"], var.compliance_scope)
    error_message = "ComplianceScope must be PCI, SOC2, or None (Section 2.2)."
  }
}

# --- Network ---

variable "vpc_id" {
  description = "VPC ID for resource placement"
  type        = string
}

variable "vpc_cidr" {
  description = "VPC CIDR block for egress rules"
  type        = string
}

variable "private_subnet_ids" {
  description = "Private subnet IDs for RDS and compute resources (Section 4.2)"
  type        = list(string)
}

variable "app_security_group_ids" {
  description = "Security group IDs of application tier for RDS ingress rules"
  type        = list(string)
}

# --- S3 ---

variable "logging_bucket_id" {
  description = "Centralized S3 logging bucket ID (Section 7.1)"
  type        = string
}

# --- RDS ---

variable "db_engine_version" {
  description = "PostgreSQL engine version"
  type        = string
  default     = "15.4"
}

variable "db_instance_class" {
  description = "RDS instance class - must be current generation per Section 5.1/6.1"
  type        = string
  default     = "db.m6i.large"
  validation {
    condition     = !can(regex("^db\\.(m4|m3|r4|r3|t2)\\.", var.db_instance_class))
    error_message = "Previous-generation instance types are prohibited (Section 5.1). Use db.m6i, db.r6i, db.m7g, or newer."
  }
}

variable "db_allocated_storage" {
  description = "Initial allocated storage in GB"
  type        = number
  default     = 100
}

variable "db_max_allocated_storage" {
  description = "Maximum allocated storage for autoscaling in GB"
  type        = number
  default     = 500
}

variable "db_username" {
  description = "Master database username"
  type        = string
  default     = "dbadmin"
}

variable "backup_retention_days" {
  description = "RDS backup retention period in days (Section 6.1: min 7 for prod, min 1 for non-prod)"
  type        = number
  default     = 7
}
