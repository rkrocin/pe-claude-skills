# AWS Resource Configuration Patterns by Policy Category

Quick reference for translating common policy requirements into Terraform and CloudFormation configuration. Use this when mapping extracted policies to IaC configuration.

## Encryption at Rest

### S3 - SSE-KMS with CMK
```hcl
# Terraform
resource "aws_s3_bucket_server_side_encryption_configuration" "this" {
  bucket = aws_s3_bucket.this.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm     = "aws:kms"
      kms_master_key_id = var.kms_key_arn  # CMK, not AWS-managed
    }
    bucket_key_enabled = true  # Reduces KMS API calls
  }
}
```

### RDS - Encrypted Storage
```hcl
resource "aws_db_instance" "this" {
  storage_encrypted = true
  kms_key_id        = var.kms_key_arn  # CMK
}
```

### EBS - Encrypted Volumes
```hcl
resource "aws_ebs_volume" "this" {
  encrypted  = true
  kms_key_id = var.kms_key_arn
}

# Or via launch template
resource "aws_launch_template" "this" {
  block_device_mappings {
    device_name = "/dev/xvda"
    ebs {
      encrypted  = true
      kms_key_id = var.kms_key_arn
      volume_type = "gp3"
    }
  }
}
```

### DynamoDB - Encrypted Table
```hcl
resource "aws_dynamodb_table" "this" {
  server_side_encryption {
    enabled     = true
    kms_key_arn = var.kms_key_arn  # CMK
  }
}
```

## Encryption in Transit

### ALB - TLS 1.2+ Listener
```hcl
resource "aws_lb_listener" "https" {
  protocol        = "HTTPS"
  ssl_policy      = "ELBSecurityPolicy-TLS13-1-2-2021-06"
  certificate_arn = var.certificate_arn
}

# HTTP redirect
resource "aws_lb_listener" "http_redirect" {
  port     = 80
  protocol = "HTTP"
  default_action {
    type = "redirect"
    redirect {
      port        = "443"
      protocol    = "HTTPS"
      status_code = "HTTP_301"
    }
  }
}
```

### RDS - Force SSL
```hcl
resource "aws_db_parameter_group" "this" {
  family = "postgres15"
  parameter {
    name  = "rds.force_ssl"
    value = "1"
  }
}
```

## Access Control

### S3 - Public Access Block
```hcl
resource "aws_s3_bucket_public_access_block" "this" {
  bucket                  = aws_s3_bucket.this.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}
```

### IAM - Least Privilege Role
```hcl
resource "aws_iam_role" "this" {
  name = "${local.name_prefix}-role"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action    = "sts:AssumeRole"
      Effect    = "Allow"
      Principal = { Service = "ecs-tasks.amazonaws.com" }  # Scoped principal
    }]
  })
  tags = local.standard_tags
}

resource "aws_iam_role_policy" "this" {
  role = aws_iam_role.this.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action   = ["s3:GetObject", "s3:PutObject"]  # Specific actions
      Effect   = "Allow"
      Resource = ["${aws_s3_bucket.this.arn}/*"]     # Specific resources
    }]
  })
}
```

### Security Group - Restricted Ingress
```hcl
resource "aws_security_group" "this" {
  name   = "${local.name_prefix}-sg"
  vpc_id = var.vpc_id

  ingress {
    from_port       = 443
    to_port         = 443
    protocol        = "tcp"
    security_groups = [var.alb_security_group_id]  # Source SG, not CIDR
    description     = "Allow HTTPS from ALB only"
  }

  egress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = [var.vpc_cidr]
    description = "Allow HTTPS to internal services"
  }

  tags = local.standard_tags
}
```

## Logging

### CloudTrail
```hcl
resource "aws_cloudtrail" "this" {
  name                          = "${local.name_prefix}-trail"
  s3_bucket_name                = var.cloudtrail_bucket
  is_multi_region_trail         = true
  enable_log_file_validation    = true
  kms_key_id                    = var.kms_key_arn
  include_global_service_events = true
  tags                          = local.standard_tags
}
```

### VPC Flow Logs
```hcl
resource "aws_flow_log" "this" {
  vpc_id               = aws_vpc.this.id
  traffic_type         = "ALL"
  log_destination_type = "cloud-watch-logs"
  log_destination      = aws_cloudwatch_log_group.flow_logs.arn
  iam_role_arn         = aws_iam_role.flow_log_role.arn
  tags                 = local.standard_tags
}
```

### S3 Access Logging
```hcl
resource "aws_s3_bucket_logging" "this" {
  bucket        = aws_s3_bucket.this.id
  target_bucket = var.logging_bucket_id
  target_prefix = "${aws_s3_bucket.this.id}/"
}
```

### CloudWatch Log Group with Retention
```hcl
resource "aws_cloudwatch_log_group" "this" {
  name              = "/app/${local.name_prefix}"
  retention_in_days = var.log_retention_days  # From standards
  kms_key_id        = var.kms_key_arn
  tags              = local.standard_tags
}
```

## Tagging

### Standard Tags as Locals
```hcl
locals {
  standard_tags = {
    Environment        = var.environment
    Owner              = var.owner
    CostCenter         = var.cost_center
    Application        = var.application
    ManagedBy          = "terraform"
    DataClassification = var.data_classification
    ComplianceScope    = var.compliance_scope
  }
}
```

### Merged Tags Pattern
```hcl
# Merge standard tags with resource-specific tags
resource "aws_s3_bucket" "this" {
  bucket = "${local.name_prefix}-data"
  tags   = merge(local.standard_tags, {
    Purpose = "transaction-logs"
  })
}
```

## Networking

### VPC with Standard Subnet Layout
```hcl
resource "aws_vpc" "this" {
  cidr_block           = var.vpc_cidr
  enable_dns_hostnames = true
  enable_dns_support   = true
  tags = merge(local.standard_tags, {
    Name = "${local.name_prefix}-vpc"
  })
}

# Private subnets across AZs
resource "aws_subnet" "private" {
  count             = length(var.availability_zones)
  vpc_id            = aws_vpc.this.id
  cidr_block        = cidrsubnet(var.vpc_cidr, 8, count.index)
  availability_zone = var.availability_zones[count.index]
  map_public_ip_on_launch = false  # Per network standards
  tags = merge(local.standard_tags, {
    Name = "${local.name_prefix}-private-${var.availability_zones[count.index]}"
    Tier = "private"
  })
}
```

## Compute

### Current-Generation Instance Types
Map old generation to current:
| Old | Current Equivalent |
|-----|--------------------|
| m4 | m6i or m7i |
| c4 | c6i or c7i |
| r4 | r6i or r7i |
| t2 | t3 or t3a |

### ECS Fargate Task
```hcl
resource "aws_ecs_task_definition" "this" {
  family                   = local.name_prefix
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = var.task_cpu
  memory                   = var.task_memory
  execution_role_arn       = aws_iam_role.ecs_execution.arn
  task_role_arn            = aws_iam_role.ecs_task.arn
  tags                     = local.standard_tags
}
```

## Storage Lifecycle

### S3 Lifecycle Rules
```hcl
resource "aws_s3_bucket_lifecycle_configuration" "this" {
  bucket = aws_s3_bucket.this.id
  rule {
    id     = "standard-lifecycle"
    status = "Enabled"
    transition {
      days          = var.glacier_transition_days  # From standards
      storage_class = "GLACIER"
    }
    expiration {
      days = var.expiration_days  # From standards
    }
  }
}
```

## Database

### RDS with Standards Compliance
```hcl
resource "aws_db_instance" "this" {
  identifier           = "${local.name_prefix}-db"
  engine               = var.db_engine
  engine_version       = var.db_engine_version
  instance_class       = var.db_instance_class  # Must be current generation per standards
  allocated_storage    = var.db_storage
  storage_encrypted    = true
  kms_key_id           = var.kms_key_arn
  publicly_accessible  = false  # Per network standards
  multi_az             = var.environment == "production" ? true : var.multi_az_non_prod
  db_subnet_group_name = aws_db_subnet_group.this.name
  parameter_group_name = aws_db_parameter_group.this.name
  
  backup_retention_period = var.backup_retention_days  # From standards
  
  enabled_cloudwatch_logs_exports = ["audit", "general"]  # Per logging standards
  
  tags = local.standard_tags
}
```
