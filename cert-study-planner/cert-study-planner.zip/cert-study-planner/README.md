# Certification Study Planner

A [Claude Skill](https://docs.anthropic.com/) that generates structured study plans for professional IT and engineering certifications, including topic sequencing, resource recommendations, milestone checkpoints, and multi-certification path planning.

## What It Does

Specify a target certification, your available study time, and your experience level. The skill generates:

- **Study Plan** with weekly schedule, daily activities, and time allocation by domain
- **Domain Priority Analysis** weighting exam domains against your experience for optimal focus
- **Milestone Checkpoints** with practice test scheduling and readiness criteria at 25%, 50%, 75%, and final
- **Resource Recommendations** organized by type (video, book, practice tests, hands-on, community)
- **Certification Path Planning** for sequencing multiple certifications with overlap exploitation

## Why

Certification preparation is one of those areas where most people know what to study but struggle with how to structure the work. They buy the study guide, watch some videos, take a practice test the week before, and hope for the best. This skill applies the same discipline to certification prep that engineering organizations apply to project planning: scope the work, prioritize by weight and weakness, set measurable checkpoints, and adjust based on data.

The certification path planning is particularly useful for professionals building a credential portfolio. Sequencing certifications to exploit content overlap (e.g., CISSP before CCSP saves 3-4 weeks) and grouping related certs while the material is fresh can save months of total study time across a multi-year certification strategy.

## Supported Certifications

### AWS (7 certifications)
Solutions Architect Associate and Professional, Developer Associate, Security Specialty, ML Specialty, ML Engineer Associate, GenAI Developer Professional

### Cybersecurity (10 certifications)
CISSP, ISSAP, ISSEP, CCSP, CISM, CRISC, CGEIT, CSSLP, GSLC, CompTIA Security+

### Cloud & Platform (6 certifications)
CKA, CKAD, CKS, Terraform Associate, FinOps Practitioner, FinOps Engineer

### AI/ML (5 certifications)
AWS GenAI Developer Professional, AWS ML Specialty, AWS ML Engineer, AAISM, Google Professional ML Engineer

For certifications not in the reference files, the skill generates plans based on publicly available exam guide information.

## Usage

### Individual Exam Plan

```
I want to get my CISSP. I have 8 weeks and can study about 12 hours per week. 
I'm strong on networking and access control but weak on cryptography and 
software security. Build me a study plan.
```

### Certification Path Planning

```
I'm a platform engineering director in financial services. I already have 
AWS SA Professional and CISSP. What should I pursue next, and in what order?
```

### Quick Readiness Check

```
I'm 3 weeks out from my CKA exam and scoring 68% on practice tests. 
Am I ready or should I postpone?
```

## Sample Outputs

| File | Description |
|------|-------------|
| `sample-plan-cissp.md` | Full 8-week CISSP study plan with weekly schedule, milestones, and exam day tips |
| `sample-certification-path.md` | Multi-certification path for a platform engineering leader in financial services |

## Study Plan Structure

Every generated plan includes:

1. **Plan Summary**: Target cert, timeline, total hours, feasibility assessment
2. **Domain Priority Analysis**: Exam domains weighted by importance and personal weakness
3. **Week-by-Week Schedule**: Daily activities with specific resources and durations
4. **Milestone Checkpoints**: Practice test targets at 25%, 50%, 75%, and final readiness
5. **Resource List**: Categorized by type (primary, supplementary, practice, community)
6. **Exam Day Tips**: Certification-specific test-taking strategies

## Time Estimation Model

The skill estimates required study hours based on certification difficulty and experience level:

| Difficulty Tier | Beginner | Intermediate | Advanced |
|----------------|----------|--------------|----------|
| Associate/Foundation | 60-80 hrs | 40-60 hrs | 20-30 hrs |
| Professional/Specialty | 100-140 hrs | 70-100 hrs | 40-60 hrs |
| Expert/Master | 150-200 hrs | 100-140 hrs | 60-80 hrs |

If available study hours fall below 70% of estimated required hours, the skill flags the risk and recommends timeline adjustment.

## Skill Structure

```
cert-study-planner/
├── SKILL.md                              # Skill definition and plan generation process
├── README.md                             # This file
├── references/
│   ├── aws-certs.md                      # 7 AWS certification profiles
│   ├── security-certs.md                 # 10 cybersecurity certification profiles
│   ├── platform-certs.md                 # 6 cloud/platform certification profiles
│   └── ai-certs.md                       # 5 AI/ML certification profiles
└── assets/
    ├── sample-plan-cissp.md              # Example: 8-week CISSP study plan
    └── sample-certification-path.md      # Example: multi-cert path for FSI platform leader
```

## License

MIT
