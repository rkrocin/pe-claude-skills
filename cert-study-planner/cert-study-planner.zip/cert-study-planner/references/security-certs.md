# Cybersecurity Certification Exam Profiles

## CISSP - Certified Information Systems Security Professional

- **Difficulty tier**: Expert/Master
- **Duration**: 180 minutes (CAT format, 125-175 questions)
- **Passing score**: 700/1000
- **Cost**: $749 USD
- **Prerequisite**: 5 years experience in 2+ domains (or 4 years + degree)
- **Certifying body**: (ISC)2

### Domains
| Domain | Weight | Topics |
|--------|--------|--------|
| Security and Risk Management | 16% | Governance, compliance, legal/regulatory, risk management, BCP, ethics |
| Asset Security | 10% | Data classification, ownership, privacy, retention, handling |
| Security Architecture and Engineering | 13% | Security models, cryptography, secure design principles, physical security |
| Communication and Network Security | 13% | Network architecture, secure channels, network attacks, segmentation |
| Identity and Access Management | 13% | Authentication, authorization, identity management, federated identity |
| Security Assessment and Testing | 12% | Assessment strategies, testing methodologies, auditing, vulnerability scanning |
| Security Operations | 13% | Incident management, forensics, logging, monitoring, DR/BCP operations |
| Software Development Security | 10% | SDLC security, application vulnerabilities, secure coding, DevSecOps |

### Key Study Resources
- **Primary**: Destination Certification MindMap video series (free on YouTube), (ISC)2 Official Study Guide
- **Practice tests**: Boson, Destination Certification practice exams
- **Supplementary**: 11th Hour CISSP (rapid review), Sunflower study notes
- **Community**: r/cissp subreddit, CISSP Discord
- **Critical note**: CISSP tests conceptual understanding, not memorization. Think like a manager, not an engineer. When in doubt, choose the answer that addresses risk first, then technology.

---

## ISSAP - Information Systems Security Architecture Professional

- **Difficulty tier**: Expert/Master
- **Duration**: 180 minutes
- **Questions**: 125
- **Passing score**: 700/1000
- **Cost**: $599 USD
- **Prerequisite**: Active CISSP + 2 years architecture experience
- **Certifying body**: (ISC)2

### Domains
| Domain | Weight | Topics |
|--------|--------|--------|
| Security Architecture Modeling | 21% | Architecture frameworks, security models, threat modeling, zero trust |
| Infrastructure Security Architecture | 19% | Network security architecture, cloud architecture, virtualization security |
| Identity and Access Management Architecture | 19% | IAM architecture, federation, SSO, privilege management, directory services |
| Architect for Governance, Compliance, and Risk Management | 14% | Regulatory compliance architecture, audit support, risk frameworks |
| Security Operations Architecture | 13% | SIEM architecture, SOC design, incident response architecture, forensic readiness |
| Application Security Architecture | 14% | Secure SDLC architecture, API security, microservices security, DevSecOps |

### Key Study Resources
- **Primary**: (ISC)2 Official ISSAP CBK, ISSAP Study Guide
- **Note**: Limited third-party resources. CISSP knowledge is foundational. Focus on architectural decision-making and enterprise-scale security design.

---

## ISSEP - Information Systems Security Engineering Professional

- **Difficulty tier**: Expert/Master
- **Duration**: 180 minutes
- **Questions**: 125
- **Passing score**: 700/1000
- **Cost**: $599 USD
- **Prerequisite**: Active CISSP + 2 years security engineering experience
- **Certifying body**: (ISC)2

### Domains
| Domain | Weight | Topics |
|--------|--------|--------|
| Systems Security Engineering Foundations | 25% | SE principles, security engineering lifecycle, systems thinking |
| Risk Management | 14% | Risk assessment, risk treatment, residual risk, risk communication |
| Security Planning, Design, and Implementation | 30% | Security requirements, design patterns, implementation strategies |
| Secure Operations and Maintenance | 13% | Secure operations, monitoring, maintenance, disposal |
| Systems Engineering Technical Management | 18% | Configuration management, quality assurance, verification, validation |

---

## CCSP - Certified Cloud Security Professional

- **Difficulty tier**: Professional
- **Duration**: 180 minutes
- **Questions**: 150
- **Passing score**: 700/1000
- **Cost**: $599 USD
- **Prerequisite**: 5 years IT experience (3 in security, 1 in cloud)
- **Certifying body**: (ISC)2

### Domains
| Domain | Weight | Topics |
|--------|--------|--------|
| Cloud Concepts, Architecture, and Design | 17% | Cloud models, reference architecture, shared responsibility, design principles |
| Cloud Data Security | 20% | Data lifecycle, storage architectures, data discovery, classification, DRM |
| Cloud Platform and Infrastructure Security | 17% | Physical/virtual infrastructure, network security, hardening, DR/BCP |
| Cloud Application Security | 17% | Application architecture, SDLC, IAM, API security |
| Cloud Security Operations | 16% | Logging, monitoring, incident management, forensics, SOC |
| Legal, Risk, and Compliance | 13% | Legal requirements, privacy, audit, risk management, contracts |

### Key Study Resources
- **Primary**: (ISC)2 Official CCSP Study Guide, Ben Maguire Udemy course
- **Practice tests**: Boson CCSP, official practice exam
- **Note**: Strong overlap with CISSP. If you hold CISSP, focus on cloud-specific concepts.

---

## CISM - Certified Information Security Manager

- **Difficulty tier**: Professional
- **Duration**: 240 minutes
- **Questions**: 150
- **Passing score**: 450/800
- **Cost**: $575 USD (member) / $760 USD (non-member)
- **Prerequisite**: 5 years infosec experience (3 in management)
- **Certifying body**: ISACA

### Domains
| Domain | Weight | Topics |
|--------|--------|--------|
| Information Security Governance | 17% | Security strategy, governance frameworks, organizational structure |
| Information Security Risk Management | 20% | Risk identification, assessment, treatment, monitoring |
| Information Security Program | 33% | Program development, management, resources, metrics |
| Incident Management | 30% | IR planning, detection, response, recovery, post-incident |

### Key Study Resources
- **Primary**: ISACA CISM Review Manual, CISM Review QA&E Database
- **Practice tests**: ISACA QA&E, Pocket Prep CISM
- **Note**: CISM is management-focused. Think about information security from a program management and governance perspective.

---

## CRISC - Certified in Risk and Information Systems Control

- **Difficulty tier**: Professional
- **Duration**: 240 minutes
- **Questions**: 150
- **Passing score**: 450/800
- **Cost**: $575 USD (member) / $760 USD (non-member)
- **Prerequisite**: 3 years in IT risk management
- **Certifying body**: ISACA

### Domains
| Domain | Weight | Topics |
|--------|--------|--------|
| Governance | 26% | Organizational governance, risk governance framework, risk culture |
| IT Risk Assessment | 20% | Risk identification, analysis and evaluation, risk scenarios |
| Risk Response and Reporting | 32% | Risk treatment, control design, risk reporting, KRIs |
| Information Technology and Security | 22% | IT operations, architecture, security principles, emerging technology risk |

### Key Study Resources
- **Primary**: ISACA CRISC Review Manual
- **Practice tests**: ISACA QA&E Database
- **Note**: Heavily focused on risk management process and decision-making. Less technical than CISSP.

---

## CGEIT - Certified in the Governance of Enterprise IT

- **Difficulty tier**: Professional
- **Duration**: 240 minutes
- **Questions**: 150
- **Passing score**: 450/800
- **Cost**: $575 USD (member) / $760 USD (non-member)
- **Prerequisite**: 5 years in enterprise IT governance
- **Certifying body**: ISACA

### Domains
| Domain | Weight | Topics |
|--------|--------|--------|
| Governance of Enterprise IT | 40% | IT governance frameworks, organizational structures, strategic alignment |
| IT Resources | 15% | Resource management, sourcing, capacity planning |
| IT Benefits Realization | 26% | Value delivery, portfolio management, investment management |
| IT Risk Optimization | 19% | Risk management integration, risk appetite, risk-aware culture |

---

## CompTIA Security+ (SY0-701)

- **Difficulty tier**: Associate/Foundation
- **Duration**: 90 minutes
- **Questions**: ~90
- **Passing score**: 750/900
- **Cost**: $392 USD
- **Prerequisite**: None (Network+ and 2 years experience recommended)
- **Certifying body**: CompTIA

### Domains
| Domain | Weight | Topics |
|--------|--------|--------|
| General Security Concepts | 12% | Security controls, threat actors, cryptography basics |
| Threats, Vulnerabilities, and Mitigations | 22% | Threat types, vulnerability assessment, mitigation techniques |
| Security Architecture | 18% | Network architecture, cloud models, secure infrastructure |
| Security Operations | 28% | Monitoring, incident response, automation, forensics |
| Security Program Management | 20% | Governance, risk, compliance, security awareness |

### Key Study Resources
- **Primary**: Professor Messer video series (free), CompTIA CertMaster
- **Practice tests**: Professor Messer practice exams, Dion Training
- **Note**: Good foundational cert. If pursuing CISSP, Security+ covers similar ground at a lower level and can serve as a warm-up.
