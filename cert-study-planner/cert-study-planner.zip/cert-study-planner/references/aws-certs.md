# AWS Certification Exam Profiles

## AWS Solutions Architect - Associate (SAA-C03)

- **Difficulty tier**: Associate
- **Duration**: 130 minutes
- **Questions**: 65
- **Passing score**: 720/1000
- **Cost**: $150 USD
- **Prerequisite**: None (1+ year hands-on recommended)

### Domains
| Domain | Weight | Topics |
|--------|--------|--------|
| Secure Architectures | 30% | IAM, VPC, security groups, NACLs, encryption, WAF, Shield |
| Resilient Architectures | 26% | Multi-AZ, multi-region, auto scaling, load balancing, decoupling, DR strategies |
| High-Performing Architectures | 24% | Compute selection, storage optimization, database selection, caching, CDN |
| Cost-Optimized Architectures | 20% | Pricing models, reserved/spot instances, S3 tiers, right-sizing, cost monitoring |

### Key Study Resources
- **Primary**: Stephane Maarek Udemy course, Adrian Cantrill course
- **Practice tests**: Tutorials Dojo, official AWS practice exam
- **Hands-on**: AWS Free Tier, A Cloud Guru labs
- **Documentation**: AWS Well-Architected Framework whitepapers

---

## AWS Solutions Architect - Professional (SAP-C02)

- **Difficulty tier**: Professional
- **Duration**: 180 minutes
- **Questions**: 75
- **Passing score**: 750/1000
- **Cost**: $300 USD
- **Prerequisite**: Associate recommended (not required)

### Domains
| Domain | Weight | Topics |
|--------|--------|--------|
| Design for Organizational Complexity | 26% | Multi-account strategies, cross-account access, AWS Organizations, network connectivity |
| Design for New Solutions | 29% | Solution design, migration strategies, serverless, containers, analytics |
| Continuous Improvement | 25% | Cost optimization, performance tuning, operational excellence, automation |
| Accelerate Workload Migration | 20% | Migration strategies (6 Rs), AWS Migration Hub, DMS, SMS, transfer services |

### Key Study Resources
- **Primary**: Stephane Maarek SAP course, Adrian Cantrill Professional course
- **Practice tests**: Tutorials Dojo, Whizlabs
- **Documentation**: AWS Well-Architected Framework, migration whitepapers, re:Invent session videos
- **Note**: This exam requires deep, scenario-based thinking. Practice tests are essential.

---

## AWS Developer - Associate (DVA-C02)

- **Difficulty tier**: Associate
- **Duration**: 130 minutes
- **Questions**: 65
- **Passing score**: 720/1000
- **Cost**: $150 USD
- **Prerequisite**: None

### Domains
| Domain | Weight | Topics |
|--------|--------|--------|
| Development with AWS Services | 32% | Lambda, API Gateway, DynamoDB, S3, SQS, SNS, Step Functions, ECS |
| Security | 26% | IAM, Cognito, KMS, Secrets Manager, certificate management |
| Deployment | 24% | CodeCommit, CodeBuild, CodeDeploy, CodePipeline, CloudFormation, SAM, CDK |
| Troubleshooting and Optimization | 18% | CloudWatch, X-Ray, debugging, performance tuning |

### Key Study Resources
- **Primary**: Stephane Maarek Developer course
- **Practice tests**: Tutorials Dojo
- **Hands-on**: Build and deploy a serverless application end-to-end

---

## AWS Security - Specialty (SCS-C02)

- **Difficulty tier**: Professional/Specialty
- **Duration**: 170 minutes
- **Questions**: 65
- **Passing score**: 750/1000
- **Cost**: $300 USD
- **Prerequisite**: Associate-level certification recommended

### Domains
| Domain | Weight | Topics |
|--------|--------|--------|
| Threat Detection and Incident Response | 14% | GuardDuty, Security Hub, Detective, IR procedures, forensics |
| Security Logging and Monitoring | 18% | CloudTrail, CloudWatch, VPC flow logs, Config, centralized logging |
| Infrastructure Security | 20% | VPC design, security groups, NACLs, WAF, Shield, Network Firewall |
| Identity and Access Management | 16% | IAM advanced, Organizations SCPs, SSO, Cognito, federation |
| Data Protection | 18% | KMS, CloudHSM, ACM, S3 encryption, RDS encryption, Macie |
| Management and Security Governance | 14% | Config rules, Systems Manager, Organizations, compliance automation |

### Key Study Resources
- **Primary**: AWS Skill Builder Security Specialty path
- **Practice tests**: Tutorials Dojo Security Specialty
- **Documentation**: AWS Security Best Practices whitepaper, Security Reference Architecture

---

## AWS Machine Learning - Specialty (MLS-C01)

- **Difficulty tier**: Professional/Specialty
- **Duration**: 170 minutes
- **Questions**: 65
- **Passing score**: 750/1000
- **Cost**: $300 USD

### Domains
| Domain | Weight | Topics |
|--------|--------|--------|
| Data Engineering | 20% | S3, Glue, Kinesis, data pipelines, data preparation |
| Exploratory Data Analysis | 24% | Data visualization, feature engineering, statistics, data distributions |
| Modeling | 36% | SageMaker, algorithm selection, training, hyperparameter tuning, evaluation |
| ML Implementation and Operations | 20% | Model deployment, A/B testing, monitoring, retraining, MLOps |

### Key Study Resources
- **Primary**: AWS Skill Builder ML Specialty path, Udemy ML Specialty courses
- **Hands-on**: SageMaker notebooks, build end-to-end ML pipeline
- **Documentation**: SageMaker documentation, built-in algorithm guides

---

## AWS Generative AI Developer - Professional

- **Difficulty tier**: Professional
- **Duration**: 170 minutes
- **Questions**: 65
- **Passing score**: 750/1000
- **Cost**: $300 USD

### Domains
| Domain | Weight | Topics |
|--------|--------|--------|
| Selection and Application of Foundation Models | 28% | Model selection criteria, Bedrock model catalog, model comparison, use case mapping |
| Prompt Engineering and Fine-tuning | 28% | Prompt design, few-shot learning, chain-of-thought, fine-tuning approaches, RLHF |
| Building RAG and Agentic Systems | 22% | Knowledge bases, vector databases, retrieval strategies, agent architectures |
| Security, Compliance, and Governance | 22% | Responsible AI, guardrails, data privacy, model access control, compliance |

### Key Study Resources
- **Primary**: AWS Skill Builder GenAI path, Bedrock workshops
- **Hands-on**: Build a RAG application with Bedrock and OpenSearch
- **Documentation**: Bedrock documentation, Generative AI on AWS guide
