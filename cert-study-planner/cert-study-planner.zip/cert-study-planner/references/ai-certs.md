# AI/ML Certification Exam Profiles

## AWS Generative AI Developer - Professional

See `aws-certs.md` for full profile. Cross-referenced here for AI/ML path planning.

Key points for AI/ML path context:
- Focuses on building with Bedrock, not training models from scratch
- RAG and agent architectures are 22% of the exam
- Strong complement to ML Specialty (ML Specialty covers model training, GenAI covers model application)

---

## AWS Machine Learning - Specialty (MLS-C01)

See `aws-certs.md` for full profile. Cross-referenced here for AI/ML path planning.

Key points for AI/ML path context:
- Heaviest domain is Modeling (36%): algorithm selection, training, tuning
- Requires understanding of classical ML algorithms, not just deep learning
- SageMaker is central to most exam scenarios
- Good foundation before GenAI Developer Professional

---

## AWS Machine Learning Engineer - Associate

- **Difficulty tier**: Associate
- **Duration**: 170 minutes
- **Questions**: 85
- **Passing score**: 720/1000
- **Cost**: $150 USD
- **Prerequisite**: None
- **Certifying body**: AWS

### Domains
| Domain | Weight | Topics |
|--------|--------|--------|
| Data Preparation for ML | 28% | Data ingestion, transformation, feature engineering, data quality |
| ML Model Development | 26% | Algorithm selection, model training, hyperparameter tuning, evaluation |
| Deployment and Orchestration | 22% | Model deployment patterns, SageMaker endpoints, CI/CD for ML, monitoring |
| ML Solution Monitoring and Maintenance | 24% | Model drift detection, retraining strategies, performance monitoring, cost optimization |

### Key Study Resources
- **Primary**: AWS Skill Builder ML Engineer path
- **Hands-on**: SageMaker Studio notebooks, build a complete ML pipeline
- **Note**: Newer exam (2024). Focuses on MLOps and production ML, not just model building. Strong complement to ML Specialty.

---

## AAISM - Advanced AI Security Management

- **Difficulty tier**: Professional
- **Duration**: 120 minutes
- **Questions**: ~60
- **Passing score**: ~70%
- **Cost**: Varies by provider
- **Prerequisite**: None (AI/ML and security experience recommended)

### Domains
| Domain | Weight | Topics |
|--------|--------|--------|
| AI Threat Landscape | ~20% | Adversarial attacks, model poisoning, data poisoning, prompt injection |
| AI Governance and Ethics | ~25% | Responsible AI, bias detection, fairness, transparency, regulatory compliance |
| AI System Security Architecture | ~25% | Secure AI pipelines, model access control, data privacy, MLOps security |
| AI Risk Management | ~15% | AI-specific risk frameworks, risk assessment for AI systems, risk mitigation |
| AI Incident Response | ~15% | AI-specific incident types, model compromise response, rollback procedures |

### Key Study Resources
- **Primary**: NIST AI RMF documentation, OWASP Top 10 for LLM Applications
- **Supplementary**: MITRE ATLAS (adversarial threat landscape for AI), responsible AI guidelines from major providers
- **Note**: Emerging certification area. Combines security expertise with AI/ML understanding. Unique differentiator for security professionals moving into AI.

---

## Google Professional Machine Learning Engineer

- **Difficulty tier**: Professional
- **Duration**: 120 minutes
- **Questions**: ~60
- **Passing score**: ~70% (Google does not publish exact passing scores)
- **Cost**: $200 USD
- **Prerequisite**: None (3+ years industry experience recommended)
- **Certifying body**: Google Cloud

### Domains
| Domain | Weight | Topics |
|--------|--------|--------|
| Architecting Low-Code ML Solutions | ~12% | AutoML, BigQuery ML, pre-built APIs, Vertex AI |
| Collaborating within and across Teams | ~14% | ML workflow management, experiment tracking, model registry |
| Scaling Prototypes into ML Models | ~18% | Training at scale, distributed training, hyperparameter tuning |
| Serving and Scaling Models | ~18% | Vertex AI Prediction, serving patterns, A/B testing, scaling |
| Automating and Orchestrating ML Pipelines | ~20% | Vertex AI Pipelines, Kubeflow, CI/CD for ML, orchestration |
| Monitoring ML Solutions | ~18% | Model monitoring, drift detection, explainability, troubleshooting |

### Key Study Resources
- **Primary**: Google Cloud Skills Boost ML Engineer learning path
- **Practice tests**: Google official practice exam
- **Hands-on**: Vertex AI notebooks and pipelines
- **Note**: GCP-specific. If your target environment is AWS, the AWS ML certs are more directly applicable. This cert is valuable for multi-cloud ML engineering positions.

---

## AI/ML Certification Path Recommendations

### For Platform Engineers Adding AI Capability
1. AWS GenAI Developer Professional (most practical for platform teams enabling AI)
2. AAISM (if your role includes AI security governance)

### For ML Engineers / Data Scientists
1. AWS ML Specialty or Google Professional ML Engineer (depending on cloud)
2. AWS ML Engineer Associate (MLOps focus)
3. AWS GenAI Developer Professional (application layer)

### For Security Professionals Expanding into AI
1. AAISM (AI-specific security)
2. AWS GenAI Developer Professional (understand what you're securing)

### For Leaders Building AI Strategy
1. AWS GenAI Developer Professional (practical understanding)
2. AAISM (risk and governance perspective)
