# Cloud & Platform Certification Exam Profiles

## CKA - Certified Kubernetes Administrator

- **Difficulty tier**: Professional
- **Duration**: 120 minutes
- **Format**: Performance-based (hands-on in live cluster)
- **Passing score**: 66%
- **Cost**: $395 USD (includes one free retake)
- **Prerequisite**: None
- **Certifying body**: CNCF / Linux Foundation

### Domains
| Domain | Weight | Topics |
|--------|--------|--------|
| Storage | 10% | PVs, PVCs, storage classes, volume types |
| Troubleshooting | 30% | Application failure, cluster component failure, networking issues |
| Workloads & Scheduling | 15% | Deployments, rolling updates, ConfigMaps, Secrets, resource limits, scheduling |
| Cluster Architecture, Installation & Configuration | 25% | kubeadm, etcd backup/restore, RBAC, cluster upgrades, HA |
| Services & Networking | 20% | Services, Ingress, NetworkPolicies, DNS, CNI |

### Key Study Resources
- **Primary**: Mumshad Mannambeth CKA course (KodeKloud/Udemy)
- **Practice**: killer.sh (included with exam registration), KodeKloud labs
- **Critical note**: This is a hands-on exam. You must be fast with kubectl. Practice until common operations are muscle memory. Bookmark the Kubernetes documentation (it is available during the exam).

---

## CKAD - Certified Kubernetes Application Developer

- **Difficulty tier**: Associate/Professional
- **Duration**: 120 minutes
- **Format**: Performance-based
- **Passing score**: 66%
- **Cost**: $395 USD (includes one free retake)
- **Prerequisite**: None
- **Certifying body**: CNCF / Linux Foundation

### Domains
| Domain | Weight | Topics |
|--------|--------|--------|
| Application Design and Build | 20% | Container images, multi-container pods, init containers, volumes |
| Application Deployment | 20% | Deployments, rolling updates, Helm, blue-green, canary |
| Application Observability and Maintenance | 15% | Probes, logging, debugging, API deprecations |
| Application Environment, Configuration, and Security | 25% | ConfigMaps, Secrets, SecurityContexts, ServiceAccounts, ResourceQuotas |
| Services and Networking | 20% | Services, Ingress, NetworkPolicies |

### Key Study Resources
- **Primary**: Mumshad Mannambeth CKAD course
- **Practice**: killer.sh, KodeKloud CKAD labs
- **Note**: Overlaps significantly with CKA. If pursuing both, do CKA first.

---

## CKS - Certified Kubernetes Security Specialist

- **Difficulty tier**: Professional/Specialty
- **Duration**: 120 minutes
- **Format**: Performance-based
- **Passing score**: 67%
- **Cost**: $395 USD (includes one free retake)
- **Prerequisite**: Active CKA certification
- **Certifying body**: CNCF / Linux Foundation

### Domains
| Domain | Weight | Topics |
|--------|--------|--------|
| Cluster Setup | 10% | Network policies, CIS benchmarks, ingress security, node metadata protection |
| Cluster Hardening | 15% | RBAC, service account hardening, restricting API access, upgrades |
| System Hardening | 15% | OS footprint minimization, IAM roles, AppArmor, Seccomp |
| Minimize Microservice Vulnerabilities | 20% | Security contexts, pod security standards, secrets management, runtime sandboxing |
| Supply Chain Security | 20% | Image scanning, signing, allowlists, static analysis, base image hardening |
| Monitoring, Logging, and Runtime Security | 20% | Falco, audit logging, immutable containers, behavioral analysis |

### Key Study Resources
- **Primary**: KodeKloud CKS course, Walid Shaari CKS study guide (GitHub)
- **Practice**: killer.sh CKS simulator
- **Note**: Requires active CKA. Most difficult of the three Kubernetes certs.

---

## HashiCorp Terraform Associate (003)

- **Difficulty tier**: Associate/Foundation
- **Duration**: 60 minutes
- **Questions**: 57
- **Passing score**: ~70%
- **Cost**: $70.50 USD
- **Prerequisite**: None
- **Certifying body**: HashiCorp

### Domains
| Domain | Weight | Topics |
|--------|--------|--------|
| IaC Concepts | 12% | IaC benefits, Terraform purpose and workflow |
| Terraform Purpose | 8% | Multi-cloud, provider ecosystem, state management |
| Terraform Basics | 20% | Providers, resources, variables, outputs, data sources |
| Terraform CLI | 14% | init, plan, apply, destroy, workspace, fmt, validate |
| Modules | 12% | Module sources, inputs/outputs, versioning, registry |
| Terraform Workflow | 10% | Write/plan/apply cycle, version control integration |
| State Management | 14% | Remote state, state locking, import, state manipulation |
| HCP Terraform | 10% | Workspaces, runs, policies, Sentinel |

### Key Study Resources
- **Primary**: HashiCorp Learn tutorials, Bryan Krausen Udemy course
- **Practice tests**: Bryan Krausen practice exams
- **Hands-on**: Build infrastructure on AWS Free Tier using Terraform
- **Note**: Relatively easy if you have Terraform hands-on experience. The exam tests concepts and workflow understanding, not complex HCL coding.

---

## FinOps Certified Practitioner

- **Difficulty tier**: Associate/Foundation
- **Duration**: 60 minutes
- **Questions**: 50
- **Passing score**: 75%
- **Cost**: $300 USD (includes training)
- **Prerequisite**: None
- **Certifying body**: FinOps Foundation

### Domains
| Domain | Weight | Topics |
|--------|--------|--------|
| FinOps Principles | ~25% | Core principles, cultural shift, cross-functional collaboration |
| FinOps Personas | ~15% | Engineering, finance, leadership, procurement personas and motivations |
| FinOps Phases | ~30% | Inform (visibility), Optimize (rates and usage), Operate (governance) |
| FinOps and Other Frameworks | ~15% | Relationship to ITIL, Agile, DevOps, ITSM |
| Cloud Rate Optimization | ~15% | Reserved instances, savings plans, spot, committed use discounts |

### Key Study Resources
- **Primary**: FinOps Foundation training course (included with exam fee)
- **Supplementary**: FinOps.org framework documentation, Cloud FinOps book (J.R. Storment)
- **Note**: The required training course is sufficient for most candidates.

---

## FinOps Certified Engineer

- **Difficulty tier**: Professional
- **Duration**: 90 minutes
- **Questions**: ~60
- **Passing score**: 75%
- **Cost**: $600 USD (includes training)
- **Prerequisite**: FinOps Certified Practitioner
- **Certifying body**: FinOps Foundation

### Domains
| Domain | Weight | Topics |
|--------|--------|--------|
| Implementing FinOps | ~25% | Building FinOps practice, tooling, automation, organizational adoption |
| Cloud Cost Optimization | ~30% | Rightsizing, commitment strategies, waste elimination, architectural optimization |
| FinOps at Scale | ~25% | Multi-cloud, enterprise FinOps, showback/chargeback, budgeting |
| Advanced FinOps | ~20% | Unit economics, sustainability, container/serverless cost management |

### Key Study Resources
- **Primary**: FinOps Foundation Engineer training course
- **Supplementary**: Cloud provider cost management documentation, FinOps.org advanced capabilities
